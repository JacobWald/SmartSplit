module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@supabase/node-fetch/lib/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@supabase/node-fetch/lib/index.js [app-route] (ecmascript)");
    });
});
}),
];