module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/api/groups/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=a5a1c_SmartSplit_apps_web__next-internal_server_app_api_groups_route_actions_3c6e6e9d.js.map