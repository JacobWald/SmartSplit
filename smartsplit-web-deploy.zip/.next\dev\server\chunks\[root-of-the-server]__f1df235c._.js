module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/lib/supabaseSSR.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSSRClientFromRequest",
    ()=>createSSRClientFromRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@supabase/ssr/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createServerClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@supabase/ssr/dist/module/createServerClient.js [app-route] (ecmascript)");
;
;
function createSSRClientFromRequest(request) {
    const response = new __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](null);
    // Parse request cookies -> [{ name, value }]
    const raw = request.headers.get('cookie') || '';
    const parsed = raw.split(';').map((s)=>s.trim()).filter(Boolean).map((kv)=>{
        const eq = kv.indexOf('=');
        if (eq === -1) return null;
        return {
            name: kv.slice(0, eq).trim(),
            value: kv.slice(eq + 1).trim()
        };
    }).filter(Boolean);
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createServerClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createServerClient"])(("TURBOPACK compile-time value", "https://mlxvtlfqzfzyvjuayazz.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1seHZ0bGZxemZ6eXZqdWF5YXp6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwMjEzNTQsImV4cCI6MjA3NzU5NzM1NH0.nJi-CJOaD7aIiyCjMKNEDkN-tcoxmERH5A1J7zlPwFU"), {
        cookies: {
            getAll () {
                return parsed;
            },
            setAll (cookiesToSet) {
                cookiesToSet.forEach(({ name, value, options })=>{
                    response.cookies.set(name, value, options);
                });
            }
        }
    });
    return {
        supabase,
        response
    };
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/lib/supabaseServer.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabaseServer",
    ()=>supabaseServer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://mlxvtlfqzfzyvjuayazz.supabase.co");
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseServer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey);
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/app/api/assigned-expenses/[id]/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PATCH",
    ()=>PATCH
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseSSR$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/lib/supabaseSSR.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/lib/supabaseServer.js [app-route] (ecmascript)");
;
;
;
async function PATCH(request, context) {
    const { id } = await context.params;
    try {
        if (!id) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Missing assigned_expense id in URL'
            }, {
                status: 400
            });
        }
        const { supabase, response } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseSSR$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSSRClientFromRequest"])(request);
        // who is calling?
        const { data: userData, error: userErr } = await supabase.auth.getUser();
        if (userErr || !userData?.user) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Not authenticated'
            }, {
                status: 401,
                headers: response.headers
            });
        }
        const currentUserId = userData.user.id;
        const body = await request.json();
        const { fulfilled } = body;
        if (typeof fulfilled !== 'boolean') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'fulfilled must be a boolean'
            }, {
                status: 400,
                headers: response.headers
            });
        }
        // Get assignment + parent expense + group
        const { data: assignment, error: aErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"].from('assigned_expenses').select(`
        id,
        user_id,
        fulfilled,
        expense:expenses (
          id,
          group_id
        )
      `).eq('id', id).single();
        if (aErr || !assignment) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Assignment not found'
            }, {
                status: 404,
                headers: response.headers
            });
        }
        const expenseId = assignment.expense.id;
        const groupId = assignment.expense.group_id;
        // Check role in this group
        const { data: gm, error: gmErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"].from('group_members').select('role').eq('group_id', groupId).eq('user_id', currentUserId).single();
        if (gmErr && gmErr.code !== 'PGRST116') {
            console.error('Group membership error:', gmErr);
        }
        const role = gm?.role ?? null;
        const isAdmin = role === 'ADMIN';
        const isModerator = role === 'MODERATOR';
        const isSelf = assignment.user_id === currentUserId;
        if (!isSelf && !isAdmin && !isModerator) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Not allowed to modify this payment status'
            }, {
                status: 403,
                headers: response.headers
            });
        }
        // Update this assigned_expenses row
        const { error: updErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"].from('assigned_expenses').update({
            fulfilled
        }).eq('id', id);
        if (updErr) {
            console.error('Error updating assignment fulfilled:', updErr);
            throw updErr;
        }
        // Recompute parent expense.fulfilled
        const { data: allAssignments, error: allErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"].from('assigned_expenses').select('fulfilled').eq('expense_id', expenseId);
        if (allErr) {
            console.error('Error loading all assignments:', allErr);
            throw allErr;
        }
        const allPaid = allAssignments.length > 0 && allAssignments.every((row)=>row.fulfilled === true);
        const { error: expErr } = await __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$lib$2f$supabaseServer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"].from('expenses').update({
            fulfilled: allPaid
        }).eq('id', expenseId);
        if (expErr) {
            console.error('Error updating expense.fulfilled:', expErr);
            throw expErr;
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            expenseId,
            fulfilled,
            expenseFulfilled: allPaid
        }, {
            status: 200,
            headers: response.headers
        });
    } catch (err) {
        console.error('PATCH /api/assigned-expenses/[id] error:', err);
        const message = err instanceof Error ? err.message : 'Server error';
        return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: message
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__f1df235c._.js.map