module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/create-profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=c1e43_apps_web__next-internal_server_app_create-profile_page_actions_0e6aa32d.js.map