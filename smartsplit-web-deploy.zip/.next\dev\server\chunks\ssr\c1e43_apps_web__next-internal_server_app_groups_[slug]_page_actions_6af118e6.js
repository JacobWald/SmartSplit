module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/groups/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=c1e43_apps_web__next-internal_server_app_groups_%5Bslug%5D_page_actions_6af118e6.js.map