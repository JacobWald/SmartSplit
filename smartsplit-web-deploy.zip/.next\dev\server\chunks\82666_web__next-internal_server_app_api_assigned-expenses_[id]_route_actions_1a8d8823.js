module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/api/assigned-expenses/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=82666_web__next-internal_server_app_api_assigned-expenses_%5Bid%5D_route_actions_1a8d8823.js.map