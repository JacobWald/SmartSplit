module.exports = [
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "baseCurrency": "GroupDetailPage-module__5v9wha__baseCurrency",
  "confirmDialogButtonPrimary": "GroupDetailPage-module__5v9wha__confirmDialogButtonPrimary",
  "confirmDialogButtonSecondary": "GroupDetailPage-module__5v9wha__confirmDialogButtonSecondary",
  "confirmDialogContent": "GroupDetailPage-module__5v9wha__confirmDialogContent",
  "confirmDialogPaper": "GroupDetailPage-module__5v9wha__confirmDialogPaper",
  "confirmDialogTitle": "GroupDetailPage-module__5v9wha__confirmDialogTitle",
  "createButton": "GroupDetailPage-module__5v9wha__createButton",
  "deleteButton": "GroupDetailPage-module__5v9wha__deleteButton",
  "editButton": "GroupDetailPage-module__5v9wha__editButton",
  "expenseAmount": "GroupDetailPage-module__5v9wha__expenseAmount",
  "expenseAmountBox": "GroupDetailPage-module__5v9wha__expenseAmountBox",
  "expenseCard": "GroupDetailPage-module__5v9wha__expenseCard",
  "expenseCardContent": "GroupDetailPage-module__5v9wha__expenseCardContent",
  "expenseDate": "GroupDetailPage-module__5v9wha__expenseDate",
  "expenseFilterBar": "GroupDetailPage-module__5v9wha__expenseFilterBar",
  "expenseFilterButton": "GroupDetailPage-module__5v9wha__expenseFilterButton",
  "expenseFilterButtonActive": "GroupDetailPage-module__5v9wha__expenseFilterButtonActive",
  "expenseHeader": "GroupDetailPage-module__5v9wha__expenseHeader",
  "expenseNote": "GroupDetailPage-module__5v9wha__expenseNote",
  "expenseStatusPill": "GroupDetailPage-module__5v9wha__expenseStatusPill",
  "expenseStatusPillFulfilled": "GroupDetailPage-module__5v9wha__expenseStatusPillFulfilled",
  "expenseStatusPillUnfulfilled": "GroupDetailPage-module__5v9wha__expenseStatusPillUnfulfilled",
  "expenseTitle": "GroupDetailPage-module__5v9wha__expenseTitle",
  "groupTitle": "GroupDetailPage-module__5v9wha__groupTitle",
  "inputs": "GroupDetailPage-module__5v9wha__inputs",
  "loadingBox": "GroupDetailPage-module__5v9wha__loadingBox",
  "memberActionButton": "GroupDetailPage-module__5v9wha__memberActionButton",
  "memberDeleteButton": "GroupDetailPage-module__5v9wha__memberDeleteButton",
  "memberDivider": "GroupDetailPage-module__5v9wha__memberDivider",
  "memberInfo": "GroupDetailPage-module__5v9wha__memberInfo",
  "memberList": "GroupDetailPage-module__5v9wha__memberList",
  "memberMeta": "GroupDetailPage-module__5v9wha__memberMeta",
  "memberName": "GroupDetailPage-module__5v9wha__memberName",
  "memberRow": "GroupDetailPage-module__5v9wha__memberRow",
  "noExpensesText": "GroupDetailPage-module__5v9wha__noExpensesText",
  "sectionTitle": "GroupDetailPage-module__5v9wha__sectionTitle",
  "splitBox": "GroupDetailPage-module__5v9wha__splitBox",
  "splitCheckbox": "GroupDetailPage-module__5v9wha__splitCheckbox",
  "splitLabel": "GroupDetailPage-module__5v9wha__splitLabel",
  "splitList": "GroupDetailPage-module__5v9wha__splitList",
  "splitName": "GroupDetailPage-module__5v9wha__splitName",
  "splitRow": "GroupDetailPage-module__5v9wha__splitRow",
  "splitValue": "GroupDetailPage-module__5v9wha__splitValue",
});
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GroupMembersSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-ssr] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Typography/Typography.js [app-ssr] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/List/List.js [app-ssr] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/ListItem/ListItem.js [app-ssr] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Divider/Divider.js [app-ssr] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Stack/Stack.js [app-ssr] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Button/Button.js [app-ssr] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Dialog/Dialog.js [app-ssr] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-ssr] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-ssr] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-ssr] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Autocomplete$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-ssr] (ecmascript) <locals> <export default as Autocomplete>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/TextField.js [app-ssr] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Chip/Chip.js [app-ssr] (ecmascript) <export default as Chip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.module.css [app-ssr] (css module)");
'use client';
;
;
;
;
;
function GroupMembersSection({ group, isAdmin, currentUserId, friendProfiles, onGroupUpdated, isReadOnly }) {
    // role-change dialog
    const [roleDialogOpen, setRoleDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [roleDialogMember, setRoleDialogMember] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [roleDialogTargetRole, setRoleDialogTargetRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // delete-member dialog
    const [deleteMemberDialogOpen, setDeleteMemberDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [memberToDelete, setMemberToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingMember, setDeletingMember] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // add-members dialog
    const [addMemberOpen, setAddMemberOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedNewMembers, setSelectedNewMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [addingMembers, setAddingMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [addMemberStatus, setAddMemberStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const openRoleDialog = (member, targetRole)=>{
        if (isReadOnly) return;
        setRoleDialogMember(member);
        setRoleDialogTargetRole(targetRole); // 'MODERATOR' or 'MEMBER'
        setRoleDialogOpen(true);
    };
    const closeRoleDialog = ()=>{
        setRoleDialogOpen(false);
        setRoleDialogMember(null);
        setRoleDialogTargetRole(null);
    };
    const confirmChangeMemberRole = async ()=>{
        const member = roleDialogMember;
        const targetRole = roleDialogTargetRole;
        if (!group?.id || !member || !targetRole) {
            closeRoleDialog();
            return;
        }
        try {
            const res = await fetch('/api/group-members', {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    group_id: group.id,
                    user_id: member.user_id,
                    role: targetRole
                })
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error changing member role:', data.error);
                alert(data.error || 'Failed to change member role');
                return;
            }
            await onGroupUpdated();
        } catch (err) {
            console.error('Error changing member role:', err);
            alert('Error changing member role. Check console.');
        } finally{
            closeRoleDialog();
        }
    };
    const openDeleteMemberDialog = (member)=>{
        if (isReadOnly) return;
        setMemberToDelete(member);
        setDeleteMemberDialogOpen(true);
    };
    const closeDeleteMemberDialog = ()=>{
        setDeleteMemberDialogOpen(false);
        setMemberToDelete(null);
    };
    const confirmDeleteMember = async ()=>{
        if (!memberToDelete?.user_id || !group?.id) {
            closeDeleteMemberDialog();
            return;
        }
        try {
            setDeletingMember(true);
            const res = await fetch('/api/group-members', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    group_id: group.id,
                    user_id: memberToDelete.user_id
                })
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error removing member:', data.error);
                alert(data.error || 'Failed to remove member');
                return;
            }
            await onGroupUpdated();
        } catch (err) {
            console.error('Error removing member:', err);
            alert('Error removing member. Check console.');
        } finally{
            setDeletingMember(false);
            closeDeleteMemberDialog();
        }
    };
    const handleAddMembers = async ()=>{
        if (!group?.id) return;
        const member_ids = [
            ...new Set(selectedNewMembers.map((u)=>u.id).filter(Boolean))
        ];
        if (member_ids.length === 0) {
            setAddMemberStatus('Please select at least one friend to add.');
            return;
        }
        try {
            setAddingMembers(true);
            setAddMemberStatus('Inviting members…');
            const res = await fetch('/api/group-members', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    group_id: group.id,
                    member_ids
                })
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error adding members:', data.error);
                setAddMemberStatus(data.error || 'Failed to add members.');
                return;
            }
            setAddMemberStatus('✅ Invitations sent.');
            await onGroupUpdated();
            setTimeout(()=>{
                setAddMemberOpen(false);
                setSelectedNewMembers([]);
                setAddMemberStatus('');
            }, 600);
        } catch (err) {
            console.error('Error adding members:', err);
            setAddMemberStatus('Error adding members. Check console.');
        } finally{
            setAddingMembers(false);
        }
    };
    const roleDialogTitle = roleDialogTargetRole === 'MODERATOR' ? 'Promote to moderator' : roleDialogTargetRole === 'MEMBER' ? 'Set role to member' : 'Change role';
    const roleDialogMessage = roleDialogMember && roleDialogTargetRole === 'MODERATOR' ? `Promote ${roleDialogMember.full_name} to moderator?` : roleDialogMember && roleDialogTargetRole === 'MEMBER' ? `Set ${roleDialogMember.full_name}'s role back to member?` : '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                sx: {
                    mt: 3,
                    mb: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                        variant: "h6",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sectionTitle,
                        children: "Members"
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 212,
                        columnNumber: 9
                    }, this),
                    !isReadOnly && isAdmin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].createButton,
                        onClick: ()=>{
                            setSelectedNewMembers([]);
                            setAddMemberStatus('');
                            setAddMemberOpen(true);
                        },
                        children: "Add members"
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 217,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                lineNumber: 206,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberList,
                children: group.members.map((m, idx)=>{
                    const isSelf = m.user_id === currentUserId;
                    const canModifyRole = !isReadOnly && isAdmin && m.status === 'ACCEPTED' && !isSelf;
                    const showPromote = canModifyRole && m.role === 'MEMBER';
                    const showDemote = canModifyRole && m.role === 'MODERATOR';
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberInfo,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberName,
                                                children: m.full_name
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                lineNumber: 244,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberMeta,
                                                children: [
                                                    m.role,
                                                    " (",
                                                    m.status,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                lineNumber: 247,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 243,
                                        columnNumber: 17
                                    }, this),
                                    !isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                        direction: "row",
                                        spacing: 1,
                                        children: [
                                            showPromote && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                size: "small",
                                                onClick: ()=>openRoleDialog(m, 'MODERATOR'),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberActionButton,
                                                children: "Promote to moderator"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                lineNumber: 255,
                                                columnNumber: 23
                                            }, this),
                                            showDemote && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                size: "small",
                                                onClick: ()=>openRoleDialog(m, 'MEMBER'),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberActionButton,
                                                children: "Demote to member"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                lineNumber: 265,
                                                columnNumber: 23
                                            }, this),
                                            canModifyRole && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                size: "small",
                                                onClick: ()=>openDeleteMemberDialog(m),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberDeleteButton,
                                                color: "error",
                                                children: "Remove"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                lineNumber: 275,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 253,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 242,
                                columnNumber: 15
                            }, this),
                            idx < group.members.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberDivider
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 288,
                                columnNumber: 17
                            }, this)
                        ]
                    }, m.user_id, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 241,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                lineNumber: 231,
                columnNumber: 7
            }, this),
            !isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                        open: roleDialogOpen,
                        onClose: closeRoleDialog,
                        fullWidth: true,
                        maxWidth: "xs",
                        slotProps: {
                            paper: {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogPaper
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogTitle,
                                children: roleDialogTitle
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 306,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogContent,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    children: roleDialogMessage
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                    lineNumber: 310,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 309,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: closeRoleDialog,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonSecondary,
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 313,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: confirmChangeMemberRole,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonPrimary,
                                        children: "Confirm"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 319,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 312,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 299,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                        open: deleteMemberDialogOpen,
                        onClose: closeDeleteMemberDialog,
                        fullWidth: true,
                        maxWidth: "xs",
                        slotProps: {
                            paper: {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogPaper
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogTitle,
                                children: "Remove member"
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 336,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogContent,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    children: memberToDelete ? `Remove ${memberToDelete.full_name} from this group? They must not be part of any outstanding expenses.` : ''
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                    lineNumber: 340,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 339,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: closeDeleteMemberDialog,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonSecondary,
                                        disabled: deletingMember,
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 347,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: confirmDeleteMember,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonPrimary,
                                        color: "error",
                                        disabled: deletingMember,
                                        children: deletingMember ? 'Removing…' : 'Remove'
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 354,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 346,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 329,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                        open: addMemberOpen,
                        onClose: ()=>!addingMembers && setAddMemberOpen(false),
                        fullWidth: true,
                        maxWidth: "sm",
                        slotProps: {
                            paper: {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogPaper
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogTitle,
                                children: [
                                    "Add members to ",
                                    group.name
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 373,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogContent,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                    spacing: 2,
                                    sx: {
                                        mt: 1
                                    },
                                    children: [
                                        friendProfiles.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "body2",
                                            children: "You don't have any friends to add yet. Add friends from the profile page first."
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                            lineNumber: 379,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    variant: "body2",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dialogueText,
                                                    children: [
                                                        "Invite additional friends to this group. They'll appear with status ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                            children: "INVITED"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                            lineNumber: 390,
                                                            columnNumber: 42
                                                        }, this),
                                                        " until they accept."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                    lineNumber: 385,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Autocomplete$3e$__["Autocomplete"], {
                                                    multiple: true,
                                                    options: friendProfiles.filter((f)=>!(group.members || []).some((m)=>m.user_id === f.id)),
                                                    getOptionLabel: (u)=>u?.username ?? '',
                                                    value: selectedNewMembers,
                                                    onChange: (_, newValue)=>setSelectedNewMembers(newValue),
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputs,
                                                    slotProps: {
                                                        paper: {
                                                            sx: {
                                                                backgroundColor: 'var(--color-bg)',
                                                                color: 'var(--color-primary)',
                                                                borderRadius: '12px',
                                                                boxShadow: '0px 6px 20px rgba(0,0,0,0.25)'
                                                            }
                                                        },
                                                        listbox: {
                                                            sx: {
                                                                '& .MuiAutocomplete-option': {
                                                                    '&:hover': {
                                                                        backgroundColor: 'rgba(255,255,255,0.06)'
                                                                    },
                                                                    '&[aria-selected="true"]': {
                                                                        backgroundColor: 'rgba(255,255,255,0.12)'
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    },
                                                    renderTags: (value, getTagProps)=>value.map((option, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Chip$3e$__["Chip"], {
                                                                ...getTagProps({
                                                                    index
                                                                }),
                                                                key: option.id,
                                                                label: option.username,
                                                                sx: {
                                                                    backgroundColor: 'var(--color-bg)',
                                                                    color: 'var(--color-primary)',
                                                                    border: '1px solid var(--color-primary)'
                                                                },
                                                                __source: {
                                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                                    lineNumber: 432,
                                                                    columnNumber: 27
                                                                }
                                                            })),
                                                    renderInput: (params)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                                            ...params,
                                                            label: "Add members (friends only)",
                                                            placeholder: "Type a name…"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                            lineNumber: 445,
                                                            columnNumber: 25
                                                        }, void 0)
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                                    lineNumber: 394,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true),
                                        addMemberStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            variant: "body2",
                                            sx: {
                                                mt: 1
                                            },
                                            children: addMemberStatus
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                            lineNumber: 456,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                    lineNumber: 377,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 376,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: ()=>setAddMemberOpen(false),
                                        disabled: addingMembers,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonSecondary,
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 463,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: handleAddMembers,
                                        disabled: addingMembers || selectedNewMembers.length === 0 || friendProfiles.length === 0,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonPrimary,
                                        children: addingMembers ? 'Adding…' : 'Add'
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                        lineNumber: 470,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                                lineNumber: 462,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js",
                        lineNumber: 366,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true);
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "customAmountField": "AddExpenseDialog-module__MmI2FG__customAmountField",
  "dialogButton": "AddExpenseDialog-module__MmI2FG__dialogButton",
  "dialogContent": "AddExpenseDialog-module__MmI2FG__dialogContent",
  "dialogPaper": "AddExpenseDialog-module__MmI2FG__dialogPaper",
  "dialogTitle": "AddExpenseDialog-module__MmI2FG__dialogTitle",
  "helperText": "AddExpenseDialog-module__MmI2FG__helperText",
  "inputs": "AddExpenseDialog-module__MmI2FG__inputs",
  "memberLabel": "AddExpenseDialog-module__MmI2FG__memberLabel",
  "memberRow": "AddExpenseDialog-module__MmI2FG__memberRow",
  "splitMethodLabel": "AddExpenseDialog-module__MmI2FG__splitMethodLabel",
});
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AddExpenseDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Dialog/Dialog.js [app-ssr] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-ssr] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-ssr] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-ssr] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Button/Button.js [app-ssr] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/TextField.js [app-ssr] (ecmascript) <export default as TextField>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-ssr] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-ssr] (ecmascript) <export default as FormControlLabel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$RadioGroup$2f$RadioGroup$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__RadioGroup$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/RadioGroup/RadioGroup.js [app-ssr] (ecmascript) <export default as RadioGroup>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$Radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Radio/Radio.js [app-ssr] (ecmascript) <export default as Radio>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Stack/Stack.js [app-ssr] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
function AddExpenseDialog({ open, onClose, members = [], onSubmit, loading = false, groupName = "", mode = "create", expense = null }) {
    const isEdit = mode === "edit";
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [amount, setAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [note, setNote] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [splitMethod, setSplitMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("equal");
    const [selectedMembers, setSelectedMembers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [customAmounts, setCustomAmounts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const acceptedMembers = members.filter((m)=>m.status === "ACCEPTED");
    // ----------------------------------------------------
    // LOAD EXISTING DATA WHEN EDITING
    // ----------------------------------------------------
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!open) return; // only load when dialog opens
        if (isEdit && expense) {
            setTitle(expense.title);
            setAmount(String(expense.amount));
            setNote(expense.note || "");
            const assigned = expense.assigned || [];
            // Determine split method
            const hasCustom = assigned.some((a)=>a.amount !== null);
            setSplitMethod(hasCustom ? "custom" : "equal");
            const memberIds = assigned.map((a)=>a.user_id);
            setSelectedMembers(memberIds);
            const amountsMap = {};
            assigned.forEach((a)=>{
                amountsMap[a.user_id] = a.amount !== null ? String(a.amount) : "";
            });
            setCustomAmounts(amountsMap);
        } else {
            // Reset for CREATE
            setTitle("");
            setAmount("");
            setNote("");
            setSplitMethod("equal");
            setSelectedMembers(acceptedMembers.map((m)=>m.user_id));
            setCustomAmounts({});
        }
    }, [
        open,
        isEdit,
        expense,
        members
    ]);
    const handleToggleMember = (id)=>{
        if (selectedMembers.includes(id)) {
            setSelectedMembers(selectedMembers.filter((m)=>m !== id));
        } else {
            setSelectedMembers([
                ...selectedMembers,
                id
            ]);
        }
    };
    const handleCustomAmountChange = (userId, val)=>{
        setCustomAmounts({
            ...customAmounts,
            [userId]: val
        });
    };
    // ----------------------------------------------------
    // SAVE (Create or Edit)
    // ----------------------------------------------------
    const handleSave = ()=>{
        setError("");
        if (!title.trim()) return setError("Title is required");
        if (!amount || Number(amount) <= 0) return setError("Amount must be greater than 0");
        if (selectedMembers.length === 0) return setError("Select at least one member");
        const total = Number(amount);
        // Custom split must sum correctly
        if (splitMethod === "custom") {
            let sum = 0;
            selectedMembers.forEach((id)=>{
                const val = parseFloat(customAmounts[id] || 0);
                sum += isNaN(val) ? 0 : val;
            });
            if (Math.round(sum * 100) !== Math.round(total * 100)) {
                return setError("Custom amounts must add up exactly to the total.");
            }
        }
        // ---------------------- PAYLOAD ----------------------
        const payload = {
            mode,
            id: isEdit ? expense.id : undefined,
            title,
            amount: total,
            note,
            assigned: selectedMembers.map((uid)=>({
                    user_id: uid,
                    amount: splitMethod === "custom" ? Number(customAmounts[uid] || 0) : Number(total / selectedMembers.length)
                }))
        };
        onSubmit(payload);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
        open: open,
        onClose: ()=>!loading ? onClose() : null,
        fullWidth: true,
        maxWidth: "sm",
        classes: {
            paper: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dialogPaper
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dialogTitle,
                children: isEdit ? "Edit Expense" : `Add Expense for ${groupName}`
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                lineNumber: 150,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dialogContent,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            label: "Title *",
                            value: title,
                            onChange: (e)=>setTitle(e.target.value),
                            fullWidth: true
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 156,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            label: "Amount *",
                            type: "number",
                            value: amount,
                            onChange: (e)=>setAmount(e.target.value),
                            fullWidth: true
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 163,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                            label: "Note (optional)",
                            value: note,
                            onChange: (e)=>setNote(e.target.value),
                            fullWidth: true,
                            multiline: true,
                            minRows: 2
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitMethodLabel,
                            children: "Split method"
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 180,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$RadioGroup$2f$RadioGroup$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__RadioGroup$3e$__["RadioGroup"], {
                            row: true,
                            value: splitMethod,
                            onChange: (e)=>setSplitMethod(e.target.value),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
                                    value: "equal",
                                    control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$Radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"], {}, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                        lineNumber: 189,
                                        columnNumber: 24
                                    }, void 0),
                                    label: "Split equally"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                    lineNumber: 187,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
                                    value: "custom",
                                    control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$Radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"], {}, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                        lineNumber: 194,
                                        columnNumber: 24
                                    }, void 0),
                                    label: "Custom amounts"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                    lineNumber: 192,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 182,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitMethodLabel,
                            children: "Members responsible"
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 199,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].helperText,
                            children: [
                                "Select members included in this expense.",
                                splitMethod === "custom" ? " Enter individual amounts below." : ""
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 201,
                            columnNumber: 11
                        }, this),
                        acceptedMembers.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].memberRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FormControlLabel$3e$__["FormControlLabel"], {
                                        control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                            checked: selectedMembers.includes(m.user_id),
                                            onChange: ()=>handleToggleMember(m.user_id)
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                            lineNumber: 212,
                                            columnNumber: 19
                                        }, void 0),
                                        label: `${m.full_name} — ${m.status}`
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                        lineNumber: 210,
                                        columnNumber: 15
                                    }, this),
                                    splitMethod === "custom" && selectedMembers.includes(m.user_id) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TextField$3e$__["TextField"], {
                                        type: "number",
                                        placeholder: "Amount",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].customAmountField,
                                        value: customAmounts[m.user_id] || "",
                                        onChange: (e)=>handleCustomAmountChange(m.user_id, e.target.value)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                        lineNumber: 222,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, m.user_id, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                                lineNumber: 209,
                                columnNumber: 13
                            }, this)),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "red",
                                fontWeight: 600
                            },
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                            lineNumber: 239,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                    lineNumber: 155,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: onClose,
                        disabled: loading,
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        onClick: handleSave,
                        disabled: loading,
                        children: isEdit ? "Save Changes" : "Save Expense"
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                        lineNumber: 251,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
                lineNumber: 246,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js",
        lineNumber: 143,
        columnNumber: 5
    }, this);
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExpensesSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-ssr] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Typography/Typography.js [app-ssr] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Stack/Stack.js [app-ssr] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Button/Button.js [app-ssr] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/Card.js [app-ssr] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/CardContent.js [app-ssr] (ecmascript) <export default as CardContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/List/List.js [app-ssr] (ecmascript) <export default as List>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/ListItem/ListItem.js [app-ssr] (ecmascript) <export default as ListItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-ssr] (ecmascript) <export default as Checkbox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Dialog/Dialog.js [app-ssr] (ecmascript) <export default as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-ssr] (ecmascript) <export default as DialogTitle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-ssr] (ecmascript) <export default as DialogContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-ssr] (ecmascript) <export default as DialogActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/components/AddExpenseDialog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.module.css [app-ssr] (css module)");
'use client';
;
;
;
;
;
function ExpensesSection({ group, expenses, expenseFilter, setExpenseFilter, isAdmin, isModerator, currentUserId, onExpensesUpdated, memberNameFor, formatDate, isReadOnly }) {
    const [expenseOpen, setExpenseOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [savingExpense, setSavingExpense] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editingExpense, setEditingExpense] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [togglingAssignmentId, setTogglingAssignmentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deleteExpenseDialogOpen, setDeleteExpenseDialogOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [expenseToDelete, setExpenseToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingExpense, setDeletingExpense] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const canManageExpenses = !isReadOnly && (isAdmin || isModerator);
    const filteredExpenses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!Array.isArray(expenses)) return [];
        if (expenseFilter === 'fulfilled') {
            return expenses.filter((exp)=>exp.fulfilled === true);
        }
        return expenses.filter((exp)=>exp.fulfilled !== true);
    }, [
        expenses,
        expenseFilter
    ]);
    const canToggleAssignment = (assignmentUserId)=>{
        if (isReadOnly) return false;
        if (!currentUserId) return false;
        if (isAdmin || isModerator) return true;
        return assignmentUserId === currentUserId;
    };
    const openCreateExpense = ()=>{
        if (isReadOnly) return;
        setEditingExpense(null);
        setExpenseOpen(true);
    };
    const openEditExpense = (expense)=>{
        if (isReadOnly) return;
        setEditingExpense(expense);
        setExpenseOpen(true);
    };
    const handleExpenseSubmit = async ({ title, amount, assigned, note })=>{
        if (!group?.id || !currentUserId) {
            console.error('Missing group id or current user id');
            return;
        }
        try {
            setSavingExpense(true);
            const isEdit = !!editingExpense;
            const endpoint = isEdit ? `/api/expenses/${editingExpense.id}` : '/api/expenses';
            const method = isEdit ? 'PUT' : 'POST';
            const res = await fetch(endpoint, {
                method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    title,
                    amount,
                    group_id: group.id,
                    payer_id: currentUserId,
                    assigned,
                    note
                })
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error saving expense:', data.error);
                alert(data.error || 'Failed to save expense');
                return;
            }
            await onExpensesUpdated();
            setExpenseOpen(false);
            setEditingExpense(null);
        } catch (err) {
            console.error('Error saving expense:', err);
            alert('Error saving expense. Check console.');
        } finally{
            setSavingExpense(false);
        }
    };
    const handleToggleAssignedFulfilled = async (expenseId, assignment)=>{
        if (!assignment?.id) return;
        if (!canToggleAssignment(assignment.user_id)) return;
        try {
            setTogglingAssignmentId(assignment.id);
            const res = await fetch(`/api/assigned-expenses/${assignment.id}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    fulfilled: !assignment.fulfilled
                })
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error updating payment status:', data.error);
                alert(data.error || 'Failed to update payment status');
                return;
            }
            await onExpensesUpdated();
        } catch (err) {
            console.error('Error updating payment status:', err);
            alert('Error updating payment status. Check console.');
        } finally{
            setTogglingAssignmentId(null);
        }
    };
    const openDeleteExpenseDialog = (expense)=>{
        if (isReadOnly) return;
        setExpenseToDelete(expense);
        setDeleteExpenseDialogOpen(true);
    };
    const closeDeleteExpenseDialog = ()=>{
        setDeleteExpenseDialogOpen(false);
        setExpenseToDelete(null);
    };
    const confirmDeleteExpense = async ()=>{
        if (!expenseToDelete?.id) {
            closeDeleteExpenseDialog();
            return;
        }
        try {
            setDeletingExpense(true);
            const res = await fetch(`/api/expenses/${expenseToDelete.id}`, {
                method: 'DELETE'
            });
            const data = await res.json();
            if (!res.ok) {
                console.error('Error deleting expense:', data.error);
                alert(data.error || 'Failed to delete expense');
                return;
            }
            await onExpensesUpdated();
        } catch (err) {
            console.error('Error deleting expense:', err);
            alert('Error deleting expense. Check console.');
        } finally{
            setDeletingExpense(false);
            closeDeleteExpenseDialog();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "h6",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sectionTitle,
                children: "Expenses"
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                lineNumber: 194,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                sx: {
                    mt: 3,
                    mb: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterBar,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: expenseFilter === 'unfulfilled' ? `${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButton} ${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButtonActive}` : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButton,
                                onClick: ()=>setExpenseFilter('unfulfilled'),
                                children: "Outstanding"
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                lineNumber: 204,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: expenseFilter === 'fulfilled' ? `${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButton} ${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButtonActive}` : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseFilterButton,
                                onClick: ()=>setExpenseFilter('fulfilled'),
                                children: "Fulfilled"
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                lineNumber: 216,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    canManageExpenses && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].createButton,
                        onClick: openCreateExpense,
                        children: "Add Expense"
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                        lineNumber: 230,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                lineNumber: 197,
                columnNumber: 7
            }, this),
            filteredExpenses.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "body2",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].noExpensesText,
                children: expenseFilter === 'fulfilled' ? 'No fulfilled expenses yet.' : 'No outstanding expenses 🎉'
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                lineNumber: 237,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                spacing: 2,
                sx: {
                    mt: 1
                },
                children: filteredExpenses.map((expense)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseCard,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CardContent$3e$__["CardContent"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseCardContent,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    alignItems: "flex-start",
                                    spacing: 2,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseHeader,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                    sx: {
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '0.5rem'
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseTitle,
                                                            children: expense.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 262,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseStatusPill} ${expense.fulfilled ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseStatusPillFulfilled : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseStatusPillUnfulfilled}`,
                                                            children: expense.fulfilled ? 'Fulfilled' : 'Outstanding'
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 265,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 255,
                                                    columnNumber: 21
                                                }, this),
                                                expense.occurred_at && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseDate,
                                                    children: formatDate(expense.occurred_at)
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 276,
                                                    columnNumber: 23
                                                }, this),
                                                expense.note && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseNote,
                                                    children: expense.note
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 281,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                            lineNumber: 254,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseAmountBox,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].expenseAmount,
                                                    children: [
                                                        Number(expense.amount).toFixed(2),
                                                        ' ',
                                                        group.base_currency
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 288,
                                                    columnNumber: 21
                                                }, this),
                                                !isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                                                    direction: "row",
                                                    spacing: 1,
                                                    children: [
                                                        canManageExpenses && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                            size: "small",
                                                            onClick: ()=>openEditExpense(expense),
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].editButton,
                                                            children: "Edit"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 296,
                                                            columnNumber: 27
                                                        }, this),
                                                        isAdmin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                            size: "small",
                                                            onClick: ()=>openDeleteExpenseDialog(expense),
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].deleteButton,
                                                            color: "error",
                                                            children: "Delete"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 306,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 294,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                            lineNumber: 287,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                    lineNumber: 247,
                                    columnNumber: 17
                                }, this),
                                expense.assigned && expense.assigned.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitBox,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitLabel,
                                            children: "Split between:"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                            lineNumber: 322,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__List$3e$__["List"], {
                                            dense: true,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitList,
                                            children: expense.assigned.map((ae)=>{
                                                const canToggle = canToggleAssignment(ae.user_id);
                                                const loading = togglingAssignmentId === ae.id;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItem$2f$ListItem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListItem$3e$__["ListItem"], {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitRow,
                                                    children: [
                                                        !isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Checkbox$3e$__["Checkbox"], {
                                                            size: "small",
                                                            checked: !!ae.fulfilled,
                                                            onChange: ()=>handleToggleAssignedFulfilled(expense.id, ae),
                                                            disabled: !canToggle || loading,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitCheckbox
                                                        }, void 0, false, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 338,
                                                            columnNumber: 31
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                                            sx: {
                                                                display: 'flex',
                                                                justifyContent: 'space-between',
                                                                alignItems: 'center',
                                                                flex: 1,
                                                                gap: '1rem'
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitName,
                                                                    children: memberNameFor(ae.user_id)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                                    lineNumber: 361,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].splitValue,
                                                                    children: [
                                                                        ae.amount != null ? `$${Number(ae.amount).toFixed(2)}` : null,
                                                                        ae.percent != null ? `${Number(ae.percent).toFixed(2)}%` : null,
                                                                        ae.ratio_part != null ? `ratio ${Number(ae.ratio_part)}` : null
                                                                    ].filter(Boolean).join(' • ') || '-'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                                    lineNumber: 364,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                            lineNumber: 352,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, ae.id, true, {
                                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                                    lineNumber: 332,
                                                    columnNumber: 27
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                            lineNumber: 325,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                    lineNumber: 321,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                            lineNumber: 246,
                            columnNumber: 15
                        }, this)
                    }, expense.id, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                        lineNumber: 245,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                lineNumber: 243,
                columnNumber: 9
            }, this),
            !isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Dialog$3e$__["Dialog"], {
                        open: deleteExpenseDialogOpen,
                        onClose: closeDeleteExpenseDialog,
                        fullWidth: true,
                        maxWidth: "xs",
                        slotProps: {
                            paper: {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogPaper
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogTitle$3e$__["DialogTitle"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogTitle,
                                children: "Delete expense"
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                lineNumber: 403,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogContent$3e$__["DialogContent"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogContent,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                                    children: expenseToDelete ? `Are you sure you want to delete "${expenseToDelete.title}"? This action cannot be undone.` : ''
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                    lineNumber: 407,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                lineNumber: 406,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DialogActions$3e$__["DialogActions"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: closeDeleteExpenseDialog,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonSecondary,
                                        disabled: deletingExpense,
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                        lineNumber: 414,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: confirmDeleteExpense,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].confirmDialogButtonPrimary,
                                        color: "error",
                                        disabled: deletingExpense,
                                        children: deletingExpense ? 'Deleting…' : 'Delete'
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                        lineNumber: 421,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                                lineNumber: 413,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                        lineNumber: 396,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$components$2f$AddExpenseDialog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        open: expenseOpen,
                        onClose: ()=>{
                            setExpenseOpen(false);
                            setEditingExpense(null);
                        },
                        members: group.members,
                        onSubmit: handleExpenseSubmit,
                        loading: savingExpense,
                        groupName: group.name,
                        mode: editingExpense ? 'edit' : 'create',
                        expense: editingExpense
                    }, void 0, false, {
                        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js",
                        lineNumber: 433,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true);
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GroupDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-ssr] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Typography/Typography.js [app-ssr] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircularProgress$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-ssr] (ecmascript) <export default as CircularProgress>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Stack/Stack.js [app-ssr] (ecmascript) <export default as Stack>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$MembersSection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/MembersSection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$ExpensesSection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/ExpensesSection.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
/* ------------------------------------------------------
   Helper: Convert slug to the real group UUID
   ------------------------------------------------------ */ const decodeSlug = (value)=>{
    if (!value) return null;
    // If slug IS a UUID → use it directly
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (uuidRegex.test(value)) return value;
    // Otherwise: NOT supported for now (only UUID slugs allowed)
    console.warn('Slug is not a UUID — ignoring:', value);
    return null;
};
function GroupDetailPage() {
    const { slug } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    // Convert slug to ID
    const groupId = decodeSlug(slug);
    const [group, setGroup] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [expenses, setExpenses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [friendProfiles, setFriendProfiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [expenseFilter, setExpenseFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('unfulfilled');
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const parseJSON = async (res)=>{
        if (!res.ok) return null;
        const text = await res.text();
        return text ? JSON.parse(text) : null;
    };
    /* ------------------------------------------------------
     Load group + expenses + current user
     ------------------------------------------------------ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!groupId) {
            setLoading(false);
            setError('Invalid group ID.');
            return;
        }
        (async ()=>{
            try {
                setLoading(true);
                setError('');
                const [gRes, eRes, meRes] = await Promise.all([
                    fetch(`/api/groups?groupId=${encodeURIComponent(groupId)}`),
                    fetch(`/api/expenses?groupId=${encodeURIComponent(groupId)}`),
                    fetch('/api/auth/me')
                ]);
                const [g, e, me] = await Promise.all([
                    parseJSON(gRes),
                    parseJSON(eRes),
                    parseJSON(meRes)
                ]);
                const groupObj = Array.isArray(g) ? g[0] : g;
                if (!groupObj) {
                    setGroup(null);
                    setExpenses([]);
                    return;
                }
                if (me?.id) {
                    groupObj.currentUserId = me.id;
                }
                setGroup(groupObj);
                setExpenses(Array.isArray(e) ? e : []);
            } catch (err) {
                console.error(err);
                setError(err.message || 'Failed to load group');
            } finally{
                setLoading(false);
            }
        })();
    }, [
        groupId
    ]);
    /* ------------------------------------------------------
     Load friend profiles
     ------------------------------------------------------ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!group?.currentUserId) {
            setFriendProfiles([]);
            return;
        }
        (async ()=>{
            try {
                const friendId = group.currentUserId;
                const fRes = await fetch(`/api/friends?friendId=${friendId}`);
                const f = await parseJSON(fRes);
                setFriendProfiles(Array.isArray(f) ? f : []);
            } catch (err) {
                console.error('Failed to load friend profiles:', err);
                setFriendProfiles([]);
            }
        })();
    }, [
        group?.currentUserId
    ]);
    /* ------------------------------------------------------
     Role + helper utilities
     ------------------------------------------------------ */ const currentMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!group?.members || !group.currentUserId) return null;
        return group.members.find((m)=>m.user_id === group.currentUserId) ?? null;
    }, [
        group
    ]);
    const currentRole = currentMember?.role ?? null;
    const isAdmin = currentRole === 'ADMIN';
    const isModerator = currentRole === 'MODERATOR';
    const isReadOnly = group?.active === false;
    const formatDate = (dateString)=>{
        if (!dateString) return '';
        const d = new Date(dateString);
        if (Number.isNaN(d.getTime())) return '';
        return d.toLocaleDateString();
    };
    const memberNameFor = (userId)=>{
        if (!group?.members) return 'Unknown user';
        const m = group.members.find((mem)=>mem.user_id === userId);
        return m?.full_name || 'Unknown user';
    };
    /* ------------------------------------------------------
     Refresh helpers
     ------------------------------------------------------ */ const reloadGroup = async ()=>{
        try {
            const gRes = await fetch(`/api/groups?groupId=${encodeURIComponent(groupId)}`);
            const g = await parseJSON(gRes);
            const groupObj = Array.isArray(g) ? g[0] : g;
            if (groupObj && group?.currentUserId) {
                groupObj.currentUserId = group.currentUserId;
            }
            setGroup(groupObj);
        } catch (err) {
            console.error('Failed to reload group:', err);
        }
    };
    const reloadExpenses = async ()=>{
        if (!groupId) return;
        try {
            const eRes = await fetch(`/api/expenses?groupId=${encodeURIComponent(groupId)}`);
            const e = await parseJSON(eRes);
            setExpenses(Array.isArray(e) ? e : []);
        } catch (err) {
            console.error('Failed to reload expenses:', err);
        }
    };
    /* ------------------------------------------------------
     UI Rendering
     ------------------------------------------------------ */ if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingBox,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircularProgress$3e$__["CircularProgress"], {}, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                lineNumber: 182,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
            lineNumber: 181,
            columnNumber: 7
        }, this);
    }
    if (error || !group) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
            sx: {
                p: 4,
                textAlign: 'center'
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                variant: "h5",
                color: "error",
                children: error || 'Group not found.'
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                lineNumber: 190,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
            lineNumber: 189,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
        sx: {
            p: 4
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Stack$3e$__["Stack"], {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                sx: {
                    mb: 2
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "h4",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].groupTitle,
                            children: group.name
                        }, void 0, false, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                            lineNumber: 207,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].baseCurrency,
                            children: [
                                "Base Currency: ",
                                group.base_currency
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                            lineNumber: 210,
                            columnNumber: 11
                        }, this),
                        isReadOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"], {
                            variant: "body2",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$GroupDetailPage$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].readOnlyNotice,
                            sx: {
                                mt: 0.5
                            },
                            children: [
                                "This group is ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "inactive"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                                    lineNumber: 219,
                                    columnNumber: 29
                                }, this),
                                ". Details are read-only."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                            lineNumber: 214,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                    lineNumber: 206,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                lineNumber: 200,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$MembersSection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                group: group,
                isAdmin: isAdmin,
                currentUserId: group.currentUserId,
                friendProfiles: friendProfiles,
                onGroupUpdated: reloadGroup,
                isReadOnly: isReadOnly
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                lineNumber: 226,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$apps$2f$web$2f$pages$2f$GroupDetailPage$2f$ExpensesSection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                group: group,
                expenses: expenses,
                expenseFilter: expenseFilter,
                setExpenseFilter: setExpenseFilter,
                isAdmin: isAdmin,
                isModerator: isModerator,
                currentUserId: group.currentUserId,
                onExpensesUpdated: reloadExpenses,
                memberNameFor: memberNameFor,
                formatDate: formatDate,
                isReadOnly: isReadOnly
            }, void 0, false, {
                fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
                lineNumber: 236,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/UMich/CIS525/SmartSplit/apps/web/pages/GroupDetailPage/GroupDetailPage.js",
        lineNumber: 198,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__116ba8a9._.js.map