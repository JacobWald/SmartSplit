globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/9bdb1_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_47d3ac2b._.js",
    "static/chunks/9bdb1_next_dist_compiled_react-dom_27f48162._.js",
    "static/chunks/9bdb1_next_dist_compiled_react-server-dom-turbopack_6fb7899e._.js",
    "static/chunks/9bdb1_next_dist_compiled_next-devtools_index_d16dccfb.js",
    "static/chunks/9bdb1_next_dist_compiled_d3fad37c._.js",
    "static/chunks/9bdb1_next_dist_client_f51cd215._.js",
    "static/chunks/9bdb1_next_dist_c727b70a._.js",
    "static/chunks/9bdb1_@swc_helpers_cjs_2769ecf2._.js",
    "static/chunks/Documents_UMich_CIS525_SmartSplit_apps_web_a0ff3932._.js",
    "static/chunks/turbopack-Documents_UMich_CIS525_SmartSplit_apps_web_239df48b._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];