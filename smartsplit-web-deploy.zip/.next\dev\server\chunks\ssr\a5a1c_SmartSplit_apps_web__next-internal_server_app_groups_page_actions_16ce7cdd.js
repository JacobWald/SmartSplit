module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/groups/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=a5a1c_SmartSplit_apps_web__next-internal_server_app_groups_page_actions_16ce7cdd.js.map