(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useThemeProps/getThemeProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getThemeProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$resolveProps$2f$resolveProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/resolveProps/resolveProps.js [app-client] (ecmascript)");
;
function getThemeProps(params) {
    const { theme, name, props } = params;
    if (!theme || !theme.components || !theme.components[name] || !theme.components[name].defaultProps) {
        return props;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$resolveProps$2f$resolveProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theme.components[name].defaultProps, props);
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useThemeProps/useThemeProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useThemeProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$getThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useThemeProps/getThemeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useTheme$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useTheme/useTheme.js [app-client] (ecmascript)");
'use client';
;
;
function useThemeProps({ props, name, defaultTheme, themeId }) {
    let theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useTheme$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(defaultTheme);
    if (themeId) {
        theme = theme[themeId] || theme;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$getThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        theme,
        name,
        props
    });
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/styled/styled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createStyled$2f$createStyled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createStyled/createStyled.js [app-client] (ecmascript)");
;
const styled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createStyled$2f$createStyled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
const __TURBOPACK__default__export__ = styled;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/Container/createContainer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>createContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$capitalize$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/capitalize/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$useThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useThemeProps/useThemeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styled$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/styled/styled.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createTheme$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createTheme/createTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
const defaultTheme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createTheme$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
const defaultCreateStyledComponent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styled$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('div', {
    name: 'MuiContainer',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            styles[`maxWidth${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$capitalize$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(String(ownerState.maxWidth))}`],
            ownerState.fixed && styles.fixed,
            ownerState.disableGutters && styles.disableGutters
        ];
    }
});
const useThemePropsDefault = (inProps)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$useThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props: inProps,
        name: 'MuiContainer',
        defaultTheme
    });
const useUtilityClasses = (ownerState, componentName)=>{
    const getContainerUtilityClass = (slot)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(componentName, slot);
    };
    const { classes, fixed, disableGutters, maxWidth } = ownerState;
    const slots = {
        root: [
            'root',
            maxWidth && `maxWidth${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$capitalize$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(String(maxWidth))}`,
            fixed && 'fixed',
            disableGutters && 'disableGutters'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, getContainerUtilityClass, classes);
};
function createContainer(options = {}) {
    const { // This will allow adding custom styled fn (for example for custom sx style function)
    createStyledComponent = defaultCreateStyledComponent, useThemeProps = useThemePropsDefault, componentName = 'MuiContainer' } = options;
    const ContainerRoot = createStyledComponent(({ theme, ownerState })=>({
            width: '100%',
            marginLeft: 'auto',
            boxSizing: 'border-box',
            marginRight: 'auto',
            ...!ownerState.disableGutters && {
                paddingLeft: theme.spacing(2),
                paddingRight: theme.spacing(2),
                // @ts-ignore module augmentation fails if custom breakpoints are used
                [theme.breakpoints.up('sm')]: {
                    paddingLeft: theme.spacing(3),
                    paddingRight: theme.spacing(3)
                }
            }
        }), ({ theme, ownerState })=>ownerState.fixed && Object.keys(theme.breakpoints.values).reduce((acc, breakpointValueKey)=>{
            const breakpoint = breakpointValueKey;
            const value = theme.breakpoints.values[breakpoint];
            if (value !== 0) {
                // @ts-ignore
                acc[theme.breakpoints.up(breakpoint)] = {
                    maxWidth: `${value}${theme.breakpoints.unit}`
                };
            }
            return acc;
        }, {}), ({ theme, ownerState })=>({
            // @ts-ignore module augmentation fails if custom breakpoints are used
            ...ownerState.maxWidth === 'xs' && {
                // @ts-ignore module augmentation fails if custom breakpoints are used
                [theme.breakpoints.up('xs')]: {
                    // @ts-ignore module augmentation fails if custom breakpoints are used
                    maxWidth: Math.max(theme.breakpoints.values.xs, 444)
                }
            },
            ...ownerState.maxWidth && // @ts-ignore module augmentation fails if custom breakpoints are used
            ownerState.maxWidth !== 'xs' && {
                // @ts-ignore module augmentation fails if custom breakpoints are used
                [theme.breakpoints.up(ownerState.maxWidth)]: {
                    // @ts-ignore module augmentation fails if custom breakpoints are used
                    maxWidth: `${theme.breakpoints.values[ownerState.maxWidth]}${theme.breakpoints.unit}`
                }
            }
        }));
    const Container = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Container(inProps, ref) {
        const props = useThemeProps(inProps);
        const { className, component = 'div', disableGutters = false, fixed = false, maxWidth = 'lg', classes: classesProp, ...other } = props;
        const ownerState = {
            ...props,
            component,
            disableGutters,
            fixed,
            maxWidth
        };
        // @ts-ignore module augmentation fails if custom breakpoints are used
        const classes = useUtilityClasses(ownerState, componentName);
        return(/*#__PURE__*/ // @ts-ignore theme is injected by the styled util
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContainerRoot, {
            as: component,
            ownerState: ownerState,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
            ref: ref,
            ...other
        }));
    });
    ("TURBOPACK compile-time truthy", 1) ? Container.propTypes = {
        children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
        classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        disableGutters: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        fixed: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        maxWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
                'xs',
                'sm',
                'md',
                'lg',
                'xl',
                false
            ]),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
        ]),
        sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
                __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
                __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
                __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
            ])),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ])
    } : "TURBOPACK unreachable";
    return Container;
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/Container/createContainer.js [app-client] (ecmascript) <export default as createContainer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createContainer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$Container$2f$createContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$Container$2f$createContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/Container/createContainer.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Container/Container.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$Container$2f$createContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createContainer$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/Container/createContainer.js [app-client] (ecmascript) <export default as createContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const Container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$Container$2f$createContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createContainer$3e$__["createContainer"])({
    createStyledComponent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])('div', {
        name: 'MuiContainer',
        slot: 'Root',
        overridesResolver: (props, styles)=>{
            const { ownerState } = props;
            return [
                styles.root,
                styles[`maxWidth${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(String(ownerState.maxWidth))}`],
                ownerState.fixed && styles.fixed,
                ownerState.disableGutters && styles.disableGutters
            ];
        }
    }),
    useThemeProps: (inProps)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
            props: inProps,
            name: 'MuiContainer'
        })
});
("TURBOPACK compile-time truthy", 1) ? Container.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * @ignore
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * If `true`, the left and right padding is removed.
   * @default false
   */ disableGutters: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Set the max-width to match the min-width of the current breakpoint.
   * This is useful if you'd prefer to design for a fixed set of sizes
   * instead of trying to accommodate a fully fluid viewport.
   * It's fluid by default.
   * @default false
   */ fixed: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Determine the max-width of the container.
   * The container width grows with the size of the screen.
   * Set to `false` to disable `maxWidth`.
   * @default 'lg'
   */ maxWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'xs',
            'sm',
            'md',
            'lg',
            'xl',
            false
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Container;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Container/Container.js [app-client] (ecmascript) <export default as Container>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Container",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Container$2f$Container$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Container/Container.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/cardClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getCardUtilityClass",
    ()=>getCardUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getCardUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiCard', slot);
}
const cardClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiCard', [
    'root'
]);
const __TURBOPACK__default__export__ = cardClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/chainPropTypes/chainPropTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$cardClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/cardClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$cardClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardUtilityClass"], classes);
};
const CardRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiCard',
    slot: 'Root'
})({
    overflow: 'hidden'
});
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Card(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiCard'
    });
    const { className, raised = false, ...other } = props;
    const ownerState = {
        ...props,
        raised
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CardRoot, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        elevation: raised ? 8 : undefined,
        ref: ref,
        ownerState: ownerState,
        ...other
    });
});
("TURBOPACK compile-time truthy", 1) ? Card.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the card will use raised styling.
   * @default false
   */ raised: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool, (props)=>{
        if (props.raised && props.variant === 'outlined') {
            return new Error('MUI: Combining `raised={true}` with `variant="outlined"` has no effect.');
        }
        return null;
    }),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Card;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript) <export default as Card>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Card$2f$Card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Card/Card.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/cardContentClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getCardContentUtilityClass",
    ()=>getCardContentUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getCardContentUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiCardContent', slot);
}
const cardContentClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiCardContent', [
    'root'
]);
const __TURBOPACK__default__export__ = cardContentClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$cardContentClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/cardContentClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$cardContentClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardContentUtilityClass"], classes);
};
const CardContentRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiCardContent',
    slot: 'Root'
})({
    padding: 16,
    '&:last-child': {
        paddingBottom: 24
    }
});
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function CardContent(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiCardContent'
    });
    const { className, component = 'div', ...other } = props;
    const ownerState = {
        ...props,
        component
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CardContentRoot, {
        as: component,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        ownerState: ownerState,
        ref: ref,
        ...other
    });
});
("TURBOPACK compile-time truthy", 1) ? CardContent.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = CardContent;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript) <export default as CardContent>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CardContent",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CardContent$2f$CardContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CardContent/CardContent.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript) <export default as Typography>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Typography",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$debounce$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/debounce/debounce.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useForkRef/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEnhancedEffect$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useEnhancedEffect/useEnhancedEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEventCallback$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useEventCallback/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ownerWindow$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/ownerWindow/ownerWindow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function getStyleValue(value) {
    return parseInt(value, 10) || 0;
}
const styles = {
    shadow: {
        // Visibility needed to hide the extra text area on iPads
        visibility: 'hidden',
        // Remove from the content flow
        position: 'absolute',
        // Ignore the scrollbar width
        overflow: 'hidden',
        height: 0,
        top: 0,
        left: 0,
        // Create a new layer, increase the isolation of the computed values
        transform: 'translateZ(0)'
    }
};
function isObjectEmpty(object) {
    // eslint-disable-next-line
    for(const _ in object){
        return false;
    }
    return true;
}
function isEmpty(obj) {
    return isObjectEmpty(obj) || obj.outerHeightStyle === 0 && !obj.overflowing;
}
/**
 *
 * Demos:
 *
 * - [Textarea Autosize](https://mui.com/material-ui/react-textarea-autosize/)
 *
 * API:
 *
 * - [TextareaAutosize API](https://mui.com/material-ui/api/textarea-autosize/)
 */ const TextareaAutosize = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function TextareaAutosize(props, forwardedRef) {
    const { onChange, maxRows, minRows = 1, style, value, ...other } = props;
    const { current: isControlled } = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](value != null);
    const textareaRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const handleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(forwardedRef, textareaRef);
    const heightRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const hiddenTextareaRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const calculateTextareaStyles = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "TextareaAutosize.TextareaAutosize.useCallback[calculateTextareaStyles]": ()=>{
            const textarea = textareaRef.current;
            const hiddenTextarea = hiddenTextareaRef.current;
            if (!textarea || !hiddenTextarea) {
                return undefined;
            }
            const containerWindow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ownerWindow$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(textarea);
            const computedStyle = containerWindow.getComputedStyle(textarea);
            // If input's width is shrunk and it's not visible, don't sync height.
            if (computedStyle.width === '0px') {
                return {
                    outerHeightStyle: 0,
                    overflowing: false
                };
            }
            hiddenTextarea.style.width = computedStyle.width;
            hiddenTextarea.value = textarea.value || props.placeholder || 'x';
            if (hiddenTextarea.value.slice(-1) === '\n') {
                // Certain fonts which overflow the line height will cause the textarea
                // to report a different scrollHeight depending on whether the last line
                // is empty. Make it non-empty to avoid this issue.
                hiddenTextarea.value += ' ';
            }
            const boxSizing = computedStyle.boxSizing;
            const padding = getStyleValue(computedStyle.paddingBottom) + getStyleValue(computedStyle.paddingTop);
            const border = getStyleValue(computedStyle.borderBottomWidth) + getStyleValue(computedStyle.borderTopWidth);
            // The height of the inner content
            const innerHeight = hiddenTextarea.scrollHeight;
            // Measure height of a textarea with a single row
            hiddenTextarea.value = 'x';
            const singleRowHeight = hiddenTextarea.scrollHeight;
            // The height of the outer content
            let outerHeight = innerHeight;
            if (minRows) {
                outerHeight = Math.max(Number(minRows) * singleRowHeight, outerHeight);
            }
            if (maxRows) {
                outerHeight = Math.min(Number(maxRows) * singleRowHeight, outerHeight);
            }
            outerHeight = Math.max(outerHeight, singleRowHeight);
            // Take the box sizing into account for applying this value as a style.
            const outerHeightStyle = outerHeight + (boxSizing === 'border-box' ? padding + border : 0);
            const overflowing = Math.abs(outerHeight - innerHeight) <= 1;
            return {
                outerHeightStyle,
                overflowing
            };
        }
    }["TextareaAutosize.TextareaAutosize.useCallback[calculateTextareaStyles]"], [
        maxRows,
        minRows,
        props.placeholder
    ]);
    const didHeightChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEventCallback$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "TextareaAutosize.TextareaAutosize.useEventCallback[didHeightChange]": ()=>{
            const textarea = textareaRef.current;
            const textareaStyles = calculateTextareaStyles();
            if (!textarea || !textareaStyles || isEmpty(textareaStyles)) {
                return false;
            }
            const outerHeightStyle = textareaStyles.outerHeightStyle;
            return heightRef.current != null && heightRef.current !== outerHeightStyle;
        }
    }["TextareaAutosize.TextareaAutosize.useEventCallback[didHeightChange]"]);
    const syncHeight = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "TextareaAutosize.TextareaAutosize.useCallback[syncHeight]": ()=>{
            const textarea = textareaRef.current;
            const textareaStyles = calculateTextareaStyles();
            if (!textarea || !textareaStyles || isEmpty(textareaStyles)) {
                return;
            }
            const outerHeightStyle = textareaStyles.outerHeightStyle;
            if (heightRef.current !== outerHeightStyle) {
                heightRef.current = outerHeightStyle;
                textarea.style.height = `${outerHeightStyle}px`;
            }
            textarea.style.overflow = textareaStyles.overflowing ? 'hidden' : '';
        }
    }["TextareaAutosize.TextareaAutosize.useCallback[syncHeight]"], [
        calculateTextareaStyles
    ]);
    const frameRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](-1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEnhancedEffect$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "TextareaAutosize.TextareaAutosize.useEnhancedEffect": ()=>{
            const debouncedHandleResize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$debounce$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(syncHeight);
            const textarea = textareaRef?.current;
            if (!textarea) {
                return undefined;
            }
            const containerWindow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ownerWindow$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(textarea);
            containerWindow.addEventListener('resize', debouncedHandleResize);
            let resizeObserver;
            if (typeof ResizeObserver !== 'undefined') {
                resizeObserver = new ResizeObserver({
                    "TextareaAutosize.TextareaAutosize.useEnhancedEffect": ()=>{
                        if (didHeightChange()) {
                            // avoid "ResizeObserver loop completed with undelivered notifications" error
                            // by temporarily unobserving the textarea element while manipulating the height
                            // and reobserving one frame later
                            resizeObserver.unobserve(textarea);
                            cancelAnimationFrame(frameRef.current);
                            syncHeight();
                            frameRef.current = requestAnimationFrame({
                                "TextareaAutosize.TextareaAutosize.useEnhancedEffect": ()=>{
                                    resizeObserver.observe(textarea);
                                }
                            }["TextareaAutosize.TextareaAutosize.useEnhancedEffect"]);
                        }
                    }
                }["TextareaAutosize.TextareaAutosize.useEnhancedEffect"]);
                resizeObserver.observe(textarea);
            }
            return ({
                "TextareaAutosize.TextareaAutosize.useEnhancedEffect": ()=>{
                    debouncedHandleResize.clear();
                    cancelAnimationFrame(frameRef.current);
                    containerWindow.removeEventListener('resize', debouncedHandleResize);
                    if (resizeObserver) {
                        resizeObserver.disconnect();
                    }
                }
            })["TextareaAutosize.TextareaAutosize.useEnhancedEffect"];
        }
    }["TextareaAutosize.TextareaAutosize.useEnhancedEffect"], [
        calculateTextareaStyles,
        syncHeight,
        didHeightChange
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEnhancedEffect$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "TextareaAutosize.TextareaAutosize.useEnhancedEffect": ()=>{
            syncHeight();
        }
    }["TextareaAutosize.TextareaAutosize.useEnhancedEffect"]);
    const handleChange = (event)=>{
        if (!isControlled) {
            syncHeight();
        }
        const textarea = event.target;
        const countOfCharacters = textarea.value.length;
        const isLastCharacterNewLine = textarea.value.endsWith('\n');
        const isEndOfTheLine = textarea.selectionStart === countOfCharacters;
        // Set the cursor position to the very end of the text.
        if (isLastCharacterNewLine && isEndOfTheLine) {
            textarea.setSelectionRange(countOfCharacters, countOfCharacters);
        }
        if (onChange) {
            onChange(event);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("textarea", {
                value: value,
                onChange: handleChange,
                ref: handleRef,
                rows: minRows,
                style: style,
                ...other
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("textarea", {
                "aria-hidden": true,
                className: props.className,
                readOnly: true,
                ref: hiddenTextareaRef,
                tabIndex: -1,
                style: {
                    ...styles.shadow,
                    ...style,
                    paddingTop: 0,
                    paddingBottom: 0
                }
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? TextareaAutosize.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │ To update them, edit the TypeScript types and run `pnpm proptypes`. │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Maximum number of rows to display.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display.
   * @default 1
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * @ignore
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * @ignore
   */ style: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = TextareaAutosize;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>formControlState
]);
function formControlState({ props, states, muiFormControl }) {
    return states.reduce((acc, state)=>{
        acc[state] = props[state];
        if (muiFormControl) {
            if (typeof props[state] === 'undefined') {
                acc[state] = muiFormControl[state];
            }
        }
        return acc;
    }, {});
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControlContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
/**
 * @ignore - internal component.
 */ const FormControlContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) {
    FormControlContext.displayName = 'FormControlContext';
}
const __TURBOPACK__default__export__ = FormControlContext;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useFormControl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControlContext.js [app-client] (ecmascript)");
'use client';
;
;
function useFormControl() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Supports determination of isControlled().
// Controlled input accepts its current value as a prop.
//
// @see https://facebook.github.io/react/docs/forms.html#controlled-components
// @param value
// @returns {boolean} true if string (including '') or number (including zero)
__turbopack_context__.s([
    "hasValue",
    ()=>hasValue,
    "isAdornedStart",
    ()=>isAdornedStart,
    "isFilled",
    ()=>isFilled
]);
function hasValue(value) {
    return value != null && !(Array.isArray(value) && value.length === 0);
}
function isFilled(obj, SSR = false) {
    return obj && (hasValue(obj.value) && obj.value !== '' || SSR && hasValue(obj.defaultValue) && obj.defaultValue !== '');
}
function isAdornedStart(obj) {
    return obj.startAdornment;
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getInputBaseUtilityClass",
    ()=>getInputBaseUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getInputBaseUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInputBase', slot);
}
const inputBaseClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInputBase', [
    'root',
    'formControl',
    'focused',
    'disabled',
    'adornedStart',
    'adornedEnd',
    'error',
    'sizeSmall',
    'multiline',
    'colorSecondary',
    'fullWidth',
    'hiddenLabel',
    'readOnly',
    'input',
    'inputSizeSmall',
    'inputMultiline',
    'inputTypeSearch',
    'inputAdornedStart',
    'inputAdornedEnd',
    'inputHiddenLabel'
]);
const __TURBOPACK__default__export__ = inputBaseClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/InputBase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputBaseInput",
    ()=>InputBaseInput,
    "InputBaseRoot",
    ()=>InputBaseRoot,
    "default",
    ()=>__TURBOPACK__default__export__,
    "inputOverridesResolver",
    ()=>inputOverridesResolver,
    "rootOverridesResolver",
    ()=>rootOverridesResolver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementTypeAcceptingRef$2f$elementTypeAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/elementTypeAcceptingRef/elementTypeAcceptingRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isHostComponent$2f$isHostComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/isHostComponent/isHostComponent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControlContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$zero$2d$styled$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/zero-styled/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useEnhancedEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
var _InputGlobalStyles;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const rootOverridesResolver = (props, styles)=>{
    const { ownerState } = props;
    return [
        styles.root,
        ownerState.formControl && styles.formControl,
        ownerState.startAdornment && styles.adornedStart,
        ownerState.endAdornment && styles.adornedEnd,
        ownerState.error && styles.error,
        ownerState.size === 'small' && styles.sizeSmall,
        ownerState.multiline && styles.multiline,
        ownerState.color && styles[`color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.color)}`],
        ownerState.fullWidth && styles.fullWidth,
        ownerState.hiddenLabel && styles.hiddenLabel
    ];
};
const inputOverridesResolver = (props, styles)=>{
    const { ownerState } = props;
    return [
        styles.input,
        ownerState.size === 'small' && styles.inputSizeSmall,
        ownerState.multiline && styles.inputMultiline,
        ownerState.type === 'search' && styles.inputTypeSearch,
        ownerState.startAdornment && styles.inputAdornedStart,
        ownerState.endAdornment && styles.inputAdornedEnd,
        ownerState.hiddenLabel && styles.inputHiddenLabel
    ];
};
const useUtilityClasses = (ownerState)=>{
    const { classes, color, disabled, error, endAdornment, focused, formControl, fullWidth, hiddenLabel, multiline, readOnly, size, startAdornment, type } = ownerState;
    const slots = {
        root: [
            'root',
            `color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(color)}`,
            disabled && 'disabled',
            error && 'error',
            fullWidth && 'fullWidth',
            focused && 'focused',
            formControl && 'formControl',
            size && size !== 'medium' && `size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(size)}`,
            multiline && 'multiline',
            startAdornment && 'adornedStart',
            endAdornment && 'adornedEnd',
            hiddenLabel && 'hiddenLabel',
            readOnly && 'readOnly'
        ],
        input: [
            'input',
            disabled && 'disabled',
            type === 'search' && 'inputTypeSearch',
            multiline && 'inputMultiline',
            size === 'small' && 'inputSizeSmall',
            hiddenLabel && 'inputHiddenLabel',
            startAdornment && 'inputAdornedStart',
            endAdornment && 'inputAdornedEnd',
            readOnly && 'readOnly'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInputBaseUtilityClass"], classes);
};
const InputBaseRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiInputBase',
    slot: 'Root',
    overridesResolver: rootOverridesResolver
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        ...theme.typography.body1,
        color: (theme.vars || theme).palette.text.primary,
        lineHeight: '1.4375em',
        // 23px
        boxSizing: 'border-box',
        // Prevent padding issue with fullWidth.
        position: 'relative',
        cursor: 'text',
        display: 'inline-flex',
        alignItems: 'center',
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            color: (theme.vars || theme).palette.text.disabled,
            cursor: 'default'
        },
        variants: [
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    padding: '4px 0 5px'
                }
            },
            {
                props: ({ ownerState, size })=>ownerState.multiline && size === 'small',
                style: {
                    paddingTop: 1
                }
            },
            {
                props: ({ ownerState })=>ownerState.fullWidth,
                style: {
                    width: '100%'
                }
            }
        ]
    })));
const InputBaseInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('input', {
    name: 'MuiInputBase',
    slot: 'Input',
    overridesResolver: inputOverridesResolver
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const light = theme.palette.mode === 'light';
    const placeholder = {
        color: 'currentColor',
        ...theme.vars ? {
            opacity: theme.vars.opacity.inputPlaceholder
        } : {
            opacity: light ? 0.42 : 0.5
        },
        transition: theme.transitions.create('opacity', {
            duration: theme.transitions.duration.shorter
        })
    };
    const placeholderHidden = {
        opacity: '0 !important'
    };
    const placeholderVisible = theme.vars ? {
        opacity: theme.vars.opacity.inputPlaceholder
    } : {
        opacity: light ? 0.42 : 0.5
    };
    return {
        font: 'inherit',
        letterSpacing: 'inherit',
        color: 'currentColor',
        padding: '4px 0 5px',
        border: 0,
        boxSizing: 'content-box',
        background: 'none',
        height: '1.4375em',
        // Reset 23pxthe native input line-height
        margin: 0,
        // Reset for Safari
        WebkitTapHighlightColor: 'transparent',
        display: 'block',
        // Make the flex item shrink with Firefox
        minWidth: 0,
        width: '100%',
        '&::-webkit-input-placeholder': placeholder,
        '&::-moz-placeholder': placeholder,
        // Firefox 19+
        '&::-ms-input-placeholder': placeholder,
        // Edge
        '&:focus': {
            outline: 0
        },
        // Reset Firefox invalid required input style
        '&:invalid': {
            boxShadow: 'none'
        },
        '&::-webkit-search-decoration': {
            // Remove the padding when type=search.
            WebkitAppearance: 'none'
        },
        // Show and hide the placeholder logic
        [`label[data-shrink=false] + .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].formControl} &`]: {
            '&::-webkit-input-placeholder': placeholderHidden,
            '&::-moz-placeholder': placeholderHidden,
            // Firefox 19+
            '&::-ms-input-placeholder': placeholderHidden,
            // Edge
            '&:focus::-webkit-input-placeholder': placeholderVisible,
            '&:focus::-moz-placeholder': placeholderVisible,
            // Firefox 19+
            '&:focus::-ms-input-placeholder': placeholderVisible // Edge
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            opacity: 1,
            // Reset iOS opacity
            WebkitTextFillColor: (theme.vars || theme).palette.text.disabled // Fix opacity Safari bug
        },
        variants: [
            {
                props: ({ ownerState })=>!ownerState.disableInjectingGlobalStyles,
                style: {
                    animationName: 'mui-auto-fill-cancel',
                    animationDuration: '10ms',
                    '&:-webkit-autofill': {
                        animationDuration: '5000s',
                        animationName: 'mui-auto-fill'
                    }
                }
            },
            {
                props: {
                    size: 'small'
                },
                style: {
                    paddingTop: 1
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    height: 'auto',
                    resize: 'none',
                    padding: 0,
                    paddingTop: 0
                }
            },
            {
                props: {
                    type: 'search'
                },
                style: {
                    MozAppearance: 'textfield' // Improve type search style.
                }
            }
        ]
    };
}));
const InputGlobalStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$zero$2d$styled$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["globalCss"])({
    '@keyframes mui-auto-fill': {
        from: {
            display: 'block'
        }
    },
    '@keyframes mui-auto-fill-cancel': {
        from: {
            display: 'block'
        }
    }
});
/**
 * `InputBase` contains as few styles as possible.
 * It aims to be a simple building block for creating an input.
 * It contains a load of style reset and some state logic.
 */ const InputBase = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function InputBase(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiInputBase'
    });
    const { 'aria-describedby': ariaDescribedby, autoComplete, autoFocus, className, color, components = {}, componentsProps = {}, defaultValue, disabled, disableInjectingGlobalStyles, endAdornment, error, fullWidth = false, id, inputComponent = 'input', inputProps: inputPropsProp = {}, inputRef: inputRefProp, margin, maxRows, minRows, multiline = false, name, onBlur, onChange, onClick, onFocus, onKeyDown, onKeyUp, placeholder, readOnly, renderSuffix, rows, size, slotProps = {}, slots = {}, startAdornment, type = 'text', value: valueProp, ...other } = props;
    const value = inputPropsProp.value != null ? inputPropsProp.value : valueProp;
    const { current: isControlled } = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](value != null);
    const inputRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    const handleInputRefWarning = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "InputBase.InputBase.useCallback[handleInputRefWarning]": (instance)=>{
            if ("TURBOPACK compile-time truthy", 1) {
                if (instance && instance.nodeName !== 'INPUT' && !instance.focus) {
                    console.error([
                        'MUI: You have provided a `inputComponent` to the input component',
                        'that does not correctly handle the `ref` prop.',
                        'Make sure the `ref` prop is called with a HTMLInputElement.'
                    ].join('\n'));
                }
            }
        }
    }["InputBase.InputBase.useCallback[handleInputRefWarning]"], []);
    const handleInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(inputRef, inputRefProp, inputPropsProp.ref, handleInputRefWarning);
    const [focused, setFocused] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    if ("TURBOPACK compile-time truthy", 1) {
        // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "InputBase.InputBase.useEffect": ()=>{
                if (muiFormControl) {
                    return muiFormControl.registerEffect();
                }
                return undefined;
            }
        }["InputBase.InputBase.useEffect"], [
            muiFormControl
        ]);
    }
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'color',
            'disabled',
            'error',
            'hiddenLabel',
            'size',
            'required',
            'filled'
        ]
    });
    fcs.focused = muiFormControl ? muiFormControl.focused : focused;
    // The blur won't fire when the disabled state is set on a focused input.
    // We need to book keep the focused state manually.
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "InputBase.InputBase.useEffect": ()=>{
            if (!muiFormControl && disabled && focused) {
                setFocused(false);
                if (onBlur) {
                    onBlur();
                }
            }
        }
    }["InputBase.InputBase.useEffect"], [
        muiFormControl,
        disabled,
        focused,
        onBlur
    ]);
    const onFilled = muiFormControl && muiFormControl.onFilled;
    const onEmpty = muiFormControl && muiFormControl.onEmpty;
    const checkDirty = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "InputBase.InputBase.useCallback[checkDirty]": (obj)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFilled"])(obj)) {
                if (onFilled) {
                    onFilled();
                }
            } else if (onEmpty) {
                onEmpty();
            }
        }
    }["InputBase.InputBase.useCallback[checkDirty]"], [
        onFilled,
        onEmpty
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "InputBase.InputBase.useEnhancedEffect": ()=>{
            if (isControlled) {
                checkDirty({
                    value
                });
            }
        }
    }["InputBase.InputBase.useEnhancedEffect"], [
        value,
        checkDirty,
        isControlled
    ]);
    const handleFocus = (event)=>{
        if (onFocus) {
            onFocus(event);
        }
        if (inputPropsProp.onFocus) {
            inputPropsProp.onFocus(event);
        }
        if (muiFormControl && muiFormControl.onFocus) {
            muiFormControl.onFocus(event);
        } else {
            setFocused(true);
        }
    };
    const handleBlur = (event)=>{
        if (onBlur) {
            onBlur(event);
        }
        if (inputPropsProp.onBlur) {
            inputPropsProp.onBlur(event);
        }
        if (muiFormControl && muiFormControl.onBlur) {
            muiFormControl.onBlur(event);
        } else {
            setFocused(false);
        }
    };
    const handleChange = (event, ...args)=>{
        if (!isControlled) {
            const element = event.target || inputRef.current;
            if (element == null) {
                throw new Error(("TURBOPACK compile-time truthy", 1) ? 'MUI: Expected valid input target. ' + 'Did you use a custom `inputComponent` and forget to forward refs? ' + 'See https://mui.com/r/input-component-ref-interface for more info.' : "TURBOPACK unreachable");
            }
            checkDirty({
                value: element.value
            });
        }
        if (inputPropsProp.onChange) {
            inputPropsProp.onChange(event, ...args);
        }
        // Perform in the willUpdate
        if (onChange) {
            onChange(event, ...args);
        }
    };
    // Check the input state on mount, in case it was filled by the user
    // or auto filled by the browser before the hydration (for SSR).
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "InputBase.InputBase.useEffect": ()=>{
            checkDirty(inputRef.current);
        // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["InputBase.InputBase.useEffect"], []);
    const handleClick = (event)=>{
        if (inputRef.current && event.currentTarget === event.target) {
            inputRef.current.focus();
        }
        if (onClick) {
            onClick(event);
        }
    };
    let InputComponent = inputComponent;
    let inputProps = inputPropsProp;
    if (multiline && InputComponent === 'input') {
        if (rows) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (minRows || maxRows) {
                    console.warn('MUI: You can not use the `minRows` or `maxRows` props when the input `rows` prop is set.');
                }
            }
            inputProps = {
                type: undefined,
                minRows: rows,
                maxRows: rows,
                ...inputProps
            };
        } else {
            inputProps = {
                type: undefined,
                maxRows,
                minRows,
                ...inputProps
            };
        }
        InputComponent = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    }
    const handleAutoFill = (event)=>{
        // Provide a fake value as Chrome might not let you access it for security reasons.
        checkDirty(event.animationName === 'mui-auto-fill-cancel' ? inputRef.current : {
            value: 'x'
        });
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "InputBase.InputBase.useEffect": ()=>{
            if (muiFormControl) {
                muiFormControl.setAdornedStart(Boolean(startAdornment));
            }
        }
    }["InputBase.InputBase.useEffect"], [
        muiFormControl,
        startAdornment
    ]);
    const ownerState = {
        ...props,
        color: fcs.color || 'primary',
        disabled: fcs.disabled,
        endAdornment,
        error: fcs.error,
        focused: fcs.focused,
        formControl: muiFormControl,
        fullWidth,
        hiddenLabel: fcs.hiddenLabel,
        multiline,
        size: fcs.size,
        startAdornment,
        type
    };
    const classes = useUtilityClasses(ownerState);
    const Root = slots.root || components.Root || InputBaseRoot;
    const rootProps = slotProps.root || componentsProps.root || {};
    const Input = slots.input || components.Input || InputBaseInput;
    inputProps = {
        ...inputProps,
        ...slotProps.input ?? componentsProps.input
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            !disableInjectingGlobalStyles && typeof InputGlobalStyles === 'function' && (// For Pigment CSS, this has no effect because the InputGlobalStyles will be null.
            _InputGlobalStyles || (_InputGlobalStyles = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputGlobalStyles, {}))),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Root, {
                ...rootProps,
                ref: ref,
                onClick: handleClick,
                ...other,
                ...!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isHostComponent$2f$isHostComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Root) && {
                    ownerState: {
                        ...ownerState,
                        ...rootProps.ownerState
                    }
                },
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, rootProps.className, className, readOnly && 'MuiInputBase-readOnly'),
                children: [
                    startAdornment,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
                        value: null,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input, {
                            "aria-invalid": fcs.error,
                            "aria-describedby": ariaDescribedby,
                            autoComplete: autoComplete,
                            autoFocus: autoFocus,
                            defaultValue: defaultValue,
                            disabled: fcs.disabled,
                            id: id,
                            onAnimationStart: handleAutoFill,
                            name: name,
                            placeholder: placeholder,
                            readOnly: readOnly,
                            required: fcs.required,
                            rows: rows,
                            value: value,
                            onKeyDown: onKeyDown,
                            onKeyUp: onKeyUp,
                            type: type,
                            ...inputProps,
                            ...!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isHostComponent$2f$isHostComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(Input) && {
                                as: InputComponent,
                                ownerState: {
                                    ...ownerState,
                                    ...inputProps.ownerState
                                }
                            },
                            ref: handleInputRef,
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.input, inputProps.className, readOnly && 'MuiInputBase-readOnly'),
                            onBlur: handleBlur,
                            onChange: handleChange,
                            onFocus: handleFocus
                        })
                    }),
                    endAdornment,
                    renderSuffix ? renderSuffix({
                        ...fcs,
                        startAdornment
                    }) : null
                ]
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? InputBase.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * @ignore
   */ 'aria-describedby': __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * This prop helps users to fill forms faster, especially on mobile devices.
   * The name can be confusing, as it's more like an autofill.
   * You can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
   */ autoComplete: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the `input` element is focused during the first mount.
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * The prop defaults to the value (`'primary'`) inherited from the parent FormControl component.
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary',
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The components used for each slot inside.
   *
   * @deprecated use the `slots` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ components: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        Input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        Root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * @deprecated use the `slotProps` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ componentsProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the component is disabled.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, GlobalStyles for the auto-fill keyframes will not be injected/removed on mount/unmount. Make sure to inject them at the top of your application.
   * This option is intended to help with boosting the initial rendering performance if you are loading a big amount of Input components at once.
   * @default false
   */ disableInjectingGlobalStyles: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * End `InputAdornment` for this component.
   */ endAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `true`, the `input` will indicate an error.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The id of the `input` element.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the `input` element.
   * Either a string to use a HTML element or a component.
   * @default 'input'
   */ inputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementTypeAcceptingRef$2f$elementTypeAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * @default {}
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a ref to the `input` element.
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   * The prop defaults to the value (`'none'`) inherited from the parent FormControl component.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none'
    ]),
    /**
   * Maximum number of rows to display when multiline option is set to true.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display when multiline option is set to true.
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, a [TextareaAutosize](https://mui.com/material-ui/react-textarea-autosize/) element is rendered.
   * @default false
   */ multiline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Callback fired when the `input` is blurred.
   *
   * Notice that the first argument (event) might be undefined.
   */ onBlur: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the value is changed.
   *
   * @param {React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onClick: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the `input` doesn't satisfy its constraints.
   */ onInvalid: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onKeyDown: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onKeyUp: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The short hint displayed in the `input` before the user enters a value.
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * It prevents the user from changing the value of the field
   * (not from interacting with the field).
   */ readOnly: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * @ignore
   */ renderSuffix: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the `input` element is required.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Number of rows to display when multiline option is set to true.
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The size of the component.
   */ size: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'medium',
            'small'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * This prop is an alias for the `componentsProps` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The components used for each slot inside.
   *
   * This prop is an alias for the `components` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * Start `InputAdornment` for this component.
   */ startAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#input_types).
   * @default 'text'
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The value of the `input` element, required for a controlled component.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = InputBase;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript) <export default as inputBaseClasses>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "inputBaseClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Input/inputClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getInputUtilityClass",
    ()=>getInputUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript) <export default as inputBaseClasses>");
;
;
;
function getInputUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInput', slot);
}
const inputClasses = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__["inputBaseClasses"],
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInput', [
        'root',
        'underline',
        'input'
    ])
};
const __TURBOPACK__default__export__ = inputClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Input/Input.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/deepmerge/deepmerge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/InputBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Input/inputClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, disableUnderline } = ownerState;
    const slots = {
        root: [
            'root',
            !disableUnderline && 'underline'
        ],
        input: [
            'input'
        ]
    };
    const composedClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInputUtilityClass"], classes);
    return {
        ...classes,
        // forward classes to the InputBase
        ...composedClasses
    };
};
const InputRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseRoot"], {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) || prop === 'classes',
    name: 'MuiInput',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootOverridesResolver"])(props, styles),
            !ownerState.disableUnderline && styles.underline
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const light = theme.palette.mode === 'light';
    let bottomLineColor = light ? 'rgba(0, 0, 0, 0.42)' : 'rgba(255, 255, 255, 0.7)';
    if (theme.vars) {
        bottomLineColor = theme.alpha(theme.vars.palette.common.onBackground, theme.vars.opacity.inputUnderline);
    }
    return {
        position: 'relative',
        variants: [
            {
                props: ({ ownerState })=>ownerState.formControl,
                style: {
                    'label + &': {
                        marginTop: 16
                    }
                }
            },
            {
                props: ({ ownerState })=>!ownerState.disableUnderline,
                style: {
                    '&::after': {
                        left: 0,
                        bottom: 0,
                        content: '""',
                        position: 'absolute',
                        right: 0,
                        transform: 'scaleX(0)',
                        transition: theme.transitions.create('transform', {
                            duration: theme.transitions.duration.shorter,
                            easing: theme.transitions.easing.easeOut
                        }),
                        pointerEvents: 'none' // Transparent to the hover style.
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused}:after`]: {
                        // translateX(0) is a workaround for Safari transform scale bug
                        // See https://github.com/mui/material-ui/issues/31766
                        transform: 'scaleX(1) translateX(0)'
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: {
                        '&::before, &::after': {
                            borderBottomColor: (theme.vars || theme).palette.error.main
                        }
                    },
                    '&::before': {
                        borderBottom: `1px solid ${bottomLineColor}`,
                        left: 0,
                        bottom: 0,
                        content: '"\\00a0"',
                        position: 'absolute',
                        right: 0,
                        transition: theme.transitions.create('border-bottom-color', {
                            duration: theme.transitions.duration.shorter
                        }),
                        pointerEvents: 'none' // Transparent to the hover style.
                    },
                    [`&:hover:not(.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}, .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}):before`]: {
                        borderBottom: `2px solid ${(theme.vars || theme).palette.text.primary}`,
                        // Reset on touch devices, it doesn't add specificity
                        '@media (hover: none)': {
                            borderBottom: `1px solid ${bottomLineColor}`
                        }
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$inputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}:before`]: {
                        borderBottomStyle: 'dotted'
                    }
                }
            },
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()).map(([color])=>({
                    props: {
                        color,
                        disableUnderline: false
                    },
                    style: {
                        '&::after': {
                            borderBottom: `2px solid ${(theme.vars || theme).palette[color].main}`
                        }
                    }
                }))
        ]
    };
}));
const InputInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseInput"], {
    name: 'MuiInput',
    slot: 'Input',
    overridesResolver: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputOverridesResolver"]
})({});
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Input(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiInput'
    });
    const { disableUnderline = false, components = {}, componentsProps: componentsPropsProp, fullWidth = false, inputComponent = 'input', multiline = false, slotProps, slots = {}, type = 'text', ...other } = props;
    const classes = useUtilityClasses(props);
    const ownerState = {
        disableUnderline
    };
    const inputComponentsProps = {
        root: {
            ownerState
        }
    };
    const componentsProps = slotProps ?? componentsPropsProp ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slotProps ?? componentsPropsProp, inputComponentsProps) : inputComponentsProps;
    const RootSlot = slots.root ?? components.Root ?? InputRoot;
    const InputSlot = slots.input ?? components.Input ?? InputInput;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        slots: {
            root: RootSlot,
            input: InputSlot
        },
        slotProps: componentsProps,
        fullWidth: fullWidth,
        inputComponent: inputComponent,
        multiline: multiline,
        ref: ref,
        type: type,
        ...other,
        classes: classes
    });
});
("TURBOPACK compile-time truthy", 1) ? Input.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * This prop helps users to fill forms faster, especially on mobile devices.
   * The name can be confusing, as it's more like an autofill.
   * You can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
   */ autoComplete: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the `input` element is focused during the first mount.
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * The prop defaults to the value (`'primary'`) inherited from the parent FormControl component.
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The components used for each slot inside.
   *
   * @deprecated use the `slots` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ components: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        Input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        Root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * @deprecated use the `slotProps` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ componentsProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the component is disabled.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` will not have an underline.
   * @default false
   */ disableUnderline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * End `InputAdornment` for this component.
   */ endAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `true`, the `input` will indicate an error.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The id of the `input` element.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the `input` element.
   * Either a string to use a HTML element or a component.
   * @default 'input'
   */ inputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * @default {}
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a ref to the `input` element.
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   * The prop defaults to the value (`'none'`) inherited from the parent FormControl component.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none'
    ]),
    /**
   * Maximum number of rows to display when multiline option is set to true.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display when multiline option is set to true.
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, a [TextareaAutosize](https://mui.com/material-ui/react-textarea-autosize/) element is rendered.
   * @default false
   */ multiline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Callback fired when the value is changed.
   *
   * @param {React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The short hint displayed in the `input` before the user enters a value.
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * It prevents the user from changing the value of the field
   * (not from interacting with the field).
   */ readOnly: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` element is required.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Number of rows to display when multiline option is set to true.
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * This prop is an alias for the `componentsProps` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The components used for each slot inside.
   *
   * This prop is an alias for the `components` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * Start `InputAdornment` for this component.
   */ startAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#input_types).
   * @default 'text'
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The value of the `input` element, required for a controlled component.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
} : "TURBOPACK unreachable";
Input.muiName = 'Input';
const __TURBOPACK__default__export__ = Input;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FilledInput/filledInputClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getFilledInputUtilityClass",
    ()=>getFilledInputUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript) <export default as inputBaseClasses>");
;
;
;
function getFilledInputUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFilledInput', slot);
}
const filledInputClasses = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__["inputBaseClasses"],
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFilledInput', [
        'root',
        'underline',
        'input',
        'adornedStart',
        'adornedEnd',
        'sizeSmall',
        'multiline',
        'hiddenLabel'
    ])
};
const __TURBOPACK__default__export__ = filledInputClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript) <export default as capitalize>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "capitalize",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FilledInput/FilledInput.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/deepmerge/deepmerge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/InputBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FilledInput/filledInputClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__capitalize$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript) <export default as capitalize>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, disableUnderline, startAdornment, endAdornment, size, hiddenLabel, multiline } = ownerState;
    const slots = {
        root: [
            'root',
            !disableUnderline && 'underline',
            startAdornment && 'adornedStart',
            endAdornment && 'adornedEnd',
            size === 'small' && `size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__capitalize$3e$__["capitalize"])(size)}`,
            hiddenLabel && 'hiddenLabel',
            multiline && 'multiline'
        ],
        input: [
            'input'
        ]
    };
    const composedClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilledInputUtilityClass"], classes);
    return {
        ...classes,
        // forward classes to the InputBase
        ...composedClasses
    };
};
const FilledInputRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseRoot"], {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) || prop === 'classes',
    name: 'MuiFilledInput',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootOverridesResolver"])(props, styles),
            !ownerState.disableUnderline && styles.underline
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const light = theme.palette.mode === 'light';
    const bottomLineColor = light ? 'rgba(0, 0, 0, 0.42)' : 'rgba(255, 255, 255, 0.7)';
    const backgroundColor = light ? 'rgba(0, 0, 0, 0.06)' : 'rgba(255, 255, 255, 0.09)';
    const hoverBackground = light ? 'rgba(0, 0, 0, 0.09)' : 'rgba(255, 255, 255, 0.13)';
    const disabledBackground = light ? 'rgba(0, 0, 0, 0.12)' : 'rgba(255, 255, 255, 0.12)';
    return {
        position: 'relative',
        backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor,
        borderTopLeftRadius: (theme.vars || theme).shape.borderRadius,
        borderTopRightRadius: (theme.vars || theme).shape.borderRadius,
        transition: theme.transitions.create('background-color', {
            duration: theme.transitions.duration.shorter,
            easing: theme.transitions.easing.easeOut
        }),
        '&:hover': {
            backgroundColor: theme.vars ? theme.vars.palette.FilledInput.hoverBg : hoverBackground,
            // Reset on touch devices, it doesn't add specificity
            '@media (hover: none)': {
                backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor
            }
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused}`]: {
            backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            backgroundColor: theme.vars ? theme.vars.palette.FilledInput.disabledBg : disabledBackground
        },
        variants: [
            {
                props: ({ ownerState })=>!ownerState.disableUnderline,
                style: {
                    '&::after': {
                        left: 0,
                        bottom: 0,
                        content: '""',
                        position: 'absolute',
                        right: 0,
                        transform: 'scaleX(0)',
                        transition: theme.transitions.create('transform', {
                            duration: theme.transitions.duration.shorter,
                            easing: theme.transitions.easing.easeOut
                        }),
                        pointerEvents: 'none' // Transparent to the hover style.
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused}:after`]: {
                        // translateX(0) is a workaround for Safari transform scale bug
                        // See https://github.com/mui/material-ui/issues/31766
                        transform: 'scaleX(1) translateX(0)'
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: {
                        '&::before, &::after': {
                            borderBottomColor: (theme.vars || theme).palette.error.main
                        }
                    },
                    '&::before': {
                        borderBottom: `1px solid ${theme.vars ? theme.alpha(theme.vars.palette.common.onBackground, theme.vars.opacity.inputUnderline) : bottomLineColor}`,
                        left: 0,
                        bottom: 0,
                        content: '"\\00a0"',
                        position: 'absolute',
                        right: 0,
                        transition: theme.transitions.create('border-bottom-color', {
                            duration: theme.transitions.duration.shorter
                        }),
                        pointerEvents: 'none' // Transparent to the hover style.
                    },
                    [`&:hover:not(.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}, .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}):before`]: {
                        borderBottom: `1px solid ${(theme.vars || theme).palette.text.primary}`
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}:before`]: {
                        borderBottomStyle: 'dotted'
                    }
                }
            },
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()) // check all the used fields in the style below
            .map(([color])=>({
                    props: {
                        disableUnderline: false,
                        color
                    },
                    style: {
                        '&::after': {
                            borderBottom: `2px solid ${(theme.vars || theme).palette[color]?.main}`
                        }
                    }
                })),
            {
                props: ({ ownerState })=>ownerState.startAdornment,
                style: {
                    paddingLeft: 12
                }
            },
            {
                props: ({ ownerState })=>ownerState.endAdornment,
                style: {
                    paddingRight: 12
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    padding: '25px 12px 8px'
                }
            },
            {
                props: ({ ownerState, size })=>ownerState.multiline && size === 'small',
                style: {
                    paddingTop: 21,
                    paddingBottom: 4
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline && ownerState.hiddenLabel,
                style: {
                    paddingTop: 16,
                    paddingBottom: 17
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline && ownerState.hiddenLabel && ownerState.size === 'small',
                style: {
                    paddingTop: 8,
                    paddingBottom: 9
                }
            }
        ]
    };
}));
const FilledInputInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseInput"], {
    name: 'MuiFilledInput',
    slot: 'Input',
    overridesResolver: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputOverridesResolver"]
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        paddingTop: 25,
        paddingRight: 12,
        paddingBottom: 8,
        paddingLeft: 12,
        ...!theme.vars && {
            '&:-webkit-autofill': {
                WebkitBoxShadow: theme.palette.mode === 'light' ? null : '0 0 0 100px #266798 inset',
                WebkitTextFillColor: theme.palette.mode === 'light' ? null : '#fff',
                caretColor: theme.palette.mode === 'light' ? null : '#fff',
                borderTopLeftRadius: 'inherit',
                borderTopRightRadius: 'inherit'
            }
        },
        ...theme.vars && {
            '&:-webkit-autofill': {
                borderTopLeftRadius: 'inherit',
                borderTopRightRadius: 'inherit'
            },
            [theme.getColorSchemeSelector('dark')]: {
                '&:-webkit-autofill': {
                    WebkitBoxShadow: '0 0 0 100px #266798 inset',
                    WebkitTextFillColor: '#fff',
                    caretColor: '#fff'
                }
            }
        },
        variants: [
            {
                props: {
                    size: 'small'
                },
                style: {
                    paddingTop: 21,
                    paddingBottom: 4
                }
            },
            {
                props: ({ ownerState })=>ownerState.hiddenLabel,
                style: {
                    paddingTop: 16,
                    paddingBottom: 17
                }
            },
            {
                props: ({ ownerState })=>ownerState.startAdornment,
                style: {
                    paddingLeft: 0
                }
            },
            {
                props: ({ ownerState })=>ownerState.endAdornment,
                style: {
                    paddingRight: 0
                }
            },
            {
                props: ({ ownerState })=>ownerState.hiddenLabel && ownerState.size === 'small',
                style: {
                    paddingTop: 8,
                    paddingBottom: 9
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    paddingTop: 0,
                    paddingBottom: 0,
                    paddingLeft: 0,
                    paddingRight: 0
                }
            }
        ]
    })));
const FilledInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FilledInput(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiFilledInput'
    });
    const { disableUnderline = false, components = {}, componentsProps: componentsPropsProp, fullWidth = false, hiddenLabel, // declare here to prevent spreading to DOM
    inputComponent = 'input', multiline = false, slotProps, slots = {}, type = 'text', ...other } = props;
    const ownerState = {
        ...props,
        disableUnderline,
        fullWidth,
        inputComponent,
        multiline,
        type
    };
    const classes = useUtilityClasses(props);
    const filledInputComponentsProps = {
        root: {
            ownerState
        },
        input: {
            ownerState
        }
    };
    const componentsProps = slotProps ?? componentsPropsProp ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(filledInputComponentsProps, slotProps ?? componentsPropsProp) : filledInputComponentsProps;
    const RootSlot = slots.root ?? components.Root ?? FilledInputRoot;
    const InputSlot = slots.input ?? components.Input ?? FilledInputInput;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        slots: {
            root: RootSlot,
            input: InputSlot
        },
        slotProps: componentsProps,
        fullWidth: fullWidth,
        inputComponent: inputComponent,
        multiline: multiline,
        ref: ref,
        type: type,
        ...other,
        classes: classes
    });
});
("TURBOPACK compile-time truthy", 1) ? FilledInput.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * This prop helps users to fill forms faster, especially on mobile devices.
   * The name can be confusing, as it's more like an autofill.
   * You can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
   */ autoComplete: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the `input` element is focused during the first mount.
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * The prop defaults to the value (`'primary'`) inherited from the parent FormControl component.
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The components used for each slot inside.
   *
   * @deprecated use the `slots` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ components: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        Input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        Root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * @deprecated use the `slotProps` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ componentsProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the component is disabled.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the input will not have an underline.
   * @default false
   */ disableUnderline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * End `InputAdornment` for this component.
   */ endAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `true`, the `input` will indicate an error.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is hidden.
   * This is used to increase density for a `FilledInput`.
   * Be sure to add `aria-label` to the `input` element.
   * @default false
   */ hiddenLabel: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The id of the `input` element.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the `input` element.
   * Either a string to use a HTML element or a component.
   * @default 'input'
   */ inputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * @default {}
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a ref to the `input` element.
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   * The prop defaults to the value (`'none'`) inherited from the parent FormControl component.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none'
    ]),
    /**
   * Maximum number of rows to display when multiline option is set to true.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display when multiline option is set to true.
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, a [TextareaAutosize](https://mui.com/material-ui/react-textarea-autosize/) element is rendered.
   * @default false
   */ multiline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Callback fired when the value is changed.
   *
   * @param {React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The short hint displayed in the `input` before the user enters a value.
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * It prevents the user from changing the value of the field
   * (not from interacting with the field).
   */ readOnly: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` element is required.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Number of rows to display when multiline option is set to true.
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * This prop is an alias for the `componentsProps` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The components used for each slot inside.
   *
   * This prop is an alias for the `components` prop, which will be deprecated in the future.
   *
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * Start `InputAdornment` for this component.
   */ startAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#input_types).
   * @default 'text'
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The value of the `input` element, required for a controlled component.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
} : "TURBOPACK unreachable";
FilledInput.muiName = 'Input';
const __TURBOPACK__default__export__ = FilledInput;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/NotchedOutline.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotchedOutline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
var _span;
;
;
;
;
;
;
const NotchedOutlineRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('fieldset', {
    name: 'MuiNotchedOutlined',
    shouldForwardProp: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
})({
    textAlign: 'left',
    position: 'absolute',
    bottom: 0,
    right: 0,
    top: -5,
    left: 0,
    margin: 0,
    padding: '0 8px',
    pointerEvents: 'none',
    borderRadius: 'inherit',
    borderStyle: 'solid',
    borderWidth: 1,
    overflow: 'hidden',
    minWidth: '0%'
});
const NotchedOutlineLegend = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('legend', {
    name: 'MuiNotchedOutlined',
    shouldForwardProp: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        float: 'unset',
        // Fix conflict with bootstrap
        width: 'auto',
        // Fix conflict with bootstrap
        overflow: 'hidden',
        // Fix Horizontal scroll when label too long
        variants: [
            {
                props: ({ ownerState })=>!ownerState.withLabel,
                style: {
                    padding: 0,
                    lineHeight: '11px',
                    // sync with `height` in `legend` styles
                    transition: theme.transitions.create('width', {
                        duration: 150,
                        easing: theme.transitions.easing.easeOut
                    })
                }
            },
            {
                props: ({ ownerState })=>ownerState.withLabel,
                style: {
                    display: 'block',
                    // Fix conflict with normalize.css and sanitize.css
                    padding: 0,
                    height: 11,
                    // sync with `lineHeight` in `legend` styles
                    fontSize: '0.75em',
                    visibility: 'hidden',
                    maxWidth: 0.01,
                    transition: theme.transitions.create('max-width', {
                        duration: 50,
                        easing: theme.transitions.easing.easeOut
                    }),
                    whiteSpace: 'nowrap',
                    '& > span': {
                        paddingLeft: 5,
                        paddingRight: 5,
                        display: 'inline-block',
                        opacity: 0,
                        visibility: 'visible'
                    }
                }
            },
            {
                props: ({ ownerState })=>ownerState.withLabel && ownerState.notched,
                style: {
                    maxWidth: '100%',
                    transition: theme.transitions.create('max-width', {
                        duration: 100,
                        easing: theme.transitions.easing.easeOut,
                        delay: 50
                    })
                }
            }
        ]
    })));
function NotchedOutline(props) {
    const { children, classes, className, label, notched, ...other } = props;
    const withLabel = label != null && label !== '';
    const ownerState = {
        ...props,
        notched,
        withLabel
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(NotchedOutlineRoot, {
        "aria-hidden": true,
        className: className,
        ownerState: ownerState,
        ...other,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(NotchedOutlineLegend, {
            ownerState: ownerState,
            children: withLabel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                children: label
            }) : _span || (_span = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: "notranslate",
                "aria-hidden": true,
                children: "\u200B"
            }))
        })
    });
}
("TURBOPACK compile-time truthy", 1) ? NotchedOutline.propTypes = {
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The label.
   */ label: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `true`, the outline is notched to accommodate the label.
   */ notched: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    /**
   * @ignore
   */ style: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
} : "TURBOPACK unreachable";
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/outlinedInputClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getOutlinedInputUtilityClass",
    ()=>getOutlinedInputUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-client] (ecmascript) <export default as inputBaseClasses>");
;
;
;
function getOutlinedInputUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiOutlinedInput', slot);
}
const outlinedInputClasses = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__["inputBaseClasses"],
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiOutlinedInput', [
        'root',
        'notchedOutline',
        'input'
    ])
};
const __TURBOPACK__default__export__ = outlinedInputClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/OutlinedInput.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$NotchedOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/NotchedOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/outlinedInputClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/InputBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useSlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ],
        notchedOutline: [
            'notchedOutline'
        ],
        input: [
            'input'
        ]
    };
    const composedClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOutlinedInputUtilityClass"], classes);
    return {
        ...classes,
        // forward classes to the InputBase
        ...composedClasses
    };
};
const OutlinedInputRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseRoot"], {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) || prop === 'classes',
    name: 'MuiOutlinedInput',
    slot: 'Root',
    overridesResolver: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootOverridesResolver"]
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const borderColor = theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.23)' : 'rgba(255, 255, 255, 0.23)';
    return {
        position: 'relative',
        borderRadius: (theme.vars || theme).shape.borderRadius,
        [`&:hover .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
            borderColor: (theme.vars || theme).palette.text.primary
        },
        // Reset on touch devices, it doesn't add specificity
        '@media (hover: none)': {
            [`&:hover .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
                borderColor: theme.vars ? theme.alpha(theme.vars.palette.common.onBackground, 0.23) : borderColor
            }
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused} .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
            borderWidth: 2
        },
        variants: [
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()).map(([color])=>({
                    props: {
                        color
                    },
                    style: {
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused} .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
                            borderColor: (theme.vars || theme).palette[color].main
                        }
                    }
                })),
            {
                props: {},
                // to override the above style
                style: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error} .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
                        borderColor: (theme.vars || theme).palette.error.main
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled} .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].notchedOutline}`]: {
                        borderColor: (theme.vars || theme).palette.action.disabled
                    }
                }
            },
            {
                props: ({ ownerState })=>ownerState.startAdornment,
                style: {
                    paddingLeft: 14
                }
            },
            {
                props: ({ ownerState })=>ownerState.endAdornment,
                style: {
                    paddingRight: 14
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    padding: '16.5px 14px'
                }
            },
            {
                props: ({ ownerState, size })=>ownerState.multiline && size === 'small',
                style: {
                    padding: '8.5px 14px'
                }
            }
        ]
    };
}));
const NotchedOutlineRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$NotchedOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiOutlinedInput',
    slot: 'NotchedOutline'
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const borderColor = theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.23)' : 'rgba(255, 255, 255, 0.23)';
    return {
        borderColor: theme.vars ? theme.alpha(theme.vars.palette.common.onBackground, 0.23) : borderColor
    };
}));
const OutlinedInputInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputBaseInput"], {
    name: 'MuiOutlinedInput',
    slot: 'Input',
    overridesResolver: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputOverridesResolver"]
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        padding: '16.5px 14px',
        ...!theme.vars && {
            '&:-webkit-autofill': {
                WebkitBoxShadow: theme.palette.mode === 'light' ? null : '0 0 0 100px #266798 inset',
                WebkitTextFillColor: theme.palette.mode === 'light' ? null : '#fff',
                caretColor: theme.palette.mode === 'light' ? null : '#fff',
                borderRadius: 'inherit'
            }
        },
        ...theme.vars && {
            '&:-webkit-autofill': {
                borderRadius: 'inherit'
            },
            [theme.getColorSchemeSelector('dark')]: {
                '&:-webkit-autofill': {
                    WebkitBoxShadow: '0 0 0 100px #266798 inset',
                    WebkitTextFillColor: '#fff',
                    caretColor: '#fff'
                }
            }
        },
        variants: [
            {
                props: {
                    size: 'small'
                },
                style: {
                    padding: '8.5px 14px'
                }
            },
            {
                props: ({ ownerState })=>ownerState.multiline,
                style: {
                    padding: 0
                }
            },
            {
                props: ({ ownerState })=>ownerState.startAdornment,
                style: {
                    paddingLeft: 0
                }
            },
            {
                props: ({ ownerState })=>ownerState.endAdornment,
                style: {
                    paddingRight: 0
                }
            }
        ]
    })));
const OutlinedInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function OutlinedInput(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiOutlinedInput'
    });
    const { components = {}, fullWidth = false, inputComponent = 'input', label, multiline = false, notched, slots = {}, slotProps = {}, type = 'text', ...other } = props;
    const classes = useUtilityClasses(props);
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'color',
            'disabled',
            'error',
            'focused',
            'hiddenLabel',
            'size',
            'required'
        ]
    });
    const ownerState = {
        ...props,
        color: fcs.color || 'primary',
        disabled: fcs.disabled,
        error: fcs.error,
        focused: fcs.focused,
        formControl: muiFormControl,
        fullWidth,
        hiddenLabel: fcs.hiddenLabel,
        multiline,
        size: fcs.size,
        type
    };
    const RootSlot = slots.root ?? components.Root ?? OutlinedInputRoot;
    const InputSlot = slots.input ?? components.Input ?? OutlinedInputInput;
    const [NotchedSlot, notchedProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('notchedOutline', {
        elementType: NotchedOutlineRoot,
        className: classes.notchedOutline,
        shouldForwardComponentProp: true,
        ownerState,
        externalForwardedProps: {
            slots,
            slotProps
        },
        additionalProps: {
            label: label != null && label !== '' && fcs.required ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    label,
                    "\u2009",
                    '*'
                ]
            }) : label
        }
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        slots: {
            root: RootSlot,
            input: InputSlot
        },
        slotProps: slotProps,
        renderSuffix: (state)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(NotchedSlot, {
                ...notchedProps,
                notched: typeof notched !== 'undefined' ? notched : Boolean(state.startAdornment || state.filled || state.focused)
            }),
        fullWidth: fullWidth,
        inputComponent: inputComponent,
        multiline: multiline,
        ref: ref,
        type: type,
        ...other,
        classes: {
            ...classes,
            notchedOutline: null
        }
    });
});
("TURBOPACK compile-time truthy", 1) ? OutlinedInput.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * This prop helps users to fill forms faster, especially on mobile devices.
   * The name can be confusing, as it's more like an autofill.
   * You can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
   */ autoComplete: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the `input` element is focused during the first mount.
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * The prop defaults to the value (`'primary'`) inherited from the parent FormControl component.
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The components used for each slot inside.
   *
   * @deprecated use the `slots` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ components: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        Input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        Root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the component is disabled.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * End `InputAdornment` for this component.
   */ endAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `true`, the `input` will indicate an error.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The id of the `input` element.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the `input` element.
   * Either a string to use a HTML element or a component.
   * @default 'input'
   */ inputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * @default {}
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a ref to the `input` element.
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * The label of the `input`. It is only used for layout. The actual labelling
   * is handled by `InputLabel`.
   */ label: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   * The prop defaults to the value (`'none'`) inherited from the parent FormControl component.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none'
    ]),
    /**
   * Maximum number of rows to display when multiline option is set to true.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display when multiline option is set to true.
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, a [TextareaAutosize](https://mui.com/material-ui/react-textarea-autosize/) element is rendered.
   * @default false
   */ multiline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the outline is notched to accommodate the label.
   */ notched: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Callback fired when the value is changed.
   *
   * @param {React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The short hint displayed in the `input` before the user enters a value.
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * It prevents the user from changing the value of the field
   * (not from interacting with the field).
   */ readOnly: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` element is required.
   * The prop defaults to the value (`false`) inherited from the parent FormControl component.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Number of rows to display when multiline option is set to true.
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The props used for each slot inside.
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        notchedOutline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The components used for each slot inside.
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        notchedOutline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * Start `InputAdornment` for this component.
   */ startAdornment: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#input_types).
   * @default 'text'
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The value of the `input` element, required for a controlled component.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
} : "TURBOPACK unreachable";
OutlinedInput.muiName = 'Input';
const __TURBOPACK__default__export__ = OutlinedInput;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/formLabelClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getFormLabelUtilityClasses",
    ()=>getFormLabelUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getFormLabelUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormLabel', slot);
}
const formLabelClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormLabel', [
    'root',
    'colorSecondary',
    'focused',
    'disabled',
    'error',
    'filled',
    'required',
    'asterisk'
]);
const __TURBOPACK__default__export__ = formLabelClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/FormLabel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormLabelRoot",
    ()=>FormLabelRoot,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/formLabelClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, color, focused, disabled, error, filled, required } = ownerState;
    const slots = {
        root: [
            'root',
            `color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(color)}`,
            disabled && 'disabled',
            error && 'error',
            filled && 'filled',
            focused && 'focused',
            required && 'required'
        ],
        asterisk: [
            'asterisk',
            error && 'error'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormLabelUtilityClasses"], classes);
};
const FormLabelRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('label', {
    name: 'MuiFormLabel',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            ownerState.color === 'secondary' && styles.colorSecondary,
            ownerState.filled && styles.filled
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        color: (theme.vars || theme).palette.text.secondary,
        ...theme.typography.body1,
        lineHeight: '1.4375em',
        padding: 0,
        position: 'relative',
        variants: [
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()).map(([color])=>({
                    props: {
                        color
                    },
                    style: {
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].focused}`]: {
                            color: (theme.vars || theme).palette[color].main
                        }
                    }
                })),
            {
                props: {},
                style: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
                        color: (theme.vars || theme).palette.text.disabled
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: {
                        color: (theme.vars || theme).palette.error.main
                    }
                }
            }
        ]
    })));
const AsteriskComponent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('span', {
    name: 'MuiFormLabel',
    slot: 'Asterisk'
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: {
            color: (theme.vars || theme).palette.error.main
        }
    })));
const FormLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FormLabel(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiFormLabel'
    });
    const { children, className, color, component = 'label', disabled, error, filled, focused, required, ...other } = props;
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'color',
            'required',
            'focused',
            'disabled',
            'error',
            'filled'
        ]
    });
    const ownerState = {
        ...props,
        color: fcs.color || 'primary',
        component,
        disabled: fcs.disabled,
        error: fcs.error,
        filled: fcs.filled,
        focused: fcs.focused,
        required: fcs.required
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(FormLabelRoot, {
        as: component,
        ownerState: ownerState,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        ref: ref,
        ...other,
        children: [
            children,
            fcs.required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(AsteriskComponent, {
                ownerState: ownerState,
                "aria-hidden": true,
                className: classes.asterisk,
                children: [
                    "\u2009",
                    '*'
                ]
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? FormLabel.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'error',
            'info',
            'primary',
            'secondary',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * If `true`, the label should be displayed in a disabled state.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is displayed in an error state.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label should use filled classes key.
   */ filled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the input of this label is focused (used by `FormGroup` components).
   */ focused: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label will indicate that the `input` is required.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = FormLabel;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/formLabelClasses.js [app-client] (ecmascript) <export default as formLabelClasses>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formLabelClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/formLabelClasses.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputLabel/inputLabelClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getInputLabelUtilityClasses",
    ()=>getInputLabelUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getInputLabelUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInputLabel', slot);
}
const inputLabelClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiInputLabel', [
    'root',
    'focused',
    'disabled',
    'error',
    'required',
    'asterisk',
    'formControl',
    'sizeSmall',
    'shrink',
    'animated',
    'standard',
    'filled',
    'outlined'
]);
const __TURBOPACK__default__export__ = inputLabelClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$FormLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/FormLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formLabelClasses$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormLabel/formLabelClasses.js [app-client] (ecmascript) <export default as formLabelClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputLabel/inputLabelClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, formControl, size, shrink, disableAnimation, variant, required } = ownerState;
    const slots = {
        root: [
            'root',
            formControl && 'formControl',
            !disableAnimation && 'animated',
            shrink && 'shrink',
            size && size !== 'medium' && `size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(size)}`,
            variant
        ],
        asterisk: [
            required && 'asterisk'
        ]
    };
    const composedClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInputLabelUtilityClasses"], classes);
    return {
        ...classes,
        // forward the focused, disabled, etc. classes to the FormLabel
        ...composedClasses
    };
};
const InputLabelRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$FormLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) || prop === 'classes',
    name: 'MuiInputLabel',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            {
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormLabel$2f$formLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formLabelClasses$3e$__["formLabelClasses"].asterisk}`]: styles.asterisk
            },
            styles.root,
            ownerState.formControl && styles.formControl,
            ownerState.size === 'small' && styles.sizeSmall,
            ownerState.shrink && styles.shrink,
            !ownerState.disableAnimation && styles.animated,
            ownerState.focused && styles.focused,
            styles[ownerState.variant]
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        display: 'block',
        transformOrigin: 'top left',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        maxWidth: '100%',
        variants: [
            {
                props: ({ ownerState })=>ownerState.formControl,
                style: {
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    // slight alteration to spec spacing to match visual spec result
                    transform: 'translate(0, 20px) scale(1)'
                }
            },
            {
                props: {
                    size: 'small'
                },
                style: {
                    // Compensation for the `Input.inputSizeSmall` style.
                    transform: 'translate(0, 17px) scale(1)'
                }
            },
            {
                props: ({ ownerState })=>ownerState.shrink,
                style: {
                    transform: 'translate(0, -1.5px) scale(0.75)',
                    transformOrigin: 'top left',
                    maxWidth: '133%'
                }
            },
            {
                props: ({ ownerState })=>!ownerState.disableAnimation,
                style: {
                    transition: theme.transitions.create([
                        'color',
                        'transform',
                        'max-width'
                    ], {
                        duration: theme.transitions.duration.shorter,
                        easing: theme.transitions.easing.easeOut
                    })
                }
            },
            {
                props: {
                    variant: 'filled'
                },
                style: {
                    // Chrome's autofill feature gives the input field a yellow background.
                    // Since the input field is behind the label in the HTML tree,
                    // the input field is drawn last and hides the label with an opaque background color.
                    // zIndex: 1 will raise the label above opaque background-colors of input.
                    zIndex: 1,
                    pointerEvents: 'none',
                    transform: 'translate(12px, 16px) scale(1)',
                    maxWidth: 'calc(100% - 24px)'
                }
            },
            {
                props: {
                    variant: 'filled',
                    size: 'small'
                },
                style: {
                    transform: 'translate(12px, 13px) scale(1)'
                }
            },
            {
                props: ({ variant, ownerState })=>variant === 'filled' && ownerState.shrink,
                style: {
                    userSelect: 'none',
                    pointerEvents: 'auto',
                    transform: 'translate(12px, 7px) scale(0.75)',
                    maxWidth: 'calc(133% - 24px)'
                }
            },
            {
                props: ({ variant, ownerState, size })=>variant === 'filled' && ownerState.shrink && size === 'small',
                style: {
                    transform: 'translate(12px, 4px) scale(0.75)'
                }
            },
            {
                props: {
                    variant: 'outlined'
                },
                style: {
                    // see comment above on filled.zIndex
                    zIndex: 1,
                    pointerEvents: 'none',
                    transform: 'translate(14px, 16px) scale(1)',
                    maxWidth: 'calc(100% - 24px)'
                }
            },
            {
                props: {
                    variant: 'outlined',
                    size: 'small'
                },
                style: {
                    transform: 'translate(14px, 9px) scale(1)'
                }
            },
            {
                props: ({ variant, ownerState })=>variant === 'outlined' && ownerState.shrink,
                style: {
                    userSelect: 'none',
                    pointerEvents: 'auto',
                    // Theoretically, we should have (8+5)*2/0.75 = 34px
                    // but it feels a better when it bleeds a bit on the left, so 32px.
                    maxWidth: 'calc(133% - 32px)',
                    transform: 'translate(14px, -9px) scale(0.75)'
                }
            }
        ]
    })));
const InputLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function InputLabel(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        name: 'MuiInputLabel',
        props: inProps
    });
    const { disableAnimation = false, margin, shrink: shrinkProp, variant, className, ...other } = props;
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    let shrink = shrinkProp;
    if (typeof shrink === 'undefined' && muiFormControl) {
        shrink = muiFormControl.filled || muiFormControl.focused || muiFormControl.adornedStart;
    }
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'size',
            'variant',
            'required',
            'focused'
        ]
    });
    const ownerState = {
        ...props,
        disableAnimation,
        formControl: muiFormControl,
        shrink,
        size: fcs.size,
        variant: fcs.variant,
        required: fcs.required,
        focused: fcs.focused
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputLabelRoot, {
        "data-shrink": shrink,
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        ...other,
        ownerState: ownerState,
        classes: classes
    });
});
("TURBOPACK compile-time truthy", 1) ? InputLabel.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'error',
            'info',
            'primary',
            'secondary',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, the transition animation is disabled.
   * @default false
   */ disableAnimation: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the component is disabled.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is displayed in an error state.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `input` of this label is focused.
   */ focused: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense'
    ]),
    /**
   * if `true`, the label will indicate that the `input` is required.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is shrunk.
   */ shrink: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The size of the component.
   * @default 'medium'
   */ size: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'medium',
            'small'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The variant to use.
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'filled',
        'outlined',
        'standard'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = InputLabel;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/isMuiElement/isMuiElement.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isMuiElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function isMuiElement(element, muiNames) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](element) && muiNames.indexOf(// For server components `muiName` is available in element.type._payload.value.muiName
    // relevant info - https://github.com/facebook/react/blob/2807d781a08db8e9873687fccc25c0f12b4fb3d4/packages/react/src/ReactLazy.js#L45
    // eslint-disable-next-line no-underscore-dangle
    element.type.muiName ?? element.type?._payload?.value?.muiName) !== -1;
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/isMuiElement.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isMuiElement$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/isMuiElement/isMuiElement.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isMuiElement$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getFormControlUtilityClasses",
    ()=>getFormControlUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getFormControlUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormControl', slot);
}
const formControlClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormControl', [
    'root',
    'marginNone',
    'marginNormal',
    'marginDense',
    'fullWidth',
    'disabled'
]);
const __TURBOPACK__default__export__ = formControlClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/isMuiElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControlContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, margin, fullWidth } = ownerState;
    const slots = {
        root: [
            'root',
            margin !== 'none' && `margin${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(margin)}`,
            fullWidth && 'fullWidth'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormControlUtilityClasses"], classes);
};
const FormControlRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiFormControl',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            styles[`margin${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.margin)}`],
            ownerState.fullWidth && styles.fullWidth
        ];
    }
})({
    display: 'inline-flex',
    flexDirection: 'column',
    position: 'relative',
    // Reset fieldset default style.
    minWidth: 0,
    padding: 0,
    margin: 0,
    border: 0,
    verticalAlign: 'top',
    // Fix alignment issue on Safari.
    variants: [
        {
            props: {
                margin: 'normal'
            },
            style: {
                marginTop: 16,
                marginBottom: 8
            }
        },
        {
            props: {
                margin: 'dense'
            },
            style: {
                marginTop: 8,
                marginBottom: 4
            }
        },
        {
            props: {
                fullWidth: true
            },
            style: {
                width: '100%'
            }
        }
    ]
});
/**
 * Provides context such as filled/focused/error/required for form inputs.
 * Relying on the context provides high flexibility and ensures that the state always stays
 * consistent across the children of the `FormControl`.
 * This context is used by the following components:
 *
 *  - FormLabel
 *  - FormHelperText
 *  - Input
 *  - InputLabel
 *
 * You can find one composition example below and more going to [the demos](/material-ui/react-text-field/#components).
 *
 * ```jsx
 * <FormControl>
 *   <InputLabel htmlFor="my-input">Email address</InputLabel>
 *   <Input id="my-input" aria-describedby="my-helper-text" />
 *   <FormHelperText id="my-helper-text">We'll never share your email.</FormHelperText>
 * </FormControl>
 * ```
 *
 * ⚠️ Only one `InputBase` can be used within a FormControl because it creates visual inconsistencies.
 * For instance, only one input can be focused at the same time, the state shouldn't be shared.
 */ const FormControl = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FormControl(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiFormControl'
    });
    const { children, className, color = 'primary', component = 'div', disabled = false, error = false, focused: visuallyFocused, fullWidth = false, hiddenLabel = false, margin = 'none', required = false, size = 'medium', variant = 'outlined', ...other } = props;
    const ownerState = {
        ...props,
        color,
        component,
        disabled,
        error,
        fullWidth,
        hiddenLabel,
        margin,
        required,
        size,
        variant
    };
    const classes = useUtilityClasses(ownerState);
    const [adornedStart, setAdornedStart] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "FormControl.FormControl.useState": ()=>{
            // We need to iterate through the children and find the Input in order
            // to fully support server-side rendering.
            let initialAdornedStart = false;
            if (children) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].forEach(children, {
                    "FormControl.FormControl.useState": (child)=>{
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(child, [
                            'Input',
                            'Select'
                        ])) {
                            return;
                        }
                        const input = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(child, [
                            'Select'
                        ]) ? child.props.input : child;
                        if (input && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAdornedStart"])(input.props)) {
                            initialAdornedStart = true;
                        }
                    }
                }["FormControl.FormControl.useState"]);
            }
            return initialAdornedStart;
        }
    }["FormControl.FormControl.useState"]);
    const [filled, setFilled] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "FormControl.FormControl.useState": ()=>{
            // We need to iterate through the children and find the Input in order
            // to fully support server-side rendering.
            let initialFilled = false;
            if (children) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].forEach(children, {
                    "FormControl.FormControl.useState": (child)=>{
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$isMuiElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(child, [
                            'Input',
                            'Select'
                        ])) {
                            return;
                        }
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFilled"])(child.props, true) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFilled"])(child.props.inputProps, true)) {
                            initialFilled = true;
                        }
                    }
                }["FormControl.FormControl.useState"]);
            }
            return initialFilled;
        }
    }["FormControl.FormControl.useState"]);
    const [focusedState, setFocused] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    if (disabled && focusedState) {
        setFocused(false);
    }
    const focused = visuallyFocused !== undefined && !disabled ? visuallyFocused : focusedState;
    let registerEffect;
    const registeredInput = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    if ("TURBOPACK compile-time truthy", 1) {
        registerEffect = ()=>{
            if (registeredInput.current) {
                console.error([
                    'MUI: There are multiple `InputBase` components inside a FormControl.',
                    'This creates visual inconsistencies, only use one `InputBase`.'
                ].join('\n'));
            }
            registeredInput.current = true;
            return ()=>{
                registeredInput.current = false;
            };
        };
    }
    const onFilled = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "FormControl.FormControl.useCallback[onFilled]": ()=>{
            setFilled(true);
        }
    }["FormControl.FormControl.useCallback[onFilled]"], []);
    const onEmpty = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "FormControl.FormControl.useCallback[onEmpty]": ()=>{
            setFilled(false);
        }
    }["FormControl.FormControl.useCallback[onEmpty]"], []);
    const childContext = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FormControl.FormControl.useMemo[childContext]": ()=>{
            return {
                adornedStart,
                setAdornedStart,
                color,
                disabled,
                error,
                filled,
                focused,
                fullWidth,
                hiddenLabel,
                size,
                onBlur: ({
                    "FormControl.FormControl.useMemo[childContext]": ()=>{
                        setFocused(false);
                    }
                })["FormControl.FormControl.useMemo[childContext]"],
                onFocus: ({
                    "FormControl.FormControl.useMemo[childContext]": ()=>{
                        setFocused(true);
                    }
                })["FormControl.FormControl.useMemo[childContext]"],
                onEmpty,
                onFilled,
                registerEffect,
                required,
                variant
            };
        }
    }["FormControl.FormControl.useMemo[childContext]"], [
        adornedStart,
        color,
        disabled,
        error,
        filled,
        focused,
        fullWidth,
        hiddenLabel,
        registerEffect,
        onEmpty,
        onFilled,
        required,
        size,
        variant
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControlContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: childContext,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FormControlRoot, {
            as: component,
            ownerState: ownerState,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
            ref: ref,
            ...other,
            children: children
        })
    });
});
("TURBOPACK compile-time truthy", 1) ? FormControl.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * @default 'primary'
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary',
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * If `true`, the label, input and helper text should be displayed in a disabled state.
   * @default false
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is displayed in an error state.
   * @default false
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the component is displayed in focused state.
   */ focused: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the component will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is hidden.
   * This is used to increase density for a `FilledInput`.
   * Be sure to add `aria-label` to the `input` element.
   * @default false
   */ hiddenLabel: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `dense` or `normal`, will adjust vertical spacing of this and contained components.
   * @default 'none'
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none',
        'normal'
    ]),
    /**
   * If `true`, the label will indicate that the `input` is required.
   * @default false
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The size of the component.
   * @default 'medium'
   */ size: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'medium',
            'small'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The variant to use.
   * @default 'outlined'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'filled',
        'outlined',
        'standard'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = FormControl;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormHelperText/formHelperTextClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getFormHelperTextUtilityClasses",
    ()=>getFormHelperTextUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getFormHelperTextUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormHelperText', slot);
}
const formHelperTextClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiFormHelperText', [
    'root',
    'error',
    'disabled',
    'sizeSmall',
    'sizeMedium',
    'contained',
    'focused',
    'filled',
    'required'
]);
const __TURBOPACK__default__export__ = formHelperTextClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormHelperText/FormHelperText.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$formHelperTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormHelperText/formHelperTextClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
var _span;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, contained, size, disabled, error, filled, focused, required } = ownerState;
    const slots = {
        root: [
            'root',
            disabled && 'disabled',
            error && 'error',
            size && `size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(size)}`,
            contained && 'contained',
            focused && 'focused',
            filled && 'filled',
            required && 'required'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$formHelperTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormHelperTextUtilityClasses"], classes);
};
const FormHelperTextRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('p', {
    name: 'MuiFormHelperText',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            ownerState.size && styles[`size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.size)}`],
            ownerState.contained && styles.contained,
            ownerState.filled && styles.filled
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        color: (theme.vars || theme).palette.text.secondary,
        ...theme.typography.caption,
        textAlign: 'left',
        marginTop: 3,
        marginRight: 0,
        marginBottom: 0,
        marginLeft: 0,
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$formHelperTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            color: (theme.vars || theme).palette.text.disabled
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$formHelperTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: {
            color: (theme.vars || theme).palette.error.main
        },
        variants: [
            {
                props: {
                    size: 'small'
                },
                style: {
                    marginTop: 4
                }
            },
            {
                props: ({ ownerState })=>ownerState.contained,
                style: {
                    marginLeft: 14,
                    marginRight: 14
                }
            }
        ]
    })));
const FormHelperText = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FormHelperText(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiFormHelperText'
    });
    const { children, className, component = 'p', disabled, error, filled, focused, margin, required, variant, ...other } = props;
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'variant',
            'size',
            'disabled',
            'error',
            'filled',
            'focused',
            'required'
        ]
    });
    const ownerState = {
        ...props,
        component,
        contained: fcs.variant === 'filled' || fcs.variant === 'outlined',
        variant: fcs.variant,
        size: fcs.size,
        disabled: fcs.disabled,
        error: fcs.error,
        filled: fcs.filled,
        focused: fcs.focused,
        required: fcs.required
    };
    // This issue explains why this is required: https://github.com/mui/material-ui/issues/42184
    delete ownerState.ownerState;
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FormHelperTextRoot, {
        as: component,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        ref: ref,
        ...other,
        ownerState: ownerState,
        children: children === ' ' ? _span || (_span = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            className: "notranslate",
            "aria-hidden": true,
            children: "\u200B"
        })) : children
    });
});
("TURBOPACK compile-time truthy", 1) ? FormHelperText.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The content of the component.
   *
   * If `' '` is provided, the component reserves one line height for displaying a future message.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * If `true`, the helper text should be displayed in a disabled state.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, helper text should be displayed in an error state.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the helper text should use filled classes key.
   */ filled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the helper text should use focused classes key.
   */ focused: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `dense`, will adjust vertical spacing. This is normally obtained via context from
   * FormControl.
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense'
    ]),
    /**
   * If `true`, the helper text should use required classes key.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The variant to use.
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'filled',
            'outlined',
            'standard'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = FormHelperText;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-is.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function typeOf(object) {
        if ("object" === typeof object && null !== object) {
            var $$typeof = object.$$typeof;
            switch($$typeof){
                case REACT_ELEMENT_TYPE:
                    switch(object = object.type, object){
                        case REACT_FRAGMENT_TYPE:
                        case REACT_PROFILER_TYPE:
                        case REACT_STRICT_MODE_TYPE:
                        case REACT_SUSPENSE_TYPE:
                        case REACT_SUSPENSE_LIST_TYPE:
                        case REACT_VIEW_TRANSITION_TYPE:
                            return object;
                        default:
                            switch(object = object && object.$$typeof, object){
                                case REACT_CONTEXT_TYPE:
                                case REACT_FORWARD_REF_TYPE:
                                case REACT_LAZY_TYPE:
                                case REACT_MEMO_TYPE:
                                    return object;
                                case REACT_CONSUMER_TYPE:
                                    return object;
                                default:
                                    return $$typeof;
                            }
                    }
                case REACT_PORTAL_TYPE:
                    return $$typeof;
            }
        }
    }
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
    exports.ContextConsumer = REACT_CONSUMER_TYPE;
    exports.ContextProvider = REACT_CONTEXT_TYPE;
    exports.Element = REACT_ELEMENT_TYPE;
    exports.ForwardRef = REACT_FORWARD_REF_TYPE;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Lazy = REACT_LAZY_TYPE;
    exports.Memo = REACT_MEMO_TYPE;
    exports.Portal = REACT_PORTAL_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.SuspenseList = REACT_SUSPENSE_LIST_TYPE;
    exports.isContextConsumer = function(object) {
        return typeOf(object) === REACT_CONSUMER_TYPE;
    };
    exports.isContextProvider = function(object) {
        return typeOf(object) === REACT_CONTEXT_TYPE;
    };
    exports.isElement = function(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    };
    exports.isForwardRef = function(object) {
        return typeOf(object) === REACT_FORWARD_REF_TYPE;
    };
    exports.isFragment = function(object) {
        return typeOf(object) === REACT_FRAGMENT_TYPE;
    };
    exports.isLazy = function(object) {
        return typeOf(object) === REACT_LAZY_TYPE;
    };
    exports.isMemo = function(object) {
        return typeOf(object) === REACT_MEMO_TYPE;
    };
    exports.isPortal = function(object) {
        return typeOf(object) === REACT_PORTAL_TYPE;
    };
    exports.isProfiler = function(object) {
        return typeOf(object) === REACT_PROFILER_TYPE;
    };
    exports.isStrictMode = function(object) {
        return typeOf(object) === REACT_STRICT_MODE_TYPE;
    };
    exports.isSuspense = function(object) {
        return typeOf(object) === REACT_SUSPENSE_TYPE;
    };
    exports.isSuspenseList = function(object) {
        return typeOf(object) === REACT_SUSPENSE_LIST_TYPE;
    };
    exports.isValidElementType = function(type) {
        return "string" === typeof type || "function" === typeof type || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || "object" === typeof type && null !== type && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE || void 0 !== type.getModuleId) ? !0 : !1;
    };
    exports.typeOf = typeOf;
}();
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)");
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerDocument.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ownerDocument$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/ownerDocument/ownerDocument.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ownerDocument$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useSlotProps/useSlotProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useForkRef/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$appendOwnerState$2f$appendOwnerState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/appendOwnerState/appendOwnerState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$mergeSlotProps$2f$mergeSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/mergeSlotProps/mergeSlotProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$resolveComponentProps$2f$resolveComponentProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/resolveComponentProps/resolveComponentProps.js [app-client] (ecmascript)");
'use client';
;
;
;
;
/**
 * @ignore - do not document.
 * Builds the props to be passed into the slot of an unstyled component.
 * It merges the internal props of the component with the ones supplied by the user, allowing to customize the behavior.
 * If the slot component is not a host component, it also merges in the `ownerState`.
 *
 * @param parameters.getSlotProps - A function that returns the props to be passed to the slot component.
 */ function useSlotProps(parameters) {
    const { elementType, externalSlotProps, ownerState, skipResolvingSlotProps = false, ...other } = parameters;
    const resolvedComponentsProps = skipResolvingSlotProps ? {} : (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$resolveComponentProps$2f$resolveComponentProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(externalSlotProps, ownerState);
    const { props: mergedProps, internalRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$mergeSlotProps$2f$mergeSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        ...other,
        externalSlotProps: resolvedComponentsProps
    });
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(internalRef, resolvedComponentsProps?.ref, parameters.additionalProps?.ref);
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$appendOwnerState$2f$appendOwnerState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(elementType, {
        ...mergedProps,
        ref
    }, ownerState);
    return props;
}
const __TURBOPACK__default__export__ = useSlotProps;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/getScrollbarSize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getScrollbarSize$2f$getScrollbarSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/getScrollbarSize/getScrollbarSize.js [app-client] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getScrollbarSize$2f$getScrollbarSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/MenuList/MenuList.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerDocument.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$getScrollbarSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/getScrollbarSize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useEnhancedEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ownerWindow$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerWindow.js [app-client] (ecmascript) <export default as ownerWindow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
function nextItem(list, item, disableListWrap) {
    if (list === item) {
        return list.firstChild;
    }
    if (item && item.nextElementSibling) {
        return item.nextElementSibling;
    }
    return disableListWrap ? null : list.firstChild;
}
function previousItem(list, item, disableListWrap) {
    if (list === item) {
        return disableListWrap ? list.firstChild : list.lastChild;
    }
    if (item && item.previousElementSibling) {
        return item.previousElementSibling;
    }
    return disableListWrap ? null : list.lastChild;
}
function textCriteriaMatches(nextFocus, textCriteria) {
    if (textCriteria === undefined) {
        return true;
    }
    let text = nextFocus.innerText;
    if (text === undefined) {
        // jsdom doesn't support innerText
        text = nextFocus.textContent;
    }
    text = text.trim().toLowerCase();
    if (text.length === 0) {
        return false;
    }
    if (textCriteria.repeating) {
        return text[0] === textCriteria.keys[0];
    }
    return text.startsWith(textCriteria.keys.join(''));
}
function moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, traversalFunction, textCriteria) {
    let wrappedOnce = false;
    let nextFocus = traversalFunction(list, currentFocus, currentFocus ? disableListWrap : false);
    while(nextFocus){
        // Prevent infinite loop.
        if (nextFocus === list.firstChild) {
            if (wrappedOnce) {
                return false;
            }
            wrappedOnce = true;
        }
        // Same logic as useAutocomplete.js
        const nextFocusDisabled = disabledItemsFocusable ? false : nextFocus.disabled || nextFocus.getAttribute('aria-disabled') === 'true';
        if (!nextFocus.hasAttribute('tabindex') || !textCriteriaMatches(nextFocus, textCriteria) || nextFocusDisabled) {
            // Move to the next element.
            nextFocus = traversalFunction(list, nextFocus, disableListWrap);
        } else {
            nextFocus.focus();
            return true;
        }
    }
    return false;
}
/**
 * A permanently displayed menu following https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/.
 * It's exposed to help customization of the [`Menu`](/material-ui/api/menu/) component if you
 * use it separately you need to move focus into the component manually. Once
 * the focus is placed inside the component it is fully keyboard accessible.
 */ const MenuList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuList(props, ref) {
    const { // private
    // eslint-disable-next-line react/prop-types
    actions, autoFocus = false, autoFocusItem = false, children, className, disabledItemsFocusable = false, disableListWrap = false, onKeyDown, variant = 'selectedMenu', ...other } = props;
    const listRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const textCriteriaRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        keys: [],
        repeating: true,
        previousKeyMatched: true,
        lastTime: null
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useEnhancedEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "MenuList.MenuList.useEnhancedEffect": ()=>{
            if (autoFocus) {
                listRef.current.focus();
            }
        }
    }["MenuList.MenuList.useEnhancedEffect"], [
        autoFocus
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](actions, {
        "MenuList.MenuList.useImperativeHandle": ()=>({
                adjustStyleForScrollbar: ({
                    "MenuList.MenuList.useImperativeHandle": (containerElement, { direction })=>{
                        // Let's ignore that piece of logic if users are already overriding the width
                        // of the menu.
                        const noExplicitWidth = !listRef.current.style.width;
                        if (containerElement.clientHeight < listRef.current.clientHeight && noExplicitWidth) {
                            const scrollbarSize = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$getScrollbarSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ownerWindow$3e$__["ownerWindow"])(containerElement))}px`;
                            listRef.current.style[direction === 'rtl' ? 'paddingLeft' : 'paddingRight'] = scrollbarSize;
                            listRef.current.style.width = `calc(100% + ${scrollbarSize})`;
                        }
                        return listRef.current;
                    }
                })["MenuList.MenuList.useImperativeHandle"]
            })
    }["MenuList.MenuList.useImperativeHandle"], []);
    const handleKeyDown = (event)=>{
        const list = listRef.current;
        const key = event.key;
        const isModifierKeyPressed = event.ctrlKey || event.metaKey || event.altKey;
        if (isModifierKeyPressed) {
            if (onKeyDown) {
                onKeyDown(event);
            }
            return;
        }
        /**
     * @type {Element} - will always be defined since we are in a keydown handler
     * attached to an element. A keydown event is either dispatched to the activeElement
     * or document.body or document.documentElement. Only the first case will
     * trigger this specific handler.
     */ const currentFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(list).activeElement;
        if (key === 'ArrowDown') {
            // Prevent scroll of the page
            event.preventDefault();
            moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, nextItem);
        } else if (key === 'ArrowUp') {
            event.preventDefault();
            moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, previousItem);
        } else if (key === 'Home') {
            event.preventDefault();
            moveFocus(list, null, disableListWrap, disabledItemsFocusable, nextItem);
        } else if (key === 'End') {
            event.preventDefault();
            moveFocus(list, null, disableListWrap, disabledItemsFocusable, previousItem);
        } else if (key.length === 1) {
            const criteria = textCriteriaRef.current;
            const lowerKey = key.toLowerCase();
            const currTime = performance.now();
            if (criteria.keys.length > 0) {
                // Reset
                if (currTime - criteria.lastTime > 500) {
                    criteria.keys = [];
                    criteria.repeating = true;
                    criteria.previousKeyMatched = true;
                } else if (criteria.repeating && lowerKey !== criteria.keys[0]) {
                    criteria.repeating = false;
                }
            }
            criteria.lastTime = currTime;
            criteria.keys.push(lowerKey);
            const keepFocusOnCurrent = currentFocus && !criteria.repeating && textCriteriaMatches(currentFocus, criteria);
            if (criteria.previousKeyMatched && (keepFocusOnCurrent || moveFocus(list, currentFocus, false, disabledItemsFocusable, nextItem, criteria))) {
                event.preventDefault();
            } else {
                criteria.previousKeyMatched = false;
            }
        }
        if (onKeyDown) {
            onKeyDown(event);
        }
    };
    const handleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(listRef, ref);
    /**
   * the index of the item should receive focus
   * in a `variant="selectedMenu"` it's the first `selected` item
   * otherwise it's the very first item.
   */ let activeItemIndex = -1;
    // since we inject focus related props into children we have to do a lookahead
    // to check if there is a `selected` item. We're looking for the last `selected`
    // item and use the first valid item as a fallback
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].forEach(children, (child, index)=>{
        if (!/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](child)) {
            if (activeItemIndex === index) {
                activeItemIndex += 1;
                if (activeItemIndex >= children.length) {
                    // there are no focusable items within the list.
                    activeItemIndex = -1;
                }
            }
            return;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFragment"])(child)) {
                console.error([
                    "MUI: The Menu component doesn't accept a Fragment as a child.",
                    'Consider providing an array instead.'
                ].join('\n'));
            }
        }
        if (!child.props.disabled) {
            if (variant === 'selectedMenu' && child.props.selected) {
                activeItemIndex = index;
            } else if (activeItemIndex === -1) {
                activeItemIndex = index;
            }
        }
        if (activeItemIndex === index && (child.props.disabled || child.props.muiSkipListHighlight || child.type.muiSkipListHighlight)) {
            activeItemIndex += 1;
            if (activeItemIndex >= children.length) {
                // there are no focusable items within the list.
                activeItemIndex = -1;
            }
        }
    });
    const items = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].map(children, (child, index)=>{
        if (index === activeItemIndex) {
            const newChildProps = {};
            if (autoFocusItem) {
                newChildProps.autoFocus = true;
            }
            if (child.props.tabIndex === undefined && variant === 'selectedMenu') {
                newChildProps.tabIndex = 0;
            }
            return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](child, newChildProps);
        }
        return child;
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        role: "menu",
        ref: handleRef,
        className: className,
        onKeyDown: handleKeyDown,
        tabIndex: autoFocus ? 0 : -1,
        ...other,
        children: items
    });
});
("TURBOPACK compile-time truthy", 1) ? MenuList.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * If `true`, will focus the `[role="menu"]` container and move into tab order.
   * @default false
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, will focus the first menuitem if `variant="menu"` or selected item
   * if `variant="selectedMenu"`.
   * @default false
   */ autoFocusItem: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * MenuList contents, normally `MenuItem`s.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, will allow focus on disabled items.
   * @default false
   */ disabledItemsFocusable: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the menu items will not wrap focus.
   * @default false
   */ disableListWrap: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * @ignore
   */ onKeyDown: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The variant to use. Use `menu` to prevent selected items from impacting the initial focus
   * and the vertical alignment relative to the anchor element.
   * @default 'selectedMenu'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'menu',
        'selectedMenu'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = MenuList;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Grow/Grow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useTimeout$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useTimeout/useTimeout.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementAcceptingRef$2f$elementAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/elementAcceptingRef/elementAcceptingRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getReactElementRef$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/getReactElementRef/getReactElementRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Transition$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/react-transition-group/esm/Transition.js [app-client] (ecmascript) <export default as Transition>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$transitions$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/transitions/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
function getScale(value) {
    return `scale(${value}, ${value ** 2})`;
}
const styles = {
    entering: {
        opacity: 1,
        transform: getScale(1)
    },
    entered: {
        opacity: 1,
        transform: 'none'
    }
};
/*
 TODO v6: remove
 Conditionally apply a workaround for the CSS transition bug in Safari 15.4 / WebKit browsers.
 */ const isWebKit154 = typeof navigator !== 'undefined' && /^((?!chrome|android).)*(safari|mobile)/i.test(navigator.userAgent) && /(os |version\/)15(.|_)4/i.test(navigator.userAgent);
/**
 * The Grow transition is used by the [Tooltip](/material-ui/react-tooltip/) and
 * [Popover](/material-ui/react-popover/) components.
 * It uses [react-transition-group](https://github.com/reactjs/react-transition-group) internally.
 */ const Grow = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Grow(props, ref) {
    const { addEndListener, appear = true, children, easing, in: inProp, onEnter, onEntered, onEntering, onExit, onExited, onExiting, style, timeout = 'auto', // eslint-disable-next-line react/prop-types
    TransitionComponent = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$react$2d$transition$2d$group$2f$esm$2f$Transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Transition$3e$__["Transition"], ...other } = props;
    const timer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useTimeout$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const autoTimeout = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const nodeRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const handleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nodeRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getReactElementRef$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(children), ref);
    const normalizedTransitionCallback = (callback)=>(maybeIsAppearing)=>{
            if (callback) {
                const node = nodeRef.current;
                // onEnterXxx and onExitXxx callbacks have a different arguments.length value.
                if (maybeIsAppearing === undefined) {
                    callback(node);
                } else {
                    callback(node, maybeIsAppearing);
                }
            }
        };
    const handleEntering = normalizedTransitionCallback(onEntering);
    const handleEnter = normalizedTransitionCallback((node, isAppearing)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$transitions$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reflow"])(node); // So the animation always start from the start.
        const { duration: transitionDuration, delay, easing: transitionTimingFunction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$transitions$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTransitionProps"])({
            style,
            timeout,
            easing
        }, {
            mode: 'enter'
        });
        let duration;
        if (timeout === 'auto') {
            duration = theme.transitions.getAutoHeightDuration(node.clientHeight);
            autoTimeout.current = duration;
        } else {
            duration = transitionDuration;
        }
        node.style.transition = [
            theme.transitions.create('opacity', {
                duration,
                delay
            }),
            theme.transitions.create('transform', {
                duration: isWebKit154 ? duration : duration * 0.666,
                delay,
                easing: transitionTimingFunction
            })
        ].join(',');
        if (onEnter) {
            onEnter(node, isAppearing);
        }
    });
    const handleEntered = normalizedTransitionCallback(onEntered);
    const handleExiting = normalizedTransitionCallback(onExiting);
    const handleExit = normalizedTransitionCallback((node)=>{
        const { duration: transitionDuration, delay, easing: transitionTimingFunction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$transitions$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTransitionProps"])({
            style,
            timeout,
            easing
        }, {
            mode: 'exit'
        });
        let duration;
        if (timeout === 'auto') {
            duration = theme.transitions.getAutoHeightDuration(node.clientHeight);
            autoTimeout.current = duration;
        } else {
            duration = transitionDuration;
        }
        node.style.transition = [
            theme.transitions.create('opacity', {
                duration,
                delay
            }),
            theme.transitions.create('transform', {
                duration: isWebKit154 ? duration : duration * 0.666,
                delay: isWebKit154 ? delay : delay || duration * 0.333,
                easing: transitionTimingFunction
            })
        ].join(',');
        node.style.opacity = 0;
        node.style.transform = getScale(0.75);
        if (onExit) {
            onExit(node);
        }
    });
    const handleExited = normalizedTransitionCallback(onExited);
    const handleAddEndListener = (next)=>{
        if (timeout === 'auto') {
            timer.start(autoTimeout.current || 0, next);
        }
        if (addEndListener) {
            // Old call signature before `react-transition-group` implemented `nodeRef`
            addEndListener(nodeRef.current, next);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TransitionComponent, {
        appear: appear,
        in: inProp,
        nodeRef: nodeRef,
        onEnter: handleEnter,
        onEntered: handleEntered,
        onEntering: handleEntering,
        onExit: handleExit,
        onExited: handleExited,
        onExiting: handleExiting,
        addEndListener: handleAddEndListener,
        timeout: timeout === 'auto' ? null : timeout,
        ...other,
        children: (state, { ownerState, ...restChildProps })=>{
            return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](children, {
                style: {
                    opacity: 0,
                    transform: getScale(0.75),
                    visibility: state === 'exited' && !inProp ? 'hidden' : undefined,
                    ...styles[state],
                    ...style,
                    ...children.props.style
                },
                ref: handleRef,
                ...restChildProps
            });
        }
    });
});
("TURBOPACK compile-time truthy", 1) ? Grow.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * Add a custom transition end trigger. Called with the transitioning DOM
   * node and a done callback. Allows for more fine grained transition end
   * logic. Note: Timeouts are still used as a fallback if provided.
   */ addEndListener: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Perform the enter transition when it first mounts if `in` is also `true`.
   * Set this to `false` to disable this behavior.
   * @default true
   */ appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * A single child content element.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementAcceptingRef$2f$elementAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isRequired,
    /**
   * The transition timing function.
   * You may specify a single easing or a object containing enter and exit values.
   */ easing: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, the component will transition in.
   */ in: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * @ignore
   */ onEnter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onEntered: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onEntering: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onExit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onExited: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onExiting: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ style: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The duration for the transition, in milliseconds.
   * You may specify a single timeout for all transitions, or individually with an object.
   *
   * Set to 'auto' to automatically calculate transition time based on height.
   * @default 'auto'
   */ timeout: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'auto'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        })
    ])
} : "TURBOPACK unreachable";
if (Grow) {
    Grow.muiSupportAuto = true;
}
const __TURBOPACK__default__export__ = Grow;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Popover/popoverClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getPopoverUtilityClass",
    ()=>getPopoverUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getPopoverUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiPopover', slot);
}
const popoverClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiPopover', [
    'root',
    'paper'
]);
const __TURBOPACK__default__export__ = popoverClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PopoverPaper",
    ()=>PopoverPaper,
    "PopoverRoot",
    ()=>PopoverRoot,
    "default",
    ()=>__TURBOPACK__default__export__,
    "getOffsetLeft",
    ()=>getOffsetLeft,
    "getOffsetTop",
    ()=>getOffsetTop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$HTMLElementType$2f$HTMLElementType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/HTMLElementType/HTMLElementType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementTypeAcceptingRef$2f$elementTypeAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/elementTypeAcceptingRef/elementTypeAcceptingRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$integerPropType$2f$integerPropType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/integerPropType/integerPropType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/chainPropTypes/chainPropTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isHostComponent$2f$isHostComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/isHostComponent/isHostComponent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/debounce.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerDocument.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerWindow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grow$2f$Grow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Grow/Grow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Modal/Modal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$popoverClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Popover/popoverClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useSlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$mergeSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mergeSlotProps$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/mergeSlotProps.js [app-client] (ecmascript) <export default as mergeSlotProps>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getOffsetTop(rect, vertical) {
    let offset = 0;
    if (typeof vertical === 'number') {
        offset = vertical;
    } else if (vertical === 'center') {
        offset = rect.height / 2;
    } else if (vertical === 'bottom') {
        offset = rect.height;
    }
    return offset;
}
function getOffsetLeft(rect, horizontal) {
    let offset = 0;
    if (typeof horizontal === 'number') {
        offset = horizontal;
    } else if (horizontal === 'center') {
        offset = rect.width / 2;
    } else if (horizontal === 'right') {
        offset = rect.width;
    }
    return offset;
}
function getTransformOriginValue(transformOrigin) {
    return [
        transformOrigin.horizontal,
        transformOrigin.vertical
    ].map((n)=>typeof n === 'number' ? `${n}px` : n).join(' ');
}
function resolveAnchorEl(anchorEl) {
    return typeof anchorEl === 'function' ? anchorEl() : anchorEl;
}
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ],
        paper: [
            'paper'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$popoverClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPopoverUtilityClass"], classes);
};
const PopoverRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Modal$2f$Modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiPopover',
    slot: 'Root'
})({});
const PopoverPaper = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiPopover',
    slot: 'Paper'
})({
    position: 'absolute',
    overflowY: 'auto',
    overflowX: 'hidden',
    // So we see the popover when it's empty.
    // It's most likely on issue on userland.
    minWidth: 16,
    minHeight: 16,
    maxWidth: 'calc(100% - 32px)',
    maxHeight: 'calc(100% - 32px)',
    // We disable the focus ring for mouse, touch and keyboard users.
    outline: 0
});
const Popover = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Popover(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiPopover'
    });
    const { action, anchorEl, anchorOrigin = {
        vertical: 'top',
        horizontal: 'left'
    }, anchorPosition, anchorReference = 'anchorEl', children, className, container: containerProp, elevation = 8, marginThreshold = 16, open, PaperProps: PaperPropsProp = {}, // TODO: remove in v7
    slots = {}, slotProps = {}, transformOrigin = {
        vertical: 'top',
        horizontal: 'left'
    }, TransitionComponent, // TODO: remove in v7
    transitionDuration: transitionDurationProp = 'auto', TransitionProps = {}, // TODO: remove in v7
    disableScrollLock = false, ...other } = props;
    const paperRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    const ownerState = {
        ...props,
        anchorOrigin,
        anchorReference,
        elevation,
        marginThreshold,
        transformOrigin,
        TransitionComponent,
        transitionDuration: transitionDurationProp,
        TransitionProps
    };
    const classes = useUtilityClasses(ownerState);
    // Returns the top/left offset of the position
    // to attach to on the anchor element (or body if none is provided)
    const getAnchorOffset = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Popover.Popover.useCallback[getAnchorOffset]": ()=>{
            if (anchorReference === 'anchorPosition') {
                if ("TURBOPACK compile-time truthy", 1) {
                    if (!anchorPosition) {
                        console.error('MUI: You need to provide a `anchorPosition` prop when using ' + '<Popover anchorReference="anchorPosition" />.');
                    }
                }
                return anchorPosition;
            }
            const resolvedAnchorEl = resolveAnchorEl(anchorEl);
            // If an anchor element wasn't provided, just use the parent body element of this Popover
            const anchorElement = resolvedAnchorEl && resolvedAnchorEl.nodeType === 1 ? resolvedAnchorEl : (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(paperRef.current).body;
            const anchorRect = anchorElement.getBoundingClientRect();
            if ("TURBOPACK compile-time truthy", 1) {
                const box = anchorElement.getBoundingClientRect();
                if (("TURBOPACK compile-time value", "development") !== 'test' && box.top === 0 && box.left === 0 && box.right === 0 && box.bottom === 0) {
                    console.warn([
                        'MUI: The `anchorEl` prop provided to the component is invalid.',
                        'The anchor element should be part of the document layout.',
                        "Make sure the element is present in the document or that it's not display none."
                    ].join('\n'));
                }
            }
            return {
                top: anchorRect.top + getOffsetTop(anchorRect, anchorOrigin.vertical),
                left: anchorRect.left + getOffsetLeft(anchorRect, anchorOrigin.horizontal)
            };
        }
    }["Popover.Popover.useCallback[getAnchorOffset]"], [
        anchorEl,
        anchorOrigin.horizontal,
        anchorOrigin.vertical,
        anchorPosition,
        anchorReference
    ]);
    // Returns the base transform origin using the element
    const getTransformOrigin = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Popover.Popover.useCallback[getTransformOrigin]": (elemRect)=>{
            return {
                vertical: getOffsetTop(elemRect, transformOrigin.vertical),
                horizontal: getOffsetLeft(elemRect, transformOrigin.horizontal)
            };
        }
    }["Popover.Popover.useCallback[getTransformOrigin]"], [
        transformOrigin.horizontal,
        transformOrigin.vertical
    ]);
    const getPositioningStyle = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Popover.Popover.useCallback[getPositioningStyle]": (element)=>{
            const elemRect = {
                width: element.offsetWidth,
                height: element.offsetHeight
            };
            // Get the transform origin point on the element itself
            const elemTransformOrigin = getTransformOrigin(elemRect);
            if (anchorReference === 'none') {
                return {
                    top: null,
                    left: null,
                    transformOrigin: getTransformOriginValue(elemTransformOrigin)
                };
            }
            // Get the offset of the anchoring element
            const anchorOffset = getAnchorOffset();
            // Calculate element positioning
            let top = anchorOffset.top - elemTransformOrigin.vertical;
            let left = anchorOffset.left - elemTransformOrigin.horizontal;
            const bottom = top + elemRect.height;
            const right = left + elemRect.width;
            // Use the parent window of the anchorEl if provided
            const containerWindow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(resolveAnchorEl(anchorEl));
            // Window thresholds taking required margin into account
            const heightThreshold = containerWindow.innerHeight - marginThreshold;
            const widthThreshold = containerWindow.innerWidth - marginThreshold;
            // Check if the vertical axis needs shifting
            if (marginThreshold !== null && top < marginThreshold) {
                const diff = top - marginThreshold;
                top -= diff;
                elemTransformOrigin.vertical += diff;
            } else if (marginThreshold !== null && bottom > heightThreshold) {
                const diff = bottom - heightThreshold;
                top -= diff;
                elemTransformOrigin.vertical += diff;
            }
            if ("TURBOPACK compile-time truthy", 1) {
                if (elemRect.height > heightThreshold && elemRect.height && heightThreshold) {
                    console.error([
                        'MUI: The popover component is too tall.',
                        `Some part of it can not be seen on the screen (${elemRect.height - heightThreshold}px).`,
                        'Please consider adding a `max-height` to improve the user-experience.'
                    ].join('\n'));
                }
            }
            // Check if the horizontal axis needs shifting
            if (marginThreshold !== null && left < marginThreshold) {
                const diff = left - marginThreshold;
                left -= diff;
                elemTransformOrigin.horizontal += diff;
            } else if (right > widthThreshold) {
                const diff = right - widthThreshold;
                left -= diff;
                elemTransformOrigin.horizontal += diff;
            }
            return {
                top: `${Math.round(top)}px`,
                left: `${Math.round(left)}px`,
                transformOrigin: getTransformOriginValue(elemTransformOrigin)
            };
        }
    }["Popover.Popover.useCallback[getPositioningStyle]"], [
        anchorEl,
        anchorReference,
        getAnchorOffset,
        getTransformOrigin,
        marginThreshold
    ]);
    const [isPositioned, setIsPositioned] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](open);
    const setPositioningStyles = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Popover.Popover.useCallback[setPositioningStyles]": ()=>{
            const element = paperRef.current;
            if (!element) {
                return;
            }
            const positioning = getPositioningStyle(element);
            if (positioning.top !== null) {
                element.style.setProperty('top', positioning.top);
            }
            if (positioning.left !== null) {
                element.style.left = positioning.left;
            }
            element.style.transformOrigin = positioning.transformOrigin;
            setIsPositioned(true);
        }
    }["Popover.Popover.useCallback[setPositioningStyles]"], [
        getPositioningStyle
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Popover.Popover.useEffect": ()=>{
            if (disableScrollLock) {
                window.addEventListener('scroll', setPositioningStyles);
            }
            return ({
                "Popover.Popover.useEffect": ()=>window.removeEventListener('scroll', setPositioningStyles)
            })["Popover.Popover.useEffect"];
        }
    }["Popover.Popover.useEffect"], [
        anchorEl,
        disableScrollLock,
        setPositioningStyles
    ]);
    const handleEntering = ()=>{
        setPositioningStyles();
    };
    const handleExited = ()=>{
        setIsPositioned(false);
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Popover.Popover.useEffect": ()=>{
            if (open) {
                setPositioningStyles();
            }
        }
    }["Popover.Popover.useEffect"]);
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](action, {
        "Popover.Popover.useImperativeHandle": ()=>open ? {
                updatePosition: ({
                    "Popover.Popover.useImperativeHandle": ()=>{
                        setPositioningStyles();
                    }
                })["Popover.Popover.useImperativeHandle"]
            } : null
    }["Popover.Popover.useImperativeHandle"], [
        open,
        setPositioningStyles
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Popover.Popover.useEffect": ()=>{
            if (!open) {
                return undefined;
            }
            const handleResize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "Popover.Popover.useEffect.handleResize": ()=>{
                    setPositioningStyles();
                }
            }["Popover.Popover.useEffect.handleResize"]);
            const containerWindow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerWindow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(resolveAnchorEl(anchorEl));
            containerWindow.addEventListener('resize', handleResize);
            return ({
                "Popover.Popover.useEffect": ()=>{
                    handleResize.clear();
                    containerWindow.removeEventListener('resize', handleResize);
                }
            })["Popover.Popover.useEffect"];
        }
    }["Popover.Popover.useEffect"], [
        anchorEl,
        open,
        setPositioningStyles
    ]);
    let transitionDuration = transitionDurationProp;
    const externalForwardedProps = {
        slots: {
            transition: TransitionComponent,
            ...slots
        },
        slotProps: {
            transition: TransitionProps,
            paper: PaperPropsProp,
            ...slotProps
        }
    };
    const [TransitionSlot, transitionSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('transition', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grow$2f$Grow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState,
        getSlotProps: {
            "Popover.Popover.useSlot": (handlers)=>({
                    ...handlers,
                    onEntering: ({
                        "Popover.Popover.useSlot": (element, isAppearing)=>{
                            handlers.onEntering?.(element, isAppearing);
                            handleEntering();
                        }
                    })["Popover.Popover.useSlot"],
                    onExited: ({
                        "Popover.Popover.useSlot": (element)=>{
                            handlers.onExited?.(element);
                            handleExited();
                        }
                    })["Popover.Popover.useSlot"]
                })
        }["Popover.Popover.useSlot"],
        additionalProps: {
            appear: true,
            in: open
        }
    });
    if (transitionDurationProp === 'auto' && !TransitionSlot.muiSupportAuto) {
        transitionDuration = undefined;
    }
    // If the container prop is provided, use that
    // If the anchorEl prop is provided, use its parent body element as the container
    // If neither are provided let the Modal take care of choosing the container
    const container = containerProp || (anchorEl ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(resolveAnchorEl(anchorEl)).body : undefined);
    const [RootSlot, { slots: rootSlotsProp, slotProps: rootSlotPropsProp, ...rootProps }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('root', {
        ref,
        elementType: PopoverRoot,
        externalForwardedProps: {
            ...externalForwardedProps,
            ...other
        },
        shouldForwardComponentProp: true,
        additionalProps: {
            slots: {
                backdrop: slots.backdrop
            },
            slotProps: {
                backdrop: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$mergeSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mergeSlotProps$3e$__["mergeSlotProps"])(typeof slotProps.backdrop === 'function' ? slotProps.backdrop(ownerState) : slotProps.backdrop, {
                    invisible: true
                })
            },
            container,
            open
        },
        ownerState,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className)
    });
    const [PaperSlot, paperProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('paper', {
        ref: paperRef,
        className: classes.paper,
        elementType: PopoverPaper,
        externalForwardedProps,
        shouldForwardComponentProp: true,
        additionalProps: {
            elevation,
            style: isPositioned ? undefined : {
                opacity: 0
            }
        },
        ownerState
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RootSlot, {
        ...rootProps,
        ...!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$isHostComponent$2f$isHostComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(RootSlot) && {
            slots: rootSlotsProp,
            slotProps: rootSlotPropsProp,
            disableScrollLock
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TransitionSlot, {
            ...transitionSlotProps,
            timeout: transitionDuration,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PaperSlot, {
                ...paperProps,
                children: children
            })
        })
    });
});
("TURBOPACK compile-time truthy", 1) ? Popover.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * A ref for imperative actions.
   * It currently only supports updatePosition() action.
   */ action: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * An HTML element, [PopoverVirtualElement](https://mui.com/material-ui/react-popover/#virtual-element),
   * or a function that returns either.
   * It's used to set the position of the popover.
   */ anchorEl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$HTMLElementType$2f$HTMLElementType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
    ]), (props)=>{
        if (props.open && (!props.anchorReference || props.anchorReference === 'anchorEl')) {
            const resolvedAnchorEl = resolveAnchorEl(props.anchorEl);
            if (resolvedAnchorEl && resolvedAnchorEl.nodeType === 1) {
                const box = resolvedAnchorEl.getBoundingClientRect();
                if (("TURBOPACK compile-time value", "development") !== 'test' && box.top === 0 && box.left === 0 && box.right === 0 && box.bottom === 0) {
                    return new Error([
                        'MUI: The `anchorEl` prop provided to the component is invalid.',
                        'The anchor element should be part of the document layout.',
                        "Make sure the element is present in the document or that it's not display none."
                    ].join('\n'));
                }
            } else {
                return new Error([
                    'MUI: The `anchorEl` prop provided to the component is invalid.',
                    `It should be an Element or PopoverVirtualElement instance but it's \`${resolvedAnchorEl}\` instead.`
                ].join('\n'));
            }
        }
        return null;
    }),
    /**
   * This is the point on the anchor where the popover's
   * `anchorEl` will attach to. This is not used when the
   * anchorReference is 'anchorPosition'.
   *
   * Options:
   * vertical: [top, center, bottom];
   * horizontal: [left, center, right].
   * @default {
   *   vertical: 'top',
   *   horizontal: 'left',
   * }
   */ anchorOrigin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        horizontal: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
                'center',
                'left',
                'right'
            ]),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired,
        vertical: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
                'bottom',
                'center',
                'top'
            ]),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired
    }),
    /**
   * This is the position that may be used to set the position of the popover.
   * The coordinates are relative to the application's client area.
   */ anchorPosition: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        left: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        top: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired
    }),
    /**
   * This determines which anchor prop to refer to when setting
   * the position of the popover.
   * @default 'anchorEl'
   */ anchorReference: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'anchorEl',
        'anchorPosition',
        'none'
    ]),
    /**
   * A backdrop component. This prop enables custom backdrop rendering.
   * @deprecated Use `slots.backdrop` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   * @default styled(Backdrop, {
   *   name: 'MuiModal',
   *   slot: 'Backdrop',
   *   overridesResolver: (props, styles) => {
   *     return styles.backdrop;
   *   },
   * })({
   *   zIndex: -1,
   * })
   */ BackdropComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * Props applied to the [`Backdrop`](/material-ui/api/backdrop/) element.
   * @deprecated Use `slotProps.backdrop` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ BackdropProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * An HTML element, component instance, or function that returns either.
   * The `container` will passed to the Modal component.
   *
   * By default, it uses the body of the anchorEl's top-level document object,
   * so it's simply `document.body` most of the time.
   */ container: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$HTMLElementType$2f$HTMLElementType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
    ]),
    /**
   * Disable the scroll lock behavior.
   * @default false
   */ disableScrollLock: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The elevation of the popover.
   * @default 8
   */ elevation: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$integerPropType$2f$integerPropType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * Specifies how close to the edge of the window the popover can appear.
   * If null, the popover will not be constrained by the window.
   * @default 16
   */ marginThreshold: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Callback fired when the component requests to be closed.
   * The `reason` parameter can optionally be used to control the response to `onClose`.
   */ onClose: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the component is shown.
   */ open: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    /**
   * Props applied to the [`Paper`](https://mui.com/material-ui/api/paper/) element.
   *
   * This prop is an alias for `slotProps.paper` and will be overridden by it if both are used.
   * @deprecated Use `slotProps.paper` instead.
   *
   * @default {}
   */ PaperProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .shape({
        component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$elementTypeAcceptingRef$2f$elementTypeAcceptingRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    }),
    /**
   * The props used for each slot inside.
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        backdrop: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        paper: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        transition: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ])
    }),
    /**
   * The components used for each slot inside.
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        backdrop: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        paper: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        transition: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * This is the point on the popover which
   * will attach to the anchor's origin.
   *
   * Options:
   * vertical: [top, center, bottom, x(px)];
   * horizontal: [left, center, right, x(px)].
   * @default {
   *   vertical: 'top',
   *   horizontal: 'left',
   * }
   */ transformOrigin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        horizontal: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
                'center',
                'left',
                'right'
            ]),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired,
        vertical: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
                'bottom',
                'center',
                'top'
            ]),
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired
    }),
    /**
   * The component used for the transition.
   * [Follow this guide](https://mui.com/material-ui/transitions/#transitioncomponent-prop) to learn more about the requirements for this component.
   * @deprecated use the `slots.transition` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   * @default Grow
   */ TransitionComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * Set to 'auto' to automatically calculate transition time based on height.
   * @default 'auto'
   */ transitionDuration: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'auto'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        })
    ]),
    /**
   * Props applied to the transition element.
   * By default, the element is based on this [`Transition`](https://reactcommunity.org/react-transition-group/transition/) component.
   * @deprecated use the `slotProps.transition` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   * @default {}
   */ TransitionProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Popover;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Menu/menuClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getMenuUtilityClass",
    ()=>getMenuUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getMenuUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiMenu', slot);
}
const menuClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiMenu', [
    'root',
    'paper',
    'list'
]);
const __TURBOPACK__default__export__ = menuClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPaper",
    ()=>MenuPaper,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$HTMLElementType$2f$HTMLElementType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/HTMLElementType/HTMLElementType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$RtlProvider$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/RtlProvider/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useSlotProps$2f$useSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useSlotProps/useSlotProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuList$2f$MenuList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/MenuList/MenuList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Popover/Popover.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$menuClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Menu/menuClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useSlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const RTL_ORIGIN = {
    vertical: 'top',
    horizontal: 'right'
};
const LTR_ORIGIN = {
    vertical: 'top',
    horizontal: 'left'
};
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ],
        paper: [
            'paper'
        ],
        list: [
            'list'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$menuClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMenuUtilityClass"], classes);
};
const MenuRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) || prop === 'classes',
    name: 'MuiMenu',
    slot: 'Root'
})({});
const MenuPaper = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popover$2f$Popover$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverPaper"], {
    name: 'MuiMenu',
    slot: 'Paper'
})({
    // specZ: The maximum height of a simple menu should be one or more rows less than the view
    // height. This ensures a tappable area outside of the simple menu with which to dismiss
    // the menu.
    maxHeight: 'calc(100% - 96px)',
    // Add iOS momentum scrolling for iOS < 13.0
    WebkitOverflowScrolling: 'touch'
});
const MenuMenuList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuList$2f$MenuList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiMenu',
    slot: 'List'
})({
    // We disable the focus ring for mouse, touch and keyboard users.
    outline: 0
});
const Menu = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Menu(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiMenu'
    });
    const { autoFocus = true, children, className, disableAutoFocusItem = false, MenuListProps = {}, onClose, open, PaperProps = {}, PopoverClasses, transitionDuration = 'auto', TransitionProps: { onEntering, ...TransitionProps } = {}, variant = 'selectedMenu', slots = {}, slotProps = {}, ...other } = props;
    const isRtl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$RtlProvider$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRtl"])();
    const ownerState = {
        ...props,
        autoFocus,
        disableAutoFocusItem,
        MenuListProps,
        onEntering,
        PaperProps,
        transitionDuration,
        TransitionProps,
        variant
    };
    const classes = useUtilityClasses(ownerState);
    const autoFocusItem = autoFocus && !disableAutoFocusItem && open;
    const menuListActionsRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const handleEntering = (element, isAppearing)=>{
        if (menuListActionsRef.current) {
            menuListActionsRef.current.adjustStyleForScrollbar(element, {
                direction: isRtl ? 'rtl' : 'ltr'
            });
        }
        if (onEntering) {
            onEntering(element, isAppearing);
        }
    };
    const handleListKeyDown = (event)=>{
        if (event.key === 'Tab') {
            event.preventDefault();
            if (onClose) {
                onClose(event, 'tabKeyDown');
            }
        }
    };
    /**
   * the index of the item should receive focus
   * in a `variant="selectedMenu"` it's the first `selected` item
   * otherwise it's the very first item.
   */ let activeItemIndex = -1;
    // since we inject focus related props into children we have to do a lookahead
    // to check if there is a `selected` item. We're looking for the last `selected`
    // item and use the first valid item as a fallback
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].map(children, (child, index)=>{
        if (!/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](child)) {
            return;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFragment"])(child)) {
                console.error([
                    "MUI: The Menu component doesn't accept a Fragment as a child.",
                    'Consider providing an array instead.'
                ].join('\n'));
            }
        }
        if (!child.props.disabled) {
            if (variant === 'selectedMenu' && child.props.selected) {
                activeItemIndex = index;
            } else if (activeItemIndex === -1) {
                activeItemIndex = index;
            }
        }
    });
    const externalForwardedProps = {
        slots,
        slotProps: {
            list: MenuListProps,
            transition: TransitionProps,
            paper: PaperProps,
            ...slotProps
        }
    };
    const rootSlotProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useSlotProps$2f$useSlotProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        elementType: slots.root,
        externalSlotProps: slotProps.root,
        ownerState,
        className: [
            classes.root,
            className
        ]
    });
    const [PaperSlot, paperSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('paper', {
        className: classes.paper,
        elementType: MenuPaper,
        externalForwardedProps,
        shouldForwardComponentProp: true,
        ownerState
    });
    const [ListSlot, listSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('list', {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.list, MenuListProps.className),
        elementType: MenuMenuList,
        shouldForwardComponentProp: true,
        externalForwardedProps,
        getSlotProps: {
            "Menu.Menu.useSlot": (handlers)=>({
                    ...handlers,
                    onKeyDown: ({
                        "Menu.Menu.useSlot": (event)=>{
                            handleListKeyDown(event);
                            handlers.onKeyDown?.(event);
                        }
                    })["Menu.Menu.useSlot"]
                })
        }["Menu.Menu.useSlot"],
        ownerState
    });
    const resolvedTransitionProps = typeof externalForwardedProps.slotProps.transition === 'function' ? externalForwardedProps.slotProps.transition(ownerState) : externalForwardedProps.slotProps.transition;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuRoot, {
        onClose: onClose,
        anchorOrigin: {
            vertical: 'bottom',
            horizontal: isRtl ? 'right' : 'left'
        },
        transformOrigin: isRtl ? RTL_ORIGIN : LTR_ORIGIN,
        slots: {
            root: slots.root,
            paper: PaperSlot,
            backdrop: slots.backdrop,
            ...slots.transition && {
                // TODO: pass `slots.transition` directly once `TransitionComponent` is removed from Popover
                transition: slots.transition
            }
        },
        slotProps: {
            root: rootSlotProps,
            paper: paperSlotProps,
            backdrop: typeof slotProps.backdrop === 'function' ? slotProps.backdrop(ownerState) : slotProps.backdrop,
            transition: {
                ...resolvedTransitionProps,
                onEntering: (...args)=>{
                    handleEntering(...args);
                    resolvedTransitionProps?.onEntering?.(...args);
                }
            }
        },
        open: open,
        ref: ref,
        transitionDuration: transitionDuration,
        ownerState: ownerState,
        ...other,
        classes: PopoverClasses,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ListSlot, {
            actions: menuListActionsRef,
            autoFocus: autoFocus && (activeItemIndex === -1 || disableAutoFocusItem),
            autoFocusItem: autoFocusItem,
            variant: variant,
            ...listSlotProps,
            children: children
        })
    });
});
("TURBOPACK compile-time truthy", 1) ? Menu.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * An HTML element, or a function that returns one.
   * It's used to set the position of the menu.
   */ anchorEl: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$HTMLElementType$2f$HTMLElementType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
    ]),
    /**
   * If `true` (Default) will focus the `[role="menu"]` if no focusable child is found. Disabled
   * children are not focusable. If you set this prop to `false` focus will be placed
   * on the parent modal container. This has severe accessibility implications
   * and should only be considered if you manage focus otherwise.
   * @default true
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Menu contents, normally `MenuItem`s.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * When opening the menu will not focus the active item but the `[role="menu"]`
   * unless `autoFocus` is also set to `false`. Not using the default means not
   * following WAI-ARIA authoring practices. Please be considerate about possible
   * accessibility implications.
   * @default false
   */ disableAutoFocusItem: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Props applied to the [`MenuList`](https://mui.com/material-ui/api/menu-list/) element.
   * @deprecated use the `slotProps.list` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   * @default {}
   */ MenuListProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Callback fired when the component requests to be closed.
   *
   * @param {object} event The event source of the callback.
   * @param {string} reason Can be: `"escapeKeyDown"`, `"backdropClick"`, `"tabKeyDown"`.
   */ onClose: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the component is shown.
   */ open: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    /**
   * @ignore
   */ PaperProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * `classes` prop applied to the [`Popover`](https://mui.com/material-ui/api/popover/) element.
   */ PopoverClasses: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The props used for each slot inside.
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        backdrop: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        list: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        paper: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        transition: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ])
    }),
    /**
   * The components used for each slot inside.
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        backdrop: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        list: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        paper: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        transition: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The length of the transition in `ms`, or 'auto'
   * @default 'auto'
   */ transitionDuration: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'auto'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            appear: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            enter: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
            exit: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        })
    ]),
    /**
   * Props applied to the transition element.
   * By default, the element is based on this [`Transition`](https://reactcommunity.org/react-transition-group/transition/) component.
   * @deprecated use the `slotProps.transition` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   * @default {}
   */ TransitionProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The variant to use. Use `menu` to prevent selected items from impacting the initial focus.
   * @default 'selectedMenu'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'menu',
        'selectedMenu'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Menu;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/NativeSelect/nativeSelectClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getNativeSelectUtilityClasses",
    ()=>getNativeSelectUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getNativeSelectUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiNativeSelect', slot);
}
const nativeSelectClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiNativeSelect', [
    'root',
    'select',
    'multiple',
    'filled',
    'outlined',
    'standard',
    'disabled',
    'icon',
    'iconOpen',
    'iconFilled',
    'iconOutlined',
    'iconStandard',
    'nativeInput',
    'error'
]);
const __TURBOPACK__default__export__ = nativeSelectClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/NativeSelect/NativeSelectInput.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StyledSelectIcon",
    ()=>StyledSelectIcon,
    "StyledSelectSelect",
    ()=>StyledSelectSelect,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$nativeSelectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/NativeSelect/nativeSelectClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, variant, disabled, multiple, open, error } = ownerState;
    const slots = {
        select: [
            'select',
            variant,
            disabled && 'disabled',
            multiple && 'multiple',
            error && 'error'
        ],
        icon: [
            'icon',
            `icon${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(variant)}`,
            open && 'iconOpen',
            disabled && 'disabled'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$nativeSelectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeSelectUtilityClasses"], classes);
};
const StyledSelectSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('select', {
    name: 'MuiNativeSelect'
})(({ theme })=>({
        // Reset
        MozAppearance: 'none',
        // Reset
        WebkitAppearance: 'none',
        // When interacting quickly, the text can end up selected.
        // Native select can't be selected either.
        userSelect: 'none',
        // Reset
        borderRadius: 0,
        cursor: 'pointer',
        '&:focus': {
            // Reset Chrome style
            borderRadius: 0
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$nativeSelectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            cursor: 'default'
        },
        '&[multiple]': {
            height: 'auto'
        },
        '&:not([multiple]) option, &:not([multiple]) optgroup': {
            backgroundColor: (theme.vars || theme).palette.background.paper
        },
        variants: [
            {
                props: ({ ownerState })=>ownerState.variant !== 'filled' && ownerState.variant !== 'outlined',
                style: {
                    // Bump specificity to allow extending custom inputs
                    '&&&': {
                        paddingRight: 24,
                        minWidth: 16 // So it doesn't collapse.
                    }
                }
            },
            {
                props: {
                    variant: 'filled'
                },
                style: {
                    '&&&': {
                        paddingRight: 32
                    }
                }
            },
            {
                props: {
                    variant: 'outlined'
                },
                style: {
                    borderRadius: (theme.vars || theme).shape.borderRadius,
                    '&:focus': {
                        borderRadius: (theme.vars || theme).shape.borderRadius // Reset the reset for Chrome style
                    },
                    '&&&': {
                        paddingRight: 32
                    }
                }
            }
        ]
    }));
const NativeSelectSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(StyledSelectSelect, {
    name: 'MuiNativeSelect',
    slot: 'Select',
    shouldForwardProp: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.select,
            styles[ownerState.variant],
            ownerState.error && styles.error,
            {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$nativeSelectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].multiple}`]: styles.multiple
            }
        ];
    }
})({});
const StyledSelectIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('svg', {
    name: 'MuiNativeSelect'
})(({ theme })=>({
        // We use a position absolute over a flexbox in order to forward the pointer events
        // to the input and to support wrapping tags..
        position: 'absolute',
        right: 0,
        // Center vertically, height is 1em
        top: 'calc(50% - .5em)',
        // Don't block pointer events on the select under the icon.
        pointerEvents: 'none',
        color: (theme.vars || theme).palette.action.active,
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$nativeSelectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            color: (theme.vars || theme).palette.action.disabled
        },
        variants: [
            {
                props: ({ ownerState })=>ownerState.open,
                style: {
                    transform: 'rotate(180deg)'
                }
            },
            {
                props: {
                    variant: 'filled'
                },
                style: {
                    right: 7
                }
            },
            {
                props: {
                    variant: 'outlined'
                },
                style: {
                    right: 7
                }
            }
        ]
    }));
const NativeSelectIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(StyledSelectIcon, {
    name: 'MuiNativeSelect',
    slot: 'Icon',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.icon,
            ownerState.variant && styles[`icon${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.variant)}`],
            ownerState.open && styles.iconOpen
        ];
    }
})({});
/**
 * @ignore - internal component.
 */ const NativeSelectInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function NativeSelectInput(props, ref) {
    const { className, disabled, error, IconComponent, inputRef, variant = 'standard', ...other } = props;
    const ownerState = {
        ...props,
        disabled,
        variant,
        error
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(NativeSelectSelect, {
                ownerState: ownerState,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.select, className),
                disabled: disabled,
                ref: inputRef || ref,
                ...other
            }),
            props.multiple ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(NativeSelectIcon, {
                as: IconComponent,
                ownerState: ownerState,
                className: classes.icon
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? NativeSelectInput.propTypes = {
    /**
   * The option elements to populate the select with.
   * Can be some `<option>` elements.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The CSS class name of the select element.
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the select is disabled.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `select input` will indicate an error.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The icon that displays the arrow.
   */ IconComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType.isRequired,
    /**
   * Use that prop to pass a ref to the native select element.
   * @deprecated
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * @ignore
   */ multiple: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `select` or hidden `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Callback fired when a menu item is selected.
   *
   * @param {object} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The input value.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * The variant to use.
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'standard',
        'outlined',
        'filled'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = NativeSelectInput;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useControlled/useControlled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useControlled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler -- process.env never changes, dependency arrays are intentionally ignored
/* eslint-disable react-hooks/rules-of-hooks, react-hooks/exhaustive-deps */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
function useControlled(props) {
    const { controlled, default: defaultProp, name, state = 'value' } = props;
    // isControlled is ignored in the hook dependency lists as it should never change.
    const { current: isControlled } = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](controlled !== undefined);
    const [valueState, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](defaultProp);
    const value = isControlled ? controlled : valueState;
    if ("TURBOPACK compile-time truthy", 1) {
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useControlled.useEffect": ()=>{
                if (isControlled !== (controlled !== undefined)) {
                    console.error([
                        `MUI: A component is changing the ${isControlled ? '' : 'un'}controlled ${state} state of ${name} to be ${isControlled ? 'un' : ''}controlled.`,
                        'Elements should not switch from uncontrolled to controlled (or vice versa).',
                        `Decide between using a controlled or uncontrolled ${name} ` + 'element for the lifetime of the component.',
                        "The nature of the state is determined during the first render. It's considered controlled if the value is not `undefined`.",
                        'More info: https://fb.me/react-controlled-components'
                    ].join('\n'));
                }
            }
        }["useControlled.useEffect"], [
            state,
            name,
            controlled
        ]);
        const { current: defaultValue } = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](defaultProp);
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useControlled.useEffect": ()=>{
                if (!isControlled && JSON.stringify(defaultProp) !== JSON.stringify(defaultValue)) {
                    console.error([
                        `MUI: A component is changing the default ${state} state of an uncontrolled ${name} after being initialized. ` + `To suppress this warning opt to use a controlled ${name}.`
                    ].join('\n'));
                }
            }
        }["useControlled.useEffect"], [
            JSON.stringify(defaultProp)
        ]);
    }
    const setValueIfUncontrolled = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useControlled.useCallback[setValueIfUncontrolled]": (newValue)=>{
            if (!isControlled) {
                setValue(newValue);
            }
        }
    }["useControlled.useCallback[setValueIfUncontrolled]"], []);
    // TODO: provide overloads for the useControlled function to account for the case where either
    // controlled or default is not undefined.
    // In that case the return type should be [T, React.Dispatch<React.SetStateAction<T>>]
    // otherwise it should be [T | undefined, React.Dispatch<React.SetStateAction<T | undefined>>]
    return [
        value,
        setValueIfUncontrolled
    ];
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useControlled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useControlled$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useControlled/useControlled.js [app-client] (ecmascript)");
'use client';
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useControlled$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/selectClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getSelectUtilityClasses",
    ()=>getSelectUtilityClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getSelectUtilityClasses(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiSelect', slot);
}
const selectClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiSelect', [
    'root',
    'select',
    'multiple',
    'filled',
    'outlined',
    'standard',
    'disabled',
    'focused',
    'icon',
    'iconOpen',
    'iconFilled',
    'iconOutlined',
    'iconStandard',
    'nativeInput',
    'error'
]);
const __TURBOPACK__default__export__ = selectClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/SelectInput.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/node_modules/react-is/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useId/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/ownerDocument.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$NativeSelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/NativeSelect/NativeSelectInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputBase/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$slotShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/slotShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useControlled.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/selectClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
var _span;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const SelectSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$NativeSelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSelectSelect"], {
    name: 'MuiSelect',
    slot: 'Select',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            // Win specificity over the input base
            {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].select}`]: styles.select
            },
            {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].select}`]: styles[ownerState.variant]
            },
            {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error}`]: styles.error
            },
            {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].multiple}`]: styles.multiple
            }
        ];
    }
})({
    // Win specificity over the input base
    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].select}`]: {
        height: 'auto',
        // Resets for multiple select with chips
        minHeight: '1.4375em',
        // Required for select\text-field height consistency
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        overflow: 'hidden'
    }
});
const SelectIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$NativeSelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StyledSelectIcon"], {
    name: 'MuiSelect',
    slot: 'Icon',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.icon,
            ownerState.variant && styles[`icon${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.variant)}`],
            ownerState.open && styles.iconOpen
        ];
    }
})({});
const SelectNativeInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('input', {
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$slotShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) && prop !== 'classes',
    name: 'MuiSelect',
    slot: 'NativeInput'
})({
    bottom: 0,
    left: 0,
    position: 'absolute',
    opacity: 0,
    pointerEvents: 'none',
    width: '100%',
    boxSizing: 'border-box'
});
function areEqualValues(a, b) {
    if (typeof b === 'object' && b !== null) {
        return a === b;
    }
    // The value could be a number, the DOM will stringify it anyway.
    return String(a) === String(b);
}
function isEmpty(display) {
    return display == null || typeof display === 'string' && !display.trim();
}
const useUtilityClasses = (ownerState)=>{
    const { classes, variant, disabled, multiple, open, error } = ownerState;
    const slots = {
        select: [
            'select',
            variant,
            disabled && 'disabled',
            multiple && 'multiple',
            error && 'error'
        ],
        icon: [
            'icon',
            `icon${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(variant)}`,
            open && 'iconOpen',
            disabled && 'disabled'
        ],
        nativeInput: [
            'nativeInput'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSelectUtilityClasses"], classes);
};
/**
 * @ignore - internal component.
 */ const SelectInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SelectInput(props, ref) {
    const { 'aria-describedby': ariaDescribedby, 'aria-label': ariaLabel, autoFocus, autoWidth, children, className, defaultOpen, defaultValue, disabled, displayEmpty, error = false, IconComponent, inputRef: inputRefProp, labelId, MenuProps = {}, multiple, name, onBlur, onChange, onClose, onFocus, onOpen, open: openProp, readOnly, renderValue, required, SelectDisplayProps = {}, tabIndex: tabIndexProp, // catching `type` from Input which makes no sense for SelectInput
    type, value: valueProp, variant = 'standard', ...other } = props;
    const [value, setValueState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        controlled: valueProp,
        default: defaultValue,
        name: 'Select'
    });
    const [openState, setOpenState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        controlled: openProp,
        default: defaultOpen,
        name: 'Select'
    });
    const inputRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const displayRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [displayNode, setDisplayNode] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const { current: isOpenControlled } = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](openProp != null);
    const [menuMinWidthState, setMenuMinWidthState] = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const handleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ref, inputRefProp);
    const handleDisplayRef = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "SelectInput.SelectInput.useCallback[handleDisplayRef]": (node)=>{
            displayRef.current = node;
            if (node) {
                setDisplayNode(node);
            }
        }
    }["SelectInput.SelectInput.useCallback[handleDisplayRef]"], []);
    const anchorElement = displayNode?.parentNode;
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](handleRef, {
        "SelectInput.SelectInput.useImperativeHandle": ()=>({
                focus: ({
                    "SelectInput.SelectInput.useImperativeHandle": ()=>{
                        displayRef.current.focus();
                    }
                })["SelectInput.SelectInput.useImperativeHandle"],
                node: inputRef.current,
                value
            })
    }["SelectInput.SelectInput.useImperativeHandle"], [
        value
    ]);
    // Resize menu on `defaultOpen` automatic toggle.
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "SelectInput.SelectInput.useEffect": ()=>{
            if (defaultOpen && openState && displayNode && !isOpenControlled) {
                setMenuMinWidthState(autoWidth ? null : anchorElement.clientWidth);
                displayRef.current.focus();
            }
        // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["SelectInput.SelectInput.useEffect"], [
        displayNode,
        autoWidth
    ]);
    // `isOpenControlled` is ignored because the component should never switch between controlled and uncontrolled modes.
    // `defaultOpen` and `openState` are ignored to avoid unnecessary callbacks.
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "SelectInput.SelectInput.useEffect": ()=>{
            if (autoFocus) {
                displayRef.current.focus();
            }
        }
    }["SelectInput.SelectInput.useEffect"], [
        autoFocus
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "SelectInput.SelectInput.useEffect": ()=>{
            if (!labelId) {
                return undefined;
            }
            const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$ownerDocument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(displayRef.current).getElementById(labelId);
            if (label) {
                const handler = {
                    "SelectInput.SelectInput.useEffect.handler": ()=>{
                        if (getSelection().isCollapsed) {
                            displayRef.current.focus();
                        }
                    }
                }["SelectInput.SelectInput.useEffect.handler"];
                label.addEventListener('click', handler);
                return ({
                    "SelectInput.SelectInput.useEffect": ()=>{
                        label.removeEventListener('click', handler);
                    }
                })["SelectInput.SelectInput.useEffect"];
            }
            return undefined;
        }
    }["SelectInput.SelectInput.useEffect"], [
        labelId
    ]);
    const update = (open, event)=>{
        if (open) {
            if (onOpen) {
                onOpen(event);
            }
        } else if (onClose) {
            onClose(event);
        }
        if (!isOpenControlled) {
            setMenuMinWidthState(autoWidth ? null : anchorElement.clientWidth);
            setOpenState(open);
        }
    };
    const handleMouseDown = (event)=>{
        // Ignore everything but left-click
        if (event.button !== 0) {
            return;
        }
        // Hijack the default focus behavior.
        event.preventDefault();
        displayRef.current.focus();
        update(true, event);
    };
    const handleClose = (event)=>{
        update(false, event);
    };
    const childrenArray = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(children);
    // Support autofill.
    const handleChange = (event)=>{
        const child = childrenArray.find((childItem)=>childItem.props.value === event.target.value);
        if (child === undefined) {
            return;
        }
        setValueState(child.props.value);
        if (onChange) {
            onChange(event, child);
        }
    };
    const handleItemClick = (child)=>(event)=>{
            let newValue;
            // We use the tabindex attribute to signal the available options.
            if (!event.currentTarget.hasAttribute('tabindex')) {
                return;
            }
            if (multiple) {
                newValue = Array.isArray(value) ? value.slice() : [];
                const itemIndex = value.indexOf(child.props.value);
                if (itemIndex === -1) {
                    newValue.push(child.props.value);
                } else {
                    newValue.splice(itemIndex, 1);
                }
            } else {
                newValue = child.props.value;
            }
            if (child.props.onClick) {
                child.props.onClick(event);
            }
            if (value !== newValue) {
                setValueState(newValue);
                if (onChange) {
                    // Redefine target to allow name and value to be read.
                    // This allows seamless integration with the most popular form libraries.
                    // https://github.com/mui/material-ui/issues/13485#issuecomment-676048492
                    // Clone the event to not override `target` of the original event.
                    const nativeEvent = event.nativeEvent || event;
                    const clonedEvent = new nativeEvent.constructor(nativeEvent.type, nativeEvent);
                    Object.defineProperty(clonedEvent, 'target', {
                        writable: true,
                        value: {
                            value: newValue,
                            name
                        }
                    });
                    onChange(clonedEvent, child);
                }
            }
            if (!multiple) {
                update(false, event);
            }
        };
    const handleKeyDown = (event)=>{
        if (!readOnly) {
            const validKeys = [
                ' ',
                'ArrowUp',
                'ArrowDown',
                // The native select doesn't respond to enter on macOS, but it's recommended by
                // https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/
                'Enter'
            ];
            if (validKeys.includes(event.key)) {
                event.preventDefault();
                update(true, event);
            }
        }
    };
    const open = displayNode !== null && openState;
    const handleBlur = (event)=>{
        // if open event.stopImmediatePropagation
        if (!open && onBlur) {
            // Preact support, target is read only property on a native event.
            Object.defineProperty(event, 'target', {
                writable: true,
                value: {
                    value,
                    name
                }
            });
            onBlur(event);
        }
    };
    delete other['aria-invalid'];
    let display;
    let displaySingle;
    const displayMultiple = [];
    let computeDisplay = false;
    let foundMatch = false;
    // No need to display any value if the field is empty.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFilled"])({
        value
    }) || displayEmpty) {
        if (renderValue) {
            display = renderValue(value);
        } else {
            computeDisplay = true;
        }
    }
    const items = childrenArray.map((child)=>{
        if (!/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](child)) {
            return null;
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFragment"])(child)) {
                console.error([
                    "MUI: The Select component doesn't accept a Fragment as a child.",
                    'Consider providing an array instead.'
                ].join('\n'));
            }
        }
        let selected;
        if (multiple) {
            if (!Array.isArray(value)) {
                throw new Error(("TURBOPACK compile-time truthy", 1) ? 'MUI: The `value` prop must be an array ' + 'when using the `Select` component with `multiple`.' : "TURBOPACK unreachable");
            }
            selected = value.some((v)=>areEqualValues(v, child.props.value));
            if (selected && computeDisplay) {
                displayMultiple.push(child.props.children);
            }
        } else {
            selected = areEqualValues(value, child.props.value);
            if (selected && computeDisplay) {
                displaySingle = child.props.children;
            }
        }
        if (selected) {
            foundMatch = true;
        }
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](child, {
            'aria-selected': selected ? 'true' : 'false',
            onClick: handleItemClick(child),
            onKeyUp: (event)=>{
                if (event.key === ' ') {
                    // otherwise our MenuItems dispatches a click event
                    // it's not behavior of the native <option> and causes
                    // the select to close immediately since we open on space keydown
                    event.preventDefault();
                }
                if (child.props.onKeyUp) {
                    child.props.onKeyUp(event);
                }
            },
            role: 'option',
            selected,
            value: undefined,
            // The value is most likely not a valid HTML attribute.
            'data-value': child.props.value // Instead, we provide it as a data attribute.
        });
    });
    if ("TURBOPACK compile-time truthy", 1) {
        // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "SelectInput.SelectInput.useEffect": ()=>{
                if (!foundMatch && !multiple && value !== '') {
                    const values = childrenArray.map({
                        "SelectInput.SelectInput.useEffect.values": (child)=>child.props.value
                    }["SelectInput.SelectInput.useEffect.values"]);
                    console.warn([
                        `MUI: You have provided an out-of-range value \`${value}\` for the select ${name ? `(name="${name}") ` : ''}component.`,
                        "Consider providing a value that matches one of the available options or ''.",
                        `The available values are ${values.filter({
                            "SelectInput.SelectInput.useEffect": (x)=>x != null
                        }["SelectInput.SelectInput.useEffect"]).map({
                            "SelectInput.SelectInput.useEffect": (x)=>`\`${x}\``
                        }["SelectInput.SelectInput.useEffect"]).join(', ') || '""'}.`
                    ].join('\n'));
                }
            }
        }["SelectInput.SelectInput.useEffect"], [
            foundMatch,
            childrenArray,
            multiple,
            name,
            value
        ]);
    }
    if (computeDisplay) {
        if (multiple) {
            if (displayMultiple.length === 0) {
                display = null;
            } else {
                display = displayMultiple.reduce((output, child, index)=>{
                    output.push(child);
                    if (index < displayMultiple.length - 1) {
                        output.push(', ');
                    }
                    return output;
                }, []);
            }
        } else {
            display = displaySingle;
        }
    }
    // Avoid performing a layout computation in the render method.
    let menuMinWidth = menuMinWidthState;
    if (!autoWidth && isOpenControlled && displayNode) {
        menuMinWidth = anchorElement.clientWidth;
    }
    let tabIndex;
    if (typeof tabIndexProp !== 'undefined') {
        tabIndex = tabIndexProp;
    } else {
        tabIndex = disabled ? null : 0;
    }
    const buttonId = SelectDisplayProps.id || (name ? `mui-component-select-${name}` : undefined);
    const ownerState = {
        ...props,
        variant,
        value,
        open,
        error
    };
    const classes = useUtilityClasses(ownerState);
    const paperProps = {
        ...MenuProps.PaperProps,
        ...typeof MenuProps.slotProps?.paper === 'function' ? MenuProps.slotProps.paper(ownerState) : MenuProps.slotProps?.paper
    };
    const listProps = {
        ...MenuProps.MenuListProps,
        ...typeof MenuProps.slotProps?.list === 'function' ? MenuProps.slotProps.list(ownerState) : MenuProps.slotProps?.list
    };
    const listboxId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SelectSelect, {
                as: "div",
                ref: handleDisplayRef,
                tabIndex: tabIndex,
                role: "combobox",
                "aria-controls": open ? listboxId : undefined,
                "aria-disabled": disabled ? 'true' : undefined,
                "aria-expanded": open ? 'true' : 'false',
                "aria-haspopup": "listbox",
                "aria-label": ariaLabel,
                "aria-labelledby": [
                    labelId,
                    buttonId
                ].filter(Boolean).join(' ') || undefined,
                "aria-describedby": ariaDescribedby,
                "aria-required": required ? 'true' : undefined,
                "aria-invalid": error ? 'true' : undefined,
                onKeyDown: handleKeyDown,
                onMouseDown: disabled || readOnly ? null : handleMouseDown,
                onBlur: handleBlur,
                onFocus: onFocus,
                ...SelectDisplayProps,
                ownerState: ownerState,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(SelectDisplayProps.className, classes.select, className),
                id: buttonId,
                children: isEmpty(display) ? _span || (_span = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "notranslate",
                    "aria-hidden": true,
                    children: "\u200B"
                })) : display
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SelectNativeInput, {
                "aria-invalid": error,
                value: Array.isArray(value) ? value.join(',') : value,
                name: name,
                ref: inputRef,
                "aria-hidden": true,
                onChange: handleChange,
                tabIndex: -1,
                disabled: disabled,
                className: classes.nativeInput,
                autoFocus: autoFocus,
                required: required,
                ...other,
                ownerState: ownerState
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SelectIcon, {
                as: IconComponent,
                className: classes.icon,
                ownerState: ownerState
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: `menu-${name || ''}`,
                anchorEl: anchorElement,
                open: open,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: 'bottom',
                    horizontal: 'center'
                },
                transformOrigin: {
                    vertical: 'top',
                    horizontal: 'center'
                },
                ...MenuProps,
                slotProps: {
                    ...MenuProps.slotProps,
                    list: {
                        'aria-labelledby': labelId,
                        role: 'listbox',
                        'aria-multiselectable': multiple ? 'true' : undefined,
                        disableListWrap: true,
                        id: listboxId,
                        ...listProps
                    },
                    paper: {
                        ...paperProps,
                        style: {
                            minWidth: menuMinWidth,
                            ...paperProps != null ? paperProps.style : null
                        }
                    }
                },
                children: items
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? SelectInput.propTypes = {
    /**
   * @ignore
   */ 'aria-describedby': __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * @ignore
   */ 'aria-label': __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * @ignore
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the width of the popover will automatically be set according to the items inside the
   * menu, otherwise it will be at least the width of the select input.
   */ autoWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The option elements to populate the select with.
   * Can be some `<MenuItem>` elements.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The CSS class name of the select element.
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the component is toggled on mount. Use when the component open state is not controlled.
   * You can only use it when the `native` prop is `false` (default).
   */ defaultOpen: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the select is disabled.
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the selected item is displayed even if its value is empty.
   */ displayEmpty: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the `select input` will indicate an error.
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The icon that displays the arrow.
   */ IconComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType.isRequired,
    /**
   * Imperative handle implementing `{ value: T, node: HTMLElement, focus(): void }`
   * Equivalent to `ref`
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * The ID of an element that acts as an additional label. The Select will
   * be labelled by the additional label and the selected value.
   */ labelId: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Props applied to the [`Menu`](/material-ui/api/menu/) element.
   */ MenuProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * If `true`, `value` must be an array and the menu will support multiple selections.
   */ multiple: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `select` or hidden `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * @ignore
   */ onBlur: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a menu item is selected.
   *
   * @param {object} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (any).
   * @param {object} [child] The react element that was selected.
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the component requests to be closed.
   * Use in controlled mode (see open).
   *
   * @param {object} event The event source of the callback.
   */ onClose: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the component requests to be opened.
   * Use in controlled mode (see open).
   *
   * @param {object} event The event source of the callback.
   */ onOpen: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the component is shown.
   */ open: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * @ignore
   */ readOnly: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Render the selected value.
   *
   * @param {any} value The `value` provided to the component.
   * @returns {ReactNode}
   */ renderValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the component is required.
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Props applied to the clickable div element.
   */ SelectDisplayProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ tabIndex: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * @ignore
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * The input value.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * The variant to use.
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'standard',
        'outlined',
        'filled'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = SelectInput;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ArrowDropDown.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M7 10l5 5 5-5z"
}), 'ArrowDropDown');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/deepmerge/deepmerge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getReactElementRef$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/getReactElementRef/getReactElementRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$SelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/SelectInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/formControlState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/useFormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ArrowDropDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ArrowDropDown.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Input/Input.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$NativeSelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/NativeSelect/NativeSelectInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$FilledInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FilledInput/FilledInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$OutlinedInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/OutlinedInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/rootShouldForwardProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/selectClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ]
    };
    const composedClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$selectClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSelectUtilityClasses"], classes);
    return {
        ...classes,
        ...composedClasses
    };
};
const styledRootConfig = {
    name: 'MuiSelect',
    slot: 'Root',
    shouldForwardProp: (prop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$rootShouldForwardProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prop) && prop !== 'variant'
};
const StyledInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], styledRootConfig)('');
const StyledOutlinedInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$OutlinedInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], styledRootConfig)('');
const StyledFilledInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$FilledInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], styledRootConfig)('');
const Select = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Select(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        name: 'MuiSelect',
        props: inProps
    });
    const { autoWidth = false, children, classes: classesProp = {}, className, defaultOpen = false, displayEmpty = false, IconComponent = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ArrowDropDown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], id, input, inputProps, label, labelId, MenuProps, multiple = false, native = false, onClose, onOpen, open, renderValue, SelectDisplayProps, variant: variantProp = 'outlined', ...other } = props;
    const inputComponent = native ? __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$NativeSelect$2f$NativeSelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$SelectInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const muiFormControl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$useFormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const fcs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        props,
        muiFormControl,
        states: [
            'variant',
            'error'
        ]
    });
    const variant = fcs.variant || variantProp;
    const ownerState = {
        ...props,
        variant,
        classes: classesProp
    };
    const classes = useUtilityClasses(ownerState);
    const { root, ...restOfClasses } = classes;
    const InputComponent = input || ({
        standard: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledInput, {
            ownerState: ownerState
        }),
        outlined: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledOutlinedInput, {
            label: label,
            ownerState: ownerState
        }),
        filled: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledFilledInput, {
            ownerState: ownerState
        })
    })[variant];
    const inputComponentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ref, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$getReactElementRef$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(InputComponent));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](InputComponent, {
            // Most of the logic is implemented in `SelectInput`.
            // The `Select` component is a simple API wrapper to expose something better to play with.
            inputComponent,
            inputProps: {
                children,
                error: fcs.error,
                IconComponent,
                variant,
                type: undefined,
                // We render a select. We can ignore the type provided by the `Input`.
                multiple,
                ...native ? {
                    id
                } : {
                    autoWidth,
                    defaultOpen,
                    displayEmpty,
                    labelId,
                    MenuProps,
                    onClose,
                    onOpen,
                    open,
                    renderValue,
                    SelectDisplayProps: {
                        id,
                        ...SelectDisplayProps
                    }
                },
                ...inputProps,
                classes: inputProps ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$deepmerge$2f$deepmerge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(restOfClasses, inputProps.classes) : restOfClasses,
                ...input ? input.props.inputProps : {}
            },
            ...(multiple && native || displayEmpty) && variant === 'outlined' ? {
                notched: true
            } : {},
            ref: inputComponentRef,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(InputComponent.props.className, className, classes.root),
            // If a custom input is provided via 'input' prop, do not allow 'variant' to be propagated to it's root element. See https://github.com/mui/material-ui/issues/33894.
            ...!input && {
                variant
            },
            ...other
        })
    });
});
("TURBOPACK compile-time truthy", 1) ? Select.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * If `true`, the width of the popover will automatically be set according to the items inside the
   * menu, otherwise it will be at least the width of the select input.
   * @default false
   */ autoWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The option elements to populate the select with.
   * Can be some `MenuItem` when `native` is false and `option` when `native` is true.
   *
   * ⚠️The `MenuItem` elements **must** be direct descendants when `native` is false.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   * @default {}
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the component is initially open. Use when the component open state is not controlled (i.e. the `open` prop is not defined).
   * You can only use it when the `native` prop is `false` (default).
   * @default false
   */ defaultOpen: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, a value is displayed even if no items are selected.
   *
   * In order to display a meaningful value, a function can be passed to the `renderValue` prop which
   * returns the value to be displayed when no items are selected.
   *
   * ⚠️ When using this prop, make sure the label doesn't overlap with the empty displayed value.
   * The label should either be hidden or forced to a shrunk state.
   * @default false
   */ displayEmpty: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The icon that displays the arrow.
   * @default ArrowDropDownIcon
   */ IconComponent: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * The `id` of the wrapper element or the `select` element when `native`.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * An `Input` element; does not have to be a material-ui specific `Input`.
   */ input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].element,
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * When `native` is `true`, the attributes are applied on the `select` element.
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * See [OutlinedInput#label](https://mui.com/material-ui/api/outlined-input/#props)
   */ label: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The ID of an element that acts as an additional label. The Select will
   * be labelled by the additional label and the selected value.
   */ labelId: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Props applied to the [`Menu`](https://mui.com/material-ui/api/menu/) element.
   */ MenuProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * If `true`, `value` must be an array and the menu will support multiple selections.
   * @default false
   */ multiple: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the component uses a native `select` element.
   * @default false
   */ native: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Callback fired when a menu item is selected.
   *
   * @param {SelectChangeEvent<Value>} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (any).
   * **Warning**: This is a generic event, not a change event, unless the change event is caused by browser autofill.
   * @param {object} [child] The react element that was selected when `native` is `false` (default).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the component requests to be closed.
   * Use it in either controlled (see the `open` prop), or uncontrolled mode (to detect when the Select collapses).
   *
   * @param {object} event The event source of the callback.
   */ onClose: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the component requests to be opened.
   * Use it in either controlled (see the `open` prop), or uncontrolled mode (to detect when the Select expands).
   *
   * @param {object} event The event source of the callback.
   */ onOpen: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the component is shown.
   * You can only use it when the `native` prop is `false` (default).
   */ open: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Render the selected value.
   * You can only use it when the `native` prop is `false` (default).
   *
   * @param {any} value The `value` provided to the component.
   * @returns {ReactNode}
   */ renderValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Props applied to the clickable div element.
   */ SelectDisplayProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The `input` value. Providing an empty string will select no options.
   * Set to an empty string `''` if you don't want any of the available options to be selected.
   *
   * If the value is an object it must have reference equality with the option in order to be selected.
   * If the value is not an object, the string representation must match with the string representation of the option in order to be selected.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            ''
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
    ]),
    /**
   * The variant to use.
   * @default 'outlined'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'filled',
        'outlined',
        'standard'
    ])
} : "TURBOPACK unreachable";
Select.muiName = 'Select';
const __TURBOPACK__default__export__ = Select;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/textFieldClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getTextFieldUtilityClass",
    ()=>getTextFieldUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getTextFieldUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiTextField', slot);
}
const textFieldClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiTextField', [
    'root'
]);
const __TURBOPACK__default__export__ = textFieldClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/useId/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/refType/refType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Input/Input.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$FilledInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FilledInput/FilledInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$OutlinedInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/OutlinedInput/OutlinedInput.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$FormHelperText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/FormHelperText/FormHelperText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$textFieldClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/textFieldClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useSlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const variantComponent = {
    standard: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Input$2f$Input$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    filled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$FilledInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    outlined: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$OutlinedInput$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
const useUtilityClasses = (ownerState)=>{
    const { classes } = ownerState;
    const slots = {
        root: [
            'root'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$textFieldClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTextFieldUtilityClass"], classes);
};
const TextFieldRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiTextField',
    slot: 'Root'
})({});
/**
 * The `TextField` is a convenience wrapper for the most common cases (80%).
 * It cannot be all things to all people, otherwise the API would grow out of control.
 *
 * ## Advanced Configuration
 *
 * It's important to understand that the text field is a simple abstraction
 * on top of the following components:
 *
 * - [FormControl](/material-ui/api/form-control/)
 * - [InputLabel](/material-ui/api/input-label/)
 * - [FilledInput](/material-ui/api/filled-input/)
 * - [OutlinedInput](/material-ui/api/outlined-input/)
 * - [Input](/material-ui/api/input/)
 * - [FormHelperText](/material-ui/api/form-helper-text/)
 *
 * If you wish to alter the props applied to the `input` element, you can do so as follows:
 *
 * ```jsx
 * const inputProps = {
 *   step: 300,
 * };
 *
 * return <TextField id="time" type="time" inputProps={inputProps} />;
 * ```
 *
 * For advanced cases, please look at the source of TextField by clicking on the
 * "Edit this page" button above. Consider either:
 *
 * - using the upper case props for passing values directly to the components
 * - using the underlying components directly as shown in the demos
 */ const TextField = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function TextField(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiTextField'
    });
    const { autoComplete, autoFocus = false, children, className, color = 'primary', defaultValue, disabled = false, error = false, FormHelperTextProps: FormHelperTextPropsProp, fullWidth = false, helperText, id: idOverride, InputLabelProps: InputLabelPropsProp, inputProps: inputPropsProp, InputProps: InputPropsProp, inputRef, label, maxRows, minRows, multiline = false, name, onBlur, onChange, onFocus, placeholder, required = false, rows, select = false, SelectProps: SelectPropsProp, slots = {}, slotProps = {}, type, value, variant = 'outlined', ...other } = props;
    const ownerState = {
        ...props,
        autoFocus,
        color,
        disabled,
        error,
        fullWidth,
        multiline,
        required,
        select,
        variant
    };
    const classes = useUtilityClasses(ownerState);
    if ("TURBOPACK compile-time truthy", 1) {
        if (select && !children) {
            console.error('MUI: `children` must be passed when using the `TextField` component with `select`.');
        }
    }
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(idOverride);
    const helperTextId = helperText && id ? `${id}-helper-text` : undefined;
    const inputLabelId = label && id ? `${id}-label` : undefined;
    const InputComponent = variantComponent[variant];
    const externalForwardedProps = {
        slots,
        slotProps: {
            input: InputPropsProp,
            inputLabel: InputLabelPropsProp,
            htmlInput: inputPropsProp,
            formHelperText: FormHelperTextPropsProp,
            select: SelectPropsProp,
            ...slotProps
        }
    };
    const inputAdditionalProps = {};
    const inputLabelSlotProps = externalForwardedProps.slotProps.inputLabel;
    if (variant === 'outlined') {
        if (inputLabelSlotProps && typeof inputLabelSlotProps.shrink !== 'undefined') {
            inputAdditionalProps.notched = inputLabelSlotProps.shrink;
        }
        inputAdditionalProps.label = label;
    }
    if (select) {
        // unset defaults from textbox inputs
        if (!SelectPropsProp || !SelectPropsProp.native) {
            inputAdditionalProps.id = undefined;
        }
        inputAdditionalProps['aria-describedby'] = undefined;
    }
    const [RootSlot, rootProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('root', {
        elementType: TextFieldRoot,
        shouldForwardComponentProp: true,
        externalForwardedProps: {
            ...externalForwardedProps,
            ...other
        },
        ownerState,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        ref,
        additionalProps: {
            disabled,
            error,
            fullWidth,
            required,
            color,
            variant
        }
    });
    const [InputSlot, inputProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('input', {
        elementType: InputComponent,
        externalForwardedProps,
        additionalProps: inputAdditionalProps,
        ownerState
    });
    const [InputLabelSlot, inputLabelProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('inputLabel', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState
    });
    const [HtmlInputSlot, htmlInputProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('htmlInput', {
        elementType: 'input',
        externalForwardedProps,
        ownerState
    });
    const [FormHelperTextSlot, formHelperTextProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('formHelperText', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormHelperText$2f$FormHelperText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState
    });
    const [SelectSlot, selectProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('select', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState
    });
    const InputElement = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputSlot, {
        "aria-describedby": helperTextId,
        autoComplete: autoComplete,
        autoFocus: autoFocus,
        defaultValue: defaultValue,
        fullWidth: fullWidth,
        multiline: multiline,
        name: name,
        rows: rows,
        maxRows: maxRows,
        minRows: minRows,
        type: type,
        value: value,
        id: id,
        inputRef: inputRef,
        onBlur: onBlur,
        onChange: onChange,
        onFocus: onFocus,
        placeholder: placeholder,
        inputProps: htmlInputProps,
        slots: {
            input: slots.htmlInput ? HtmlInputSlot : undefined
        },
        ...inputProps
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(RootSlot, {
        ...rootProps,
        children: [
            label != null && label !== '' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputLabelSlot, {
                htmlFor: id,
                id: inputLabelId,
                ...inputLabelProps,
                children: label
            }),
            select ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SelectSlot, {
                "aria-describedby": helperTextId,
                id: id,
                labelId: inputLabelId,
                value: value,
                input: InputElement,
                ...selectProps,
                children: children
            }) : InputElement,
            helperText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FormHelperTextSlot, {
                id: helperTextId,
                ...formHelperTextProps,
                children: helperText
            })
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? TextField.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * This prop helps users to fill forms faster, especially on mobile devices.
   * The name can be confusing, as it's more like an autofill.
   * You can learn more about it [following the specification](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
   */ autoComplete: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the `input` element is focused during the first mount.
   * @default false
   */ autoFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * @ignore
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * @default 'primary'
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'primary',
            'secondary',
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The default value. Use when the component is not controlled.
   */ defaultValue: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * If `true`, the component is disabled.
   * @default false
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the label is displayed in an error state.
   * @default false
   */ error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Props applied to the [`FormHelperText`](https://mui.com/material-ui/api/form-helper-text/) element.
   * @deprecated Use `slotProps.formHelperText` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ FormHelperTextProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * If `true`, the input will take up the full width of its container.
   * @default false
   */ fullWidth: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The helper text content.
   */ helperText: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The id of the `input` element.
   * Use this prop to make `label` and `helperText` accessible for screen readers.
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Props applied to the [`InputLabel`](https://mui.com/material-ui/api/input-label/) element.
   * Pointer events like `onClick` are enabled if and only if `shrink` is `true`.
   * @deprecated Use `slotProps.inputLabel` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ InputLabelProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#attributes) applied to the `input` element.
   * @deprecated Use `slotProps.htmlInput` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Props applied to the Input element.
   * It will be a [`FilledInput`](https://mui.com/material-ui/api/filled-input/),
   * [`OutlinedInput`](https://mui.com/material-ui/api/outlined-input/) or [`Input`](https://mui.com/material-ui/api/input/)
   * component depending on the `variant` prop value.
   * @deprecated Use `slotProps.input` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ InputProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a ref to the `input` element.
   */ inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$refType$2f$refType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    /**
   * The label content.
   */ label: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * If `dense` or `normal`, will adjust vertical spacing of this and contained components.
   * @default 'none'
   */ margin: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'dense',
        'none',
        'normal'
    ]),
    /**
   * Maximum number of rows to display when multiline option is set to true.
   */ maxRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Minimum number of rows to display when multiline option is set to true.
   */ minRows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, a `textarea` element is rendered instead of an input.
   * @default false
   */ multiline: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Name attribute of the `input` element.
   */ name: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * @ignore
   */ onBlur: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the value is changed.
   *
   * @param {object} event The event source of the callback.
   * You can pull out the new value by accessing `event.target.value` (string).
   */ onChange: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * @ignore
   */ onFocus: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The short hint displayed in the `input` before the user enters a value.
   */ placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the label is displayed as required and the `input` element is required.
   * @default false
   */ required: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Number of rows to display when multiline option is set to true.
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * Render a [`Select`](https://mui.com/material-ui/api/select/) element while passing the Input element to `Select` as `input` parameter.
   * If this option is set you must pass the options of the select as children.
   * @default false
   */ select: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Props applied to the [`Select`](https://mui.com/material-ui/api/select/) element.
   * @deprecated Use `slotProps.select` instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   */ SelectProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The size of the component.
   * @default 'medium'
   */ size: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'medium',
            'small'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The props used for each slot inside.
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .shape({
        formHelperText: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        htmlInput: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        inputLabel: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        select: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ])
    }),
    /**
   * The components used for each slot inside.
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        formHelperText: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        htmlInput: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        input: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        inputLabel: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        select: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * Type of the `input` element. It should be [a valid HTML5 input type](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input#input_types).
   */ type: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The value of the `input` element, required for a controlled component.
   */ value: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any,
    /**
   * The variant to use.
   * @default 'outlined'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'filled',
        'outlined',
        'standard'
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = TextField;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript) <export default as TextField>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TextField",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Alert/alertClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getAlertUtilityClass",
    ()=>getAlertUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getAlertUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiAlert', slot);
}
const alertClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiAlert', [
    'root',
    'action',
    'icon',
    'message',
    'filled',
    'colorSuccess',
    'colorInfo',
    'colorWarning',
    'colorError',
    'filledSuccess',
    'filledInfo',
    'filledWarning',
    'filledError',
    'outlined',
    'outlinedSuccess',
    'outlinedInfo',
    'outlinedWarning',
    'outlinedError',
    'standard',
    'standardSuccess',
    'standardInfo',
    'standardWarning',
    'standardError'
]);
const __TURBOPACK__default__export__ = alertClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/IconButton/iconButtonClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getIconButtonUtilityClass",
    ()=>getIconButtonUtilityClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
;
;
function getIconButtonUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiIconButton', slot);
}
const iconButtonClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiIconButton', [
    'root',
    'disabled',
    'colorInherit',
    'colorPrimary',
    'colorSecondary',
    'colorError',
    'colorInfo',
    'colorSuccess',
    'colorWarning',
    'edgeStart',
    'edgeEnd',
    'sizeSmall',
    'sizeMedium',
    'sizeLarge',
    'loading',
    'loadingIndicator',
    'loadingWrapper'
]);
const __TURBOPACK__default__export__ = iconButtonClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/chainPropTypes/chainPropTypes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__unstable_useId$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useId.js [app-client] (ecmascript) <export default as unstable_useId>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonBase$2f$ButtonBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/ButtonBase/ButtonBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/IconButton/iconButtonClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { classes, disabled, color, edge, size, loading } = ownerState;
    const slots = {
        root: [
            'root',
            loading && 'loading',
            disabled && 'disabled',
            color !== 'default' && `color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(color)}`,
            edge && `edge${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(edge)}`,
            `size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(size)}`
        ],
        loadingIndicator: [
            'loadingIndicator'
        ],
        loadingWrapper: [
            'loadingWrapper'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIconButtonUtilityClass"], classes);
};
const IconButtonRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonBase$2f$ButtonBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiIconButton',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            ownerState.loading && styles.loading,
            ownerState.color !== 'default' && styles[`color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.color)}`],
            ownerState.edge && styles[`edge${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.edge)}`],
            styles[`size${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.size)}`]
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        textAlign: 'center',
        flex: '0 0 auto',
        fontSize: theme.typography.pxToRem(24),
        padding: 8,
        borderRadius: '50%',
        color: (theme.vars || theme).palette.action.active,
        transition: theme.transitions.create('background-color', {
            duration: theme.transitions.duration.shortest
        }),
        variants: [
            {
                props: (props)=>!props.disableRipple,
                style: {
                    '--IconButton-hoverBg': theme.alpha((theme.vars || theme).palette.action.active, (theme.vars || theme).palette.action.hoverOpacity),
                    '&:hover': {
                        backgroundColor: 'var(--IconButton-hoverBg)',
                        // Reset on touch devices, it doesn't add specificity
                        '@media (hover: none)': {
                            backgroundColor: 'transparent'
                        }
                    }
                }
            },
            {
                props: {
                    edge: 'start'
                },
                style: {
                    marginLeft: -12
                }
            },
            {
                props: {
                    edge: 'start',
                    size: 'small'
                },
                style: {
                    marginLeft: -3
                }
            },
            {
                props: {
                    edge: 'end'
                },
                style: {
                    marginRight: -12
                }
            },
            {
                props: {
                    edge: 'end',
                    size: 'small'
                },
                style: {
                    marginRight: -3
                }
            }
        ]
    })), (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>({
        variants: [
            {
                props: {
                    color: 'inherit'
                },
                style: {
                    color: 'inherit'
                }
            },
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()) // check all the used fields in the style below
            .map(([color])=>({
                    props: {
                        color
                    },
                    style: {
                        color: (theme.vars || theme).palette[color].main
                    }
                })),
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()) // check all the used fields in the style below
            .map(([color])=>({
                    props: {
                        color
                    },
                    style: {
                        '--IconButton-hoverBg': theme.alpha((theme.vars || theme).palette[color].main, (theme.vars || theme).palette.action.hoverOpacity)
                    }
                })),
            {
                props: {
                    size: 'small'
                },
                style: {
                    padding: 5,
                    fontSize: theme.typography.pxToRem(18)
                }
            },
            {
                props: {
                    size: 'large'
                },
                style: {
                    padding: 12,
                    fontSize: theme.typography.pxToRem(28)
                }
            }
        ],
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].disabled}`]: {
            backgroundColor: 'transparent',
            color: (theme.vars || theme).palette.action.disabled
        },
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].loading}`]: {
            color: 'transparent'
        }
    })));
const IconButtonLoadingIndicator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('span', {
    name: 'MuiIconButton',
    slot: 'LoadingIndicator'
})(({ theme })=>({
        display: 'none',
        position: 'absolute',
        visibility: 'visible',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        color: (theme.vars || theme).palette.action.disabled,
        variants: [
            {
                props: {
                    loading: true
                },
                style: {
                    display: 'flex'
                }
            }
        ]
    }));
/**
 * Refer to the [Icons](/material-ui/icons/) section of the documentation
 * regarding the available icon options.
 */ const IconButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function IconButton(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiIconButton'
    });
    const { edge = false, children, className, color = 'default', disabled = false, disableFocusRipple = false, size = 'medium', id: idProp, loading = null, loadingIndicator: loadingIndicatorProp, ...other } = props;
    const loadingId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__unstable_useId$3e$__["unstable_useId"])(idProp);
    const loadingIndicator = loadingIndicatorProp ?? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        "aria-labelledby": loadingId,
        color: "inherit",
        size: 16
    });
    const ownerState = {
        ...props,
        edge,
        color,
        disabled,
        disableFocusRipple,
        loading,
        loadingIndicator,
        size
    };
    const classes = useUtilityClasses(ownerState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(IconButtonRoot, {
        id: loading ? loadingId : idProp,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        centerRipple: true,
        focusRipple: !disableFocusRipple,
        disabled: disabled || loading,
        ref: ref,
        ...other,
        ownerState: ownerState,
        children: [
            typeof loading === 'boolean' && /*#__PURE__*/ // use plain HTML span to minimize the runtime overhead
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: classes.loadingWrapper,
                style: {
                    display: 'contents'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconButtonLoadingIndicator, {
                    className: classes.loadingIndicator,
                    ownerState: ownerState,
                    children: loading && loadingIndicator
                })
            }),
            children
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? IconButton.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The icon to display.
   */ children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$chainPropTypes$2f$chainPropTypes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node, (props)=>{
        const found = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(props.children).some((child)=>/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](child) && child.props.onClick);
        if (found) {
            return new Error([
                'MUI: You are providing an onClick event listener to a child of a button element.',
                'Prefer applying it to the IconButton directly.',
                'This guarantees that the whole <button> will be responsive to click events.'
            ].join('\n'));
        }
        return null;
    }),
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   * @default 'default'
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'inherit',
            'default',
            'primary',
            'secondary',
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * If `true`, the component is disabled.
   * @default false
   */ disabled: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the  keyboard focus ripple is disabled.
   * @default false
   */ disableFocusRipple: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the ripple effect is disabled.
   *
   * ⚠️ Without a ripple there is no styling for :focus-visible by default. Be sure
   * to highlight the element by applying separate styles with the `.Mui-focusVisible` class.
   * @default false
   */ disableRipple: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If given, uses a negative margin to counteract the padding on one
   * side (this is often helpful for aligning the left or right
   * side of the icon with content above or below, without ruining the border
   * size and shape).
   * @default false
   */ edge: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'end',
        'start',
        false
    ]),
    /**
   * @ignore
   */ id: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the loading indicator is visible and the button is disabled.
   * If `true | false`, the loading wrapper is always rendered before the children to prevent [Google Translation Crash](https://github.com/mui/material-ui/issues/27853).
   * @default null
   */ loading: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Element placed before the children if the button is in loading state.
   * The node should contain an element with `role="progressbar"` with an accessible name.
   * By default, it renders a `CircularProgress` that is labeled by the button itself.
   * @default <CircularProgress color="inherit" size={16} />
   */ loadingIndicator: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The size of the component.
   * `small` is equivalent to the dense button styling.
   * @default 'medium'
   */ size: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'small',
            'medium',
            'large'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = IconButton;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/SuccessOutlined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2, 4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0, 0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"
}), 'SuccessOutlined');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ReportProblemOutlined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 5.99L19.53 19H4.47L12 5.99M12 2L1 21h22L12 2zm1 14h-2v2h2v-2zm0-6h-2v4h2v-4z"
}), 'ReportProblemOutlined');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ErrorOutline.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11 15h2v2h-2zm0-8h2v6h-2zm.99-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
}), 'ErrorOutline');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/InfoOutlined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20, 12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10, 10 0 0,0 12,2M11,17H13V11H11V17Z"
}), 'InfoOutlined');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/Close.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript)");
/**
 * @ignore - internal component.
 *
 * Alias to `Clear`.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close');
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/memoTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/DefaultPropsProvider/DefaultPropsProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/useSlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/capitalize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/utils/createSimplePaletteValueFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Alert/alertClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$SuccessOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/SuccessOutlined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ReportProblemOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ReportProblemOutlined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ErrorOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/ErrorOutline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$InfoOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/InfoOutlined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/internal/svg-icons/Close.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useUtilityClasses = (ownerState)=>{
    const { variant, color, severity, classes } = ownerState;
    const slots = {
        root: [
            'root',
            `color${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(color || severity)}`,
            `${variant}${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(color || severity)}`,
            `${variant}`
        ],
        icon: [
            'icon'
        ],
        message: [
            'message'
        ],
        action: [
            'action'
        ]
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlertUtilityClass"], classes);
};
const AlertRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiAlert',
    slot: 'Root',
    overridesResolver: (props, styles)=>{
        const { ownerState } = props;
        return [
            styles.root,
            styles[ownerState.variant],
            styles[`${ownerState.variant}${(0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$capitalize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ownerState.color || ownerState.severity)}`]
        ];
    }
})((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$memoTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ theme })=>{
    const getColor = theme.palette.mode === 'light' ? theme.darken : theme.lighten;
    const getBackgroundColor = theme.palette.mode === 'light' ? theme.lighten : theme.darken;
    return {
        ...theme.typography.body2,
        backgroundColor: 'transparent',
        display: 'flex',
        padding: '6px 16px',
        variants: [
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])([
                'light'
            ])).map(([color])=>({
                    props: {
                        colorSeverity: color,
                        variant: 'standard'
                    },
                    style: {
                        color: theme.vars ? theme.vars.palette.Alert[`${color}Color`] : getColor(theme.palette[color].light, 0.6),
                        backgroundColor: theme.vars ? theme.vars.palette.Alert[`${color}StandardBg`] : getBackgroundColor(theme.palette[color].light, 0.9),
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].icon}`]: theme.vars ? {
                            color: theme.vars.palette.Alert[`${color}IconColor`]
                        } : {
                            color: theme.palette[color].main
                        }
                    }
                })),
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])([
                'light'
            ])).map(([color])=>({
                    props: {
                        colorSeverity: color,
                        variant: 'outlined'
                    },
                    style: {
                        color: theme.vars ? theme.vars.palette.Alert[`${color}Color`] : getColor(theme.palette[color].light, 0.6),
                        border: `1px solid ${(theme.vars || theme).palette[color].light}`,
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].icon}`]: theme.vars ? {
                            color: theme.vars.palette.Alert[`${color}IconColor`]
                        } : {
                            color: theme.palette[color].main
                        }
                    }
                })),
            ...Object.entries(theme.palette).filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSimplePaletteValueFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])([
                'dark'
            ])).map(([color])=>({
                    props: {
                        colorSeverity: color,
                        variant: 'filled'
                    },
                    style: {
                        fontWeight: theme.typography.fontWeightMedium,
                        ...theme.vars ? {
                            color: theme.vars.palette.Alert[`${color}FilledColor`],
                            backgroundColor: theme.vars.palette.Alert[`${color}FilledBg`]
                        } : {
                            backgroundColor: theme.palette.mode === 'dark' ? theme.palette[color].dark : theme.palette[color].main,
                            color: theme.palette.getContrastText(theme.palette[color].main)
                        }
                    }
                }))
        ]
    };
}));
const AlertIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiAlert',
    slot: 'Icon'
})({
    marginRight: 12,
    padding: '7px 0',
    display: 'flex',
    fontSize: 22,
    opacity: 0.9
});
const AlertMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiAlert',
    slot: 'Message'
})({
    padding: '8px 0',
    minWidth: 0,
    overflow: 'auto'
});
const AlertAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiAlert',
    slot: 'Action'
})({
    display: 'flex',
    alignItems: 'flex-start',
    padding: '4px 0 0 16px',
    marginLeft: 'auto',
    marginRight: -8
});
const defaultIconMapping = {
    success: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$SuccessOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "inherit"
    }),
    warning: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ReportProblemOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "inherit"
    }),
    error: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$ErrorOutline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "inherit"
    }),
    info: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$InfoOutlined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        fontSize: "inherit"
    })
};
const Alert = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Alert(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DefaultPropsProvider$2f$DefaultPropsProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDefaultProps"])({
        props: inProps,
        name: 'MuiAlert'
    });
    const { action, children, className, closeText = 'Close', color, components = {}, componentsProps = {}, icon, iconMapping = defaultIconMapping, onClose, role = 'alert', severity = 'success', slotProps = {}, slots = {}, variant = 'standard', ...other } = props;
    const ownerState = {
        ...props,
        color,
        severity,
        variant,
        colorSeverity: color || severity
    };
    const classes = useUtilityClasses(ownerState);
    const externalForwardedProps = {
        slots: {
            closeButton: components.CloseButton,
            closeIcon: components.CloseIcon,
            ...slots
        },
        slotProps: {
            ...componentsProps,
            ...slotProps
        }
    };
    const [RootSlot, rootSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('root', {
        ref,
        shouldForwardComponentProp: true,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(classes.root, className),
        elementType: AlertRoot,
        externalForwardedProps: {
            ...externalForwardedProps,
            ...other
        },
        ownerState,
        additionalProps: {
            role,
            elevation: 0
        }
    });
    const [IconSlot, iconSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('icon', {
        className: classes.icon,
        elementType: AlertIcon,
        externalForwardedProps,
        ownerState
    });
    const [MessageSlot, messageSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('message', {
        className: classes.message,
        elementType: AlertMessage,
        externalForwardedProps,
        ownerState
    });
    const [ActionSlot, actionSlotProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('action', {
        className: classes.action,
        elementType: AlertAction,
        externalForwardedProps,
        ownerState
    });
    const [CloseButtonSlot, closeButtonProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('closeButton', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState
    });
    const [CloseIconSlot, closeIconProps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$useSlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('closeIcon', {
        elementType: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$internal$2f$svg$2d$icons$2f$Close$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        externalForwardedProps,
        ownerState
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(RootSlot, {
        ...rootSlotProps,
        children: [
            icon !== false ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconSlot, {
                ...iconSlotProps,
                children: icon || iconMapping[severity] || defaultIconMapping[severity]
            }) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MessageSlot, {
                ...messageSlotProps,
                children: children
            }),
            action != null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ActionSlot, {
                ...actionSlotProps,
                children: action
            }) : null,
            action == null && onClose ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ActionSlot, {
                ...actionSlotProps,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CloseButtonSlot, {
                    size: "small",
                    "aria-label": closeText,
                    title: closeText,
                    color: "inherit",
                    onClick: onClose,
                    ...closeButtonProps,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CloseIconSlot, {
                        fontSize: "small",
                        ...closeIconProps
                    })
                })
            }) : null
        ]
    });
});
("TURBOPACK compile-time truthy", 1) ? Alert.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * The action to display. It renders after the message, at the end of the alert.
   */ action: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The content of the component.
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * @ignore
   */ className: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Override the default label for the *close popup* icon button.
   *
   * For localization purposes, you can use the provided [translations](https://mui.com/material-ui/guides/localization/).
   * @default 'Close'
   */ closeText: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The color of the component. Unless provided, the value is taken from the `severity` prop.
   * It supports both default and custom theme colors, which can be added as shown in the
   * [palette customization guide](https://mui.com/material-ui/customization/palette/#custom-colors).
   */ color: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The components used for each slot inside.
   *
   * @deprecated use the `slots` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ components: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        CloseButton: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        CloseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The extra props for the slot components.
   * You can override the existing props or add new ones.
   *
   * @deprecated use the `slotProps` prop instead. This prop will be removed in a future major release. See [Migrating from deprecated APIs](https://mui.com/material-ui/migration/migrating-from-deprecated-apis/) for more details.
   *
   * @default {}
   */ componentsProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        closeButton: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
        closeIcon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * Override the icon displayed before the children.
   * Unless provided, the icon is mapped to the value of the `severity` prop.
   * Set to `false` to remove the `icon`.
   */ icon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The component maps the `severity` prop to a range of different icons,
   * for instance success to `<SuccessOutlined>`.
   * If you wish to change this mapping, you can provide your own.
   * Alternatively, you can use the `icon` prop to override the icon displayed.
   */ iconMapping: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
        info: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
        success: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
        warning: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node
    }),
    /**
   * Callback fired when the component requests to be closed.
   * When provided and no `action` prop is set, a close icon button is displayed that triggers the callback when clicked.
   * @param {React.SyntheticEvent} event The event source of the callback.
   */ onClose: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The ARIA role attribute of the element.
   * @default 'alert'
   */ role: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The severity of the alert. This defines the color and icon used.
   * @default 'success'
   */ severity: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'error',
            'info',
            'success',
            'warning'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ]),
    /**
   * The props used for each slot inside.
   * @default {}
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        action: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        closeButton: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        closeIcon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        message: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ]),
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
        ])
    }),
    /**
   * The components used for each slot inside.
   * @default {}
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        action: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        closeButton: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        closeIcon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        message: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
        root: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType
    }),
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * The variant to use.
   * @default 'standard'
   */ variant: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'filled',
            'outlined',
            'standard'
        ]),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Alert;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript) <export default as Alert>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Alert",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createBox/createBox.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>createBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$styled$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/styled-engine/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styleFunctionSx$2f$styleFunctionSx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/styleFunctionSx/styleFunctionSx.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styleFunctionSx$2f$extendSxProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extendSxProp$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/styleFunctionSx/extendSxProp.js [app-client] (ecmascript) <export default as extendSxProp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useTheme$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/useTheme/useTheme.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function createBox(options = {}) {
    const { themeId, defaultTheme, defaultClassName = 'MuiBox-root', generateClassName } = options;
    const BoxRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$styled$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])('div', {
        shouldForwardProp: (prop)=>prop !== 'theme' && prop !== 'sx' && prop !== 'as'
    })(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styleFunctionSx$2f$styleFunctionSx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const Box = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Box(inProps, ref) {
        const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useTheme$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(defaultTheme);
        const { className, component = 'div', ...other } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$styleFunctionSx$2f$extendSxProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extendSxProp$3e$__["extendSxProp"])(inProps);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BoxRoot, {
            as: component,
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, generateClassName ? generateClassName(defaultClassName) : defaultClassName),
            theme: themeId ? theme[themeId] || theme : theme,
            ...other
        });
    });
    return Box;
}
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createBox/createBox.js [app-client] (ecmascript) <export default as createBox>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createBox",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createBox$2f$createBox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createBox$2f$createBox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createBox/createBox.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/ClassNameGenerator/ClassNameGenerator.js [app-client] (ecmascript) <export default as unstable_ClassNameGenerator>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "unstable_ClassNameGenerator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ClassNameGenerator$2f$ClassNameGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ClassNameGenerator$2f$ClassNameGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/ClassNameGenerator/ClassNameGenerator.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript) <export default as createTheme>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTheme",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/boxClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
;
const boxClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiBox', [
    'root'
]);
const __TURBOPACK__default__export__ = boxClasses;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createBox$2f$createBox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createBox$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/system/esm/createBox/createBox.js [app-client] (ecmascript) <export default as createBox>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ClassNameGenerator$2f$ClassNameGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__unstable_ClassNameGenerator$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/utils/esm/ClassNameGenerator/ClassNameGenerator.js [app-client] (ecmascript) <export default as unstable_ClassNameGenerator>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript) <export default as createTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$identifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/styles/identifier.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$boxClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/boxClasses.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const defaultTheme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__["createTheme"])();
const Box = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$system$2f$esm$2f$createBox$2f$createBox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createBox$3e$__["createBox"])({
    themeId: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$identifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    defaultTheme,
    defaultClassName: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$boxClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].root,
    generateClassName: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$ClassNameGenerator$2f$ClassNameGenerator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__unstable_ClassNameGenerator$3e$__["unstable_ClassNameGenerator"].generate
});
("TURBOPACK compile-time truthy", 1) ? Box.propTypes = {
    // ┌────────────────────────────── Warning ──────────────────────────────┐
    // │ These PropTypes are generated from the TypeScript type definitions. │
    // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
    // └─────────────────────────────────────────────────────────────────────┘
    /**
   * @ignore
   */ children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */ component: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ])
} : "TURBOPACK unreachable";
const __TURBOPACK__default__export__ = Box;
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript) <export default as Box>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Box",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
}),
"[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript) <export default as CircularProgress>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CircularProgress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$UMich$2f$CIS525$2f$SmartSplit$2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=9bdb1_%40mui_ba264bb7._.js.map