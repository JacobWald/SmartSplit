module.exports = [
"[project]/Documents/UMich/CIS525/SmartSplit/apps/web/.next-internal/server/app/profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=a5a1c_SmartSplit_apps_web__next-internal_server_app_profile_page_actions_724e145c.js.map