var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/9bdb1_9dc7719b._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Documents/UMich/CIS525/SmartSplit/node_modules/next/document.js [ssr] (ecmascript)").exports
