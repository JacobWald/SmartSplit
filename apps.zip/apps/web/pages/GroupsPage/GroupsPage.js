import styles from './GroupsPage.module.css';

export default function GroupsPage() {
    return (
        <div className={styles.root}>
            <h1>Groups Page</h1>
            <p>This is where you can manage your groups.</p>
        </div>
    );
}