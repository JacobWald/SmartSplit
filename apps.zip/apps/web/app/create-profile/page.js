'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import {
  Container,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Alert,
  Box,
  CircularProgress,
  Grid,
} from '@mui/material';

export default function CreateProfilePage() {
  const router = useRouter();

  // Auth fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Profile fields
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');    // unique handle
  const [phone, setPhone] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');

  // UI state
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [infoMsg, setInfoMsg] = useState('');

  async function handleCreate(e) {
    e.preventDefault();
    setErrorMsg('');
    setInfoMsg('');
    setSubmitting(true);

    // Simple client-side checks
    if (!email || !password || !fullName || !username) {
      setErrorMsg('Please fill in Full Name, Username, Email, and Password.');
      setSubmitting(false);
      return;
    }
    if (username.length < 3) {
      setErrorMsg('Username must be at least 3 characters.');
      setSubmitting(false);
      return;
    }

    try {
      // 1) Create auth user (may require email confirmation, depending on your project)
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } }, // user_metadata
      });
      if (signUpError) throw signUpError;

      const userId = signUpData.user?.id;

      if (userId) {
        // 2) Insert/Upsert profile row for this user
        //    If you add a UNIQUE index on "username", this will fail gracefully on duplicates.
        const { error: profileError } = await supabase.from('profiles').upsert({
          id: userId,
          full_name: fullName,
          username: username,
          phone: phone || null,
          email: email,           // convenient to keep a copy
          avatar_url: avatarUrl || null,
          updated_at: new Date().toISOString(),
        });
        if (profileError) {
          // If you created a unique index on username, duplicate will surface here (code 23505)
          throw profileError;
        }

        setInfoMsg('Account created! Redirecting to your profile…');
        setTimeout(() => router.push('/profile'), 800);
      } else {
        // Email confirmation flow: user is null until they confirm
        setInfoMsg(
          'Check your email to confirm your account. After confirming, log in and your profile will be created/updated automatically.'
        );
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to create your profile. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Container maxWidth="sm" sx={{ py: { xs: 4, md: 6 } }}>
      <Card elevation={3} sx={{ borderRadius: 3 }}>
        <CardContent sx={{ p: { xs: 3, md: 4 } }}>
          <Typography
            variant="h4"
            component="h1"
            gutterBottom
            sx={{ fontWeight: 700, textAlign: 'center', mb: 3 }}
          >
            Create Profile
          </Typography>

          {errorMsg && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {errorMsg}
            </Alert>
          )}
          {infoMsg && (
            <Alert severity="success" sx={{ mb: 2 }}>
              {infoMsg}
            </Alert>
          )}

          <Box component="form" onSubmit={handleCreate} noValidate>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  label="Full Name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  fullWidth
                  required
                  autoComplete="name"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  label="Username"
                  placeholder="e.g., rakan_a"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.trim())}
                  fullWidth
                  required
                  helperText="Pick a unique handle (a–z, 0–9, underscore)."
                  inputProps={{ pattern: '[A-Za-z0-9_]{3,}' }}
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  label="Phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  fullWidth
                  autoComplete="tel"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  label="Avatar URL (optional)"
                  placeholder="https://…"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  fullWidth
                  autoComplete="off"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  label="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  fullWidth
                  required
                  autoComplete="email"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  label="Password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  fullWidth
                  required
                  autoComplete="new-password"
                />
              </Grid>
            </Grid>

            <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
              <Button type="submit" variant="contained" size="large" disabled={submitting}>
                {submitting ? (
                  <>
                    <CircularProgress size={22} sx={{ mr: 1 }} />
                    Creating…
                  </>
                ) : (
                  'Create Profile'
                )}
              </Button>
            </Box>

            <Typography variant="body2" sx={{ mt: 3, textAlign: 'center' }}>
              Already have an account?{' '}
              <Link
                href="/login"
                style={{ textDecoration: 'none', color: '#1976d2', fontWeight: 600 }}
              >
                Log In
              </Link>
            </Typography>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
}
