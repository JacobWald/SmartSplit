import HomePage from '../pages/HomePage/HomePage';

export default function Page() {
  return <HomePage />;
}