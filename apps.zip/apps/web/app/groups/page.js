import GroupsPage from "../../pages/GroupsPage/GroupsPage";

export default function Page() {
    return <GroupsPage />;
}