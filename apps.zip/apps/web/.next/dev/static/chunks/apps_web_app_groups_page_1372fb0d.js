(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_pages_GroupsPage_GroupsPage_module_fa8e7d17.css"
],
    source: "dynamic"
});
