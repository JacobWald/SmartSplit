(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_ebbd8575.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_434fd12f._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_@mui_material_esm_f178bfe1._.js",
  "static/chunks/node_modules_cebab9e0._.js",
  "static/chunks/apps_web_9ea1e91e._.js"
],
    source: "dynamic"
});
