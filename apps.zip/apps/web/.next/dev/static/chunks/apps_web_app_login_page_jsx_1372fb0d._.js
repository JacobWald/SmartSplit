(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_ebbd8575.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_434fd12f._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_@mui_material_esm_9d22beb3._.js",
  "static/chunks/node_modules_200a3da4._.js",
  "static/chunks/apps_web_dcbd19a6._.js"
],
    source: "dynamic"
});
