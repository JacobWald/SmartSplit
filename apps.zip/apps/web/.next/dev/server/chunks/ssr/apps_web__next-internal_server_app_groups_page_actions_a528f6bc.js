module.exports = [
"[project]/apps/web/.next-internal/server/app/groups/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_groups_page_actions_a528f6bc.js.map