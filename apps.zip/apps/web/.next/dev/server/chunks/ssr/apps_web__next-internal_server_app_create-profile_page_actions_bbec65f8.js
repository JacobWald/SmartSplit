module.exports = [
"[project]/apps/web/.next-internal/server/app/create-profile/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_create-profile_page_actions_bbec65f8.js.map